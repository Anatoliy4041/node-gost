// ����������� ����������� ���� � ������ reader/include/reader/support.h,
// reader/source/support/sup_def.h � reader/source/rndm/rndm_def.h,
// �� ���� ������� � ������������!
#if defined( UNIX ) || defined( _WIN32 ) && defined( __STDC__ ) || defined( WINCE )
#define NO_SUP_PROPERTIES
#endif // defined( UNIX ) || defined( _WIN32 ) && defined( __STDC__ ) || defined( WINCE )

#if !defined UNIX
RDR_ITEM(rdr_context_default_get, ( const TSupSysEList *list, TSupSysEContext **context ),( list, context ))
RDR_ITEM(rdr_context_default_set, ( const TSupSysEContext *context ),( context ))
RDR_ITEM(rdr_alloc,( size_t size, void ** res ),(size,res))
RDR_ITEM(rdr_free, ( void * mem ),(mem))
#endif /* !UNIX */

RDR_ITEM(rdr_info_carrier_type, ( const TSupSysEContext *context, TSupSysENickname carrier_type ),( context, carrier_type ))
RDR_ITEM(rdr_connect_carrier, (TSupSysEContext *context), (context))
RDR_ITEM(rdr_format_carrier, (TSupSysEContext *context), (context))
RDR_ITEM(rdr_clear_tries, ( TSupSysEContext *context, const TCHAR *passwd, int number ),( context, passwd, number ))
RDR_ITEM(rdr_disconnect_carrier, (TSupSysEContext *context), (context))
RDR_ITEM(rdr_local_machine, (TSupSysEContext *context, int local_machine ), (context, local_machine))
RDR_ITEM(rdr_passwd_length, ( const TSupSysEContext *context, TRdrLoginInfoType *type, size_t *max_length, size_t *min_length ),(context, type, max_length, min_length))
RDR_ITEM(rdr_passwd_term, ( const TSupSysEContext *context, size_t *length, TCHAR *term ),( context, length, term ))
RDR_ITEM(rdr_passwd_change, ( TSupSysEContext *context, const TCHAR *new_passwd ),( context, new_passwd ))
RDR_ITEM(rdr_passwd_clear, ( TSupSysEContext *context, const TCHAR *master_passwd ),( context, master_passwd ))
RDR_ITEM(rdr_passwd_phrase, (TSupSysEContext *context, size_t *length, TCHAR *phrase ),(context,length, phrase))
RDR_ITEM(rdr_passwd_default_get, ( const TSupSysEContext *context, size_t *passwd_length, TCHAR *passwd ), ( context, passwd_length, passwd ))
RDR_ITEM(rdr_passwd_default_set, ( const TSupSysEContext *context, const TCHAR *passwd ),( context, passwd ))
RDR_ITEM(rdr_passwd_default_clear, ( const TSupSysEContext *context ),( context ))
RDR_ITEM(rdr_passwd_default_clear_all, ( int machine ),( machine ))
RDR_ITEM(rdr_shortcut_clear, ( int local_machine, const TCHAR *shortcut ), (local_machine, shortcut))
RDR_ITEM(rdr_shortcut_get, ( int local_machine, const TCHAR *shortcut, size_t *unique_length, TCHAR *unique, size_t *folder_length, TCHAR *folder, size_t *untreated_length, TCHAR *untreated, TSupSysENickname media_type ), ( local_machine, shortcut, unique_length, unique, folder_length, folder, untreated_length, untreated, media_type ))
RDR_ITEM(rdr_shortcut_set, ( const TSupSysEContext *context, const TCHAR *shortcut, const TCHAR *untreated ), ( context, shortcut, untreated ))
RDR_ITEM(rdr_folder_enum_open, ( const TSupSysEContext *context, TRdrFolderEnumContext **enum_ctx, size_t *folder_length, const TCHAR *prototype, unsigned flags ), ( context, enum_ctx, folder_length, prototype, flags ))
RDR_ITEM(rdr_folder_enum_next, ( TRdrFolderEnumContext *enum_ctx, TCHAR *folder ), ( enum_ctx, folder ))
RDR_ITEM(rdr_folder_enum_close, ( TRdrFolderEnumContext *enum_ctx ), ( enum_ctx ))
RDR_ITEM(rdr_folder_open, ( TSupSysEContext *context, const TCHAR *mode, const TCHAR *folder ), ( context, mode, folder ))
RDR_ITEM(rdr_folder_close, ( TSupSysEContext *context ), ( context ))
RDR_ITEM(rdr_folder_clear, ( TSupSysEContext *context ), ( context ))
RDR_ITEM(rdr_login, ( TSupSysEContext *context, const TCHAR *login_info, int *retries ),( context, login_info, retries ))
RDR_ITEM(rdr_prime, ( TSupSysEContext *context, const TCHAR *login_info, int *retries ),( context, login_info, retries ))
RDR_ITEM(rdr_prime_login, ( TSupSysEContext *context ),( context ))
RDR_ITEM(rdr_puk_enter, ( TSupSysEContext *context, const TCHAR *login_info, int *retries ),( context, login_info, retries ))
RDR_ITEM(rdr_logout, ( TSupSysEContext *context ),( context ))
RDR_ITEM(rdr_lock, ( TSupSysEContext *context ), ( context ))
RDR_ITEM(rdr_unlock, ( TSupSysEContext *context ), ( context ))
RDR_ITEM(rdr_file_open, ( TSupSysEContext *context, const TCHAR *mode, const TCHAR *file_name, TRdrFileNumber filno ),( context, mode, file_name, filno ))
RDR_ITEM(rdr_file_close, ( TSupSysEContext *context ),( context ))
RDR_ITEM(rdr_file_write, ( TSupSysEContext *context, size_t pos, size_t size, const void *buffer, size_t *writen ),( context, pos, size, buffer, writen ))
RDR_ITEM(rdr_file_read, ( TSupSysEContext *context, size_t pos, size_t size, void *buffer, size_t *read_len ),( context, pos, size, buffer, read_len ))
RDR_ITEM(rdr_file_length, ( TSupSysEContext *context, size_t *size ),( context, size ))
RDR_ITEM(rdr_file_chsize, ( TSupSysEContext *context, size_t *size ),( context, size ))
RDR_ITEM(rdr_file_unlink, ( TSupSysEContext *context, const TCHAR *file_name, TRdrFileNumber filno ),( context, file_name, filno ))
RDR_ITEM(rdr_unique_get, ( const TSupSysEContext *context, size_t *length, TCHAR *unique ),( context, length, unique ))
RDR_ITEM(rdr_unique_set, ( TSupSysEContext *context, TCHAR *unique ),( context, unique ))
RDR_ITEM(rdr_error, ( const TSupSysEContext *context, TSupErr err, size_t *length, TCHAR *text ),( context, err, length, text ))
RDR_ITEM(rdr_carrier_type_get, ( const TSupSysEContext *context, TSupSysENickname carrier_type, const TCHAR * path_to_item ),( context, carrier_type, path_to_item ))
RDR_ITEM(rdr_same_media, ( const TSupSysEContext *context, size_t *length, TCHAR *unique, unsigned flags ),( context, length, unique, flags ))
RDR_ITEM(rdr_retry_proc_set, ( TSupSysEContext *context, TRdrRetryProc proc, void *info ),( context, proc, info ))

RDR_ITEM(rdr_register_start, ( TSupSysEList **list ), ( list ))

RDR_ITEM(rdr_cancel_consequences, ( const TSupSysEContext *context ), ( context ))
RDR_ITEM(rdr_media_register_start, ( TSupSysEList **list ), ( list ))

#ifndef UNIX

RDR_ITEM(rdr_wnd_retry_set, ( TSupSysEContext *ctx, TRdrWndRetry *info, void *use_info ), (ctx,info,use_info))
RDR_ITEM(rdr_wnd_choice_carrier, (const TRdrWndChoiceCarrier *init_info, void *ret_info ), (init_info,ret_info))

#endif /* UNIX */

#if defined( _WIN32 ) 
RDR_ITEM(rdr_set_sec_descr , ( TSupSysEContext *context, SECURITY_INFORMATION sInfo, PSECURITY_DESCRIPTOR pSecDescr, HRESULT * out_error ), ( context, sInfo, pSecDescr, out_error ))
RDR_ITEM(rdr_get_sec_descr , ( TSupSysEContext *context, SECURITY_INFORMATION sInfo, PSECURITY_DESCRIPTOR pSecDescr, DWORD * dbSecDescrLen, HRESULT * out_error ), ( context, sInfo, pSecDescr, dbSecDescrLen, out_error ))
#endif /*_WIN32 */

#ifndef NO_SUP_PROPERTIES
RDR_ITEM(rdr_wnd_configure, (TRdrWndConfigure *info), (info))
RDR_ITEM(rdr_media_wnd_configure, (TRdrMediaWndConfigure *info), (info))
#endif /* NO_SUP_PROPERTIES */

RDR_ITEM(fkc_lock, ( TSupSysEContext *context ), ( context ))
RDR_ITEM(rdr_folder_open_ex, ( TSupSysEContext *context, const TCHAR *mode, const TCHAR *folder, const TRdrInfoFolderOpenEx_param *param ), ( context, mode, folder, param ))
RDR_ITEM(rdr_folder_get_param,(const TSupSysEContext * context,const TRdrFolderEnumParam paramID, TRdrFolderParamValue * paramValue,size_t * paramSize),(context,paramID,paramValue,paramSize))
RDR_ITEM(rdr_folder_set_param,(TSupSysEContext * context,const TRdrFolderParamValue *paramValue),(context,paramValue))
RDR_ITEM(rdr_friendly_name_set,(TSupSysEContext * context,const TCHAR * tFriendlyName ),(context,tFriendlyName))
RDR_ITEM(fkc_passwd_term, (const TSupSysEContext * context,size_t *length,TCHAR *term ), (context,length,term ))
RDR_ITEM(fkc_passwd_length, (const TSupSysEContext *context, TRdrLoginInfoType *type, size_t *max_length, size_t *min_length ), (context, type, max_length, min_length ))
RDR_ITEM(rdr_auth_type,(TSupSysEContext *context,TRdrInfoAuthType *authType,size_t *authSize),(context,authType,authSize))
RDR_ITEM(rdr_auth_challenge,(TSupSysEContext *context,TRdrLoginInfoType type,TRdrChallenge_class Class,TRdrChallenge_id id,const TRdrChallenge2folder *toFKC,TRdrChallenge2rdr *fromFKC ),(context,type,Class,id,toFKC,fromFKC ))
RDR_ITEM(rdr_auth_change,(TSupSysEContext *context,TRdrLoginInfoType type,TRdrChallenge_class Class,TRdrChallenge_id id,const TRdrChallenge2folder *toFKC,TRdrChallenge2rdr *fromFKC ),(context,type,Class,id,toFKC,fromFKC ))
RDR_ITEM(rdr_get_random, (TSupSysEContext *context, size_t *length, BYTE *out ),(context,length, out))
RDR_ITEM(rdr_uec_set_pin1, (TSupSysEContext *context, const TCHAR  *pin ),(context, pin))
RDR_ITEM(rdr_uec_open_data, ( TSupSysEContext *context,  unsigned short data_id ),( context, data_id ))
RDR_ITEM(rdr_uec_close_data, ( TSupSysEContext *context ), (context))
RDR_ITEM(rdr_uec_read_data, ( TSupSysEContext *context, unsigned int is_binary, size_t pos, size_t size, unsigned int read_param, void *buffer, size_t *read_len ),( context, is_binary, pos, size, read_param, buffer, read_len ))
RDR_ITEM(rdr_uec_write_data, ( TSupSysEContext *context, size_t pos, size_t size, const void *buffer, unsigned int is_binary, unsigned int write_param),( context, pos, size, buffer, is_binary, write_param))
RDR_ITEM(rdr_uec_change_pin1, (TSupSysEContext *context, const TCHAR  *pin ),(context, pin))
RDR_ITEM(rdr_set_auth_param, (TSupSysEContext *context,const TRdrFkcPoint *uQs,const TRdrFkcPoint *uQpw,const TRdrFkcSyncro *usyncro),(context,uQs,uQpw,usyncro))
RDR_ITEM(rdr_crypt_key_gen,(TSupSysEContext *context,const TRdrFkcPoint *uQs,const TRdrFkcPoint *uQpw,const TCHAR *tPIN ),(context,uQs,uQpw,tPIN ))
RDR_ITEM(rdr_crypt_key_set,(TSupSysEContext *context,const TRdrFkcPoint *uQs,const TRdrFkcPoint *uQpw,const TRdrFkcOrder *udfkc,const TRdrFkcSyncro *usyncro,const TCHAR *tPIN ),(context,uQs,uQpw,udfkc,usyncro,tPIN ))
RDR_ITEM(rdr_crypt_uec_key_set,(TSupSysEContext *context,const TRdrFkcOrder *d),(context,d))
RDR_ITEM(rdr_crypt_signature_1,(TSupSysEContext *context,const TRdrFkcOrder *e,TRdrFkcPoint *uR2, const TRdrFkcTrID TrId, const TRdrFkcTrNewID IsNewTr ),(context,e,uR2,TrId,IsNewTr ))
#if _DEBUG
RDR_ITEM(rdr_crypt_signature_1_debug,(TSupSysEContext *context,const TRdrFkcOrder *e,const TRdrFkcOrder *k2,TRdrFkcPoint *uR2, const TRdrFkcTrID TrId, const TRdrFkcTrNewID IsNewTr  ),(context,e,k2,uR2,TrId,IsNewTr))
#endif /*_DEBUG*/
RDR_ITEM(rdr_crypt_signature_2,(TSupSysEContext *context,const TRdrFkcOrder *ur,TRdrFkcOrder *us2, const TRdrFkcTrID TrId ),(context,ur,us2,TrId ))
RDR_ITEM(rdr_crypt_agreement_1,(TSupSysEContext *context,const TRdrFkcPoint *uQalpha,TRdrFkcPoint *uK2, const TRdrFkcTrID TrId, const TRdrFkcTrNewID IsNewTr),(context,uQalpha,uK2,TrId,IsNewTr))
RDR_ITEM(rdr_crypt_agreement, (TSupSysEContext *context,const TRdrFkcPoint *uQalpha,const TRdrFkcUKM * ukm,TRdrFkcOrder *key),(context,uQalpha,ukm,key))
RDR_ITEM(rdr_crypt_agreement_mask,(TSupSysEContext *context, const TRdrFkcPoint *uQalpha, TRdrFkcPoint *uDK2, TRdrFkcOrder *D),(context, uQalpha, uDK2, D))
RDR_ITEM(rdr_crypt_signature_uec,(TSupSysEContext *context,BYTE * hash,DWORD hash_len, BYTE * signature, DWORD * signature_len),(context, hash, hash_len, signature, signature_len))
RDR_ITEM(rdr_crypt_uec_key_gen,(TSupSysEContext *context, BYTE * pubKey),(context, pubKey)) 
RDR_ITEM(rdr_crypt_hash_init,(TSupSysEContext *context, unsigned int hash_algid, TRdrHashContext ** hash_ctx),(context,hash_algid,hash_ctx))
RDR_ITEM(rdr_crypt_hash_data,(TSupSysEContext *context,TRdrHashContext * hash_ctx,const void * data,size_t data_len,size_t * hashed_data_len),(context,hash_ctx,data,data_len,hashed_data_len))
RDR_ITEM(rdr_crypt_hash_getval,(TSupSysEContext *context,TRdrHashContext * hash_ctx,void * buffer,size_t * buffer_len),(context,hash_ctx,buffer,buffer_len))
RDR_ITEM(rdr_crypt_signature_hash_1,(TSupSysEContext *context, TRdrHashContext * hash_ctx, TRdrFkcPoint *uR2, const TRdrFkcTrID TrId, const TRdrFkcTrNewID IsNewTr),(context,hash_ctx,uR2,TrId,IsNewTr))
RDR_ITEM(rdr_crypt_hash_destroy,(TSupSysEContext *context, TRdrHashContext * hash_ctx),(context,hash_ctx))

#if !defined( _READER_RDR_VER_H )
#define _READER_RDR_VER_H

TSupErr info_versionsupport(
    TSupSysContext *context, TSupSysInfo *info );

#endif /* !defined( _READER_RDR_VER_H ) */

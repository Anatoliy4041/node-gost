/*
 * Copyright(C) 2000 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/****
 * $Id: tst_log.c 87410 2013-04-01 09:24:35Z borodin $
 *
 * ���������� ������ / ������ �������� ���������� (READER).
 *
 * ������� ������������ ������� ������������� ����������� � �����������
 *  ��������� �����������.
 *
 * �������:reader_test_login_*, reader_test_logout_*
 *
 * ������ ����������� �� define: 
 *
 * �����������: 
 *
 * ������������ �������������:
 *
 ****/

#include "tst_prj.h" /*+ Project (READER/RDR/TEST) include.
    include ���� ��� ������� (READER/RDR/TEST). +*/

/* ��������� / ������ ����� local machine. */
TSupErr reader_test_local_machine( 
    TSupSysEContext *context, 
    int flag )
{
    TSupErr code;

    if( flag )
    {
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Setting local machine flag...")));
	code = rdr_local_machine( context, flag );
        if( code )
	   return test_error( context, code );
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Local machine flag set successfully.")));
    }
    else
    {
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Setting current user flag...")));
	code = rdr_local_machine( context, flag );
        if( code )
	   return test_error( context, code );
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Current user flag set successfully.")));
    }

    return SUP_ERR_NO;
}

/*++++
 * ������� ������������ ������������� ��������.
 ++++*/
TSupErr reader_test_login( 
    TSupSysEContext *context,
    const TCHAR *passwd )
{
    TSupErr code;
    TRdrLoginInfoType type = RDR_LOGIN_INFO_UNKNOWN;
    size_t length = 0; /* ����� ������. */
    const TCHAR *cur_passwd = passwd;

    printf ("Login test in progress...\n");

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Login test in progress...")));

    code = rdr_passwd_length( context, &type, &length, NULL );
    if( code )
	return test_error( context, code );

    if( type != RDR_LOGIN_INFO_PASSWD
	&& type != RDR_LOGIN_INFO_NO )
	return test_error( context, SUP_ERR_PARAM );
    code = rdr_login( context, cur_passwd, NULL );

    if( code )
	return test_error( context, code );
    
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Login successful.")));
    printf ("Login successful.\n");
    return SUP_ERR_NO;
}

/*++++
 * ������� ������������ ������������� ��������.
 ++++*/
TSupErr reader_test_prime(
    TSupSysEContext *context,
    const TCHAR *passwd )
{
    TSupErr code;
    TRdrLoginInfoType type = RDR_LOGIN_INFO_PRIME_PASSWD;
    size_t length = 0; /* ����� ������. */
    const TCHAR *cur_passwd = passwd;

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Login test in progress...")));    

    code = rdr_passwd_length( context, &type, &length, NULL );
    if( code )
	return test_error( context, code );
    if( type != RDR_LOGIN_INFO_PRIME_PASSWD )
	return test_error( context, SUP_ERR_PARAM );
    
    code = rdr_prime( context, cur_passwd, NULL );
    if( code )
	return test_error( context, code );

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Login successful.")));    
    return SUP_ERR_NO;
}

/*++++
 * ������� ������������ ������������� ��������.
 ++++*/
TSupErr reader_test_logout( 
    TSupSysEContext *context ) /*+ (i) HANDLE �����������. +*/
/*+ 
 * ����������:
 *
 * SUP_ERR_NO, ��� ������� login
 *
 * SUP_ERR_MEMORY, ��� �������� ������.
 *
 * ������ logout.
 +*/
{
    TSupErr code;
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Logout test in progress...")));    
    
    code = rdr_logout( context );
    if( code )
	return test_error( context, code ); 

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Logout test successful.")));        
    return SUP_ERR_NO;
}

/* ������� ������������� � ��������. */
TSupErr reader_test_connect_carrier( 
    TSupSysEContext *context )
{
    TSupErr code;

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Connecting to carrier...")));    
    code = rdr_connect_carrier( context );
    if( code == RDR_ERR_FORMAT )
    {
	test_error( context, code ); 
	code = rdr_format_carrier( context );
    }
    if( code )
	return test_error( context, code ); 
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Connected to carrier successfully.")));    
    return SUP_ERR_NO;
}

/* ������� ������������ �� ��������. */
TSupErr reader_test_disconnect_carrier( 
    TSupSysEContext *context )
{
    TSupErr code;
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Disconnecting from carrier...")));    

    code = rdr_disconnect_carrier( context );
    if( code )
	return test_error( context, code ); 
    
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Disconnected from carrier successfully.")));    
    return SUP_ERR_NO;
}

static void printPoint (TRdrFkcPoint p)
{
    int i = 0;

    printf ("X = 0x( ");
    for (i = 0; i<SECRET_KEY_LEN; i++)
	printf ("%02X ", p.x[i]);
    printf (" )\nY = 0x(");
    for (i = 0; i<SECRET_KEY_LEN; i++)
	printf ("%02X ", p.y[i]);
    printf (")\n");
}

static void printSyncro (TRdrFkcSyncro x)
{
    int i = 0;

    printf ("0x(");
    for (i = 0; i<RDR_FKC_SYNCRO_SIZE; i++)
	printf ("%02X ", x.v[i]);
    printf (")");
}

static void printOrder (TRdrFkcOrder x)
{
    int i = 0;

    printf ("0x(");
    for (i = 0; i<SECRET_KEY_LEN; i++)
	printf ("%02X ", x.v[i]);
    printf (")");
}

TSupErr reader_test_fkc_set_key(TSupSysEContext *context, TCHAR * pin, BYTE * ElP, 
				BYTE *qs, const BYTE *d, LPBYTE syncro)
{
    TRdrFkcPoint Qs;
    TRdrFkcPoint QpW;
    TRdrFkcOrder dFKC;
    TRdrFkcSyncro rdr_sync;
    TSupErr code= SUP_ERR_NO;

    memcpy(Qs.x,qs,SECRET_KEY_LEN);
    memcpy(Qs.y,qs+SECRET_KEY_LEN,SECRET_KEY_LEN);
    memcpy(QpW.x,ElP,SECRET_KEY_LEN);
    memcpy(QpW.y,ElP+SECRET_KEY_LEN,SECRET_KEY_LEN);
    memcpy(rdr_sync.v,syncro,RDR_FKC_SYNCRO_SIZE);
    memcpy(dFKC.v,d,SECRET_KEY_LEN);
    printf ("fkc_set_key started\n");
    printf ("Qs: \n"); printPoint (Qs);
    printf ("QpW: \n"); printPoint (QpW);
    printf ("dFKC: \n"); printOrder (dFKC);
    printf ("\nsyncro: \n"); printSyncro (rdr_sync);
    printf ("\n");

    code = rdr_crypt_key_set(context,&Qs,&QpW,&dFKC,&rdr_sync,pin);
    if (code == SUP_ERR_NO) {
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Set key success.")));
    }
    printf ("fkc_set_key finished\n");
    return code;
}

TSupErr reader_test_fkc_gen_key(TSupSysEContext *context, TCHAR * pin, BYTE * ElP, BYTE *qs)
{
    TRdrFkcPoint Qs;
    TRdrFkcPoint QpW;
    TSupErr code= SUP_ERR_NO;

    memcpy(Qs.x,qs,SECRET_KEY_LEN);
    memcpy(Qs.y,qs+SECRET_KEY_LEN,SECRET_KEY_LEN);
    memcpy(QpW.x,ElP,SECRET_KEY_LEN);
    memcpy(QpW.y,ElP+SECRET_KEY_LEN,SECRET_KEY_LEN);
    printf ("fkc_gen_key started\n");
    printf ("Qs: \n"); printPoint (Qs);
    printf ("QpW: \n"); printPoint (QpW);

    code = rdr_crypt_key_gen(context,&Qs,&QpW,pin);

    if (code == SUP_ERR_NO) {
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Gen key success.")));
    }
    printf ("fkc_gen_key finished\n");
    return code;
}

static void setNameOfUnfinity(TCHAR * dest, TRdrFkcEKEChallenge_id id) 
{
    
    switch (id) 
    {
    case TRECi_syncro:
	_tcscpy(dest,_TEXT("read syncro"));
	break;
    case TRECi_syncroBIS:
	_tcscpy(dest,_TEXT("write syncro"));
	break;
    case TRECi_deltaBIS:
	_tcscpy(dest,_TEXT("write delta"));
	break;
    case TRECi_Qpw:
	_tcscpy(dest,_TEXT("write Qpw"));
	break;
    case TRECi_Qfkc:
	_tcscpy(dest,_TEXT("read Qfkc"));
	break;
    case TRECi_Qs:
	_tcscpy(dest,_TEXT("write Qs"));
	break;
    }
}

TSupErr reader_test_fkc_signature1(TSupSysEContext *context, BYTE * hash, BYTE * param, TRdrFkcTrID ident) 
{
    TSupErr code= SUP_ERR_NO;

    TRdrFkcOrder e;
    TRdrFkcPoint ur;

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Signature-1 started...")));
    printf ("Signature-1 started...\n");

    memcpy(e.v,hash,SECRET_KEY_LEN);
    printf ("TrId = 0x%08X\n", ident); 
    printf ("e:"); printOrder(e); printf ("\n");

    code = rdr_crypt_signature_1(context,&e,&ur, ident, FKC_TRANSACTION_IS_NEW);
    if (code == RDR_ERR_BLOCK) {
	printf ("UR:"); printPoint(ur);
	printf ("\nSignature-1 finished.\n");
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Signature-1 finished.")));
    }
    memcpy(param,ur.x,SECRET_KEY_LEN);
    memcpy(param+SECRET_KEY_LEN,ur.y,SECRET_KEY_LEN);
    
    return code;
}

TSupErr reader_test_fkc_signature2(TSupSysEContext *context, BYTE * inp, BYTE * outp, TRdrFkcTrID ident) 
{
    TSupErr code= SUP_ERR_NO;

    TRdrFkcOrder r;
    TRdrFkcOrder ur;

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Signature-2 started...")));
    printf ("Signature-2 started...\n");

    memcpy(r.v,inp,SECRET_KEY_LEN);

    printf ("TrId = 0x%08X\n", ident); 
    printf ("R:\n"); printOrder(r); printf("\n");

    code = rdr_crypt_signature_2(context,&r,&ur,ident);

    memcpy(outp,ur.v,SECRET_KEY_LEN);

    if (code == SUP_ERR_NO) {
	printf ("UR:\n"); printOrder(ur);
	printf ("\nSignature-2 finished.\n");
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Signature-2 finished.")));
    }
    return code;
}

TSupErr reader_test_fkc_agreement(TSupSysEContext *context, BYTE * qA, BYTE * K2, TRdrFkcTrID ident)  
{
    TSupErr code= SUP_ERR_NO;

    TRdrFkcPoint qAlfa;
    TRdrFkcPoint kOut;

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "DH started.")));
    printf ("DH started.\n");

    memcpy(qAlfa.x,qA,SECRET_KEY_LEN);
    memcpy(qAlfa.y,qA+SECRET_KEY_LEN,SECRET_KEY_LEN);
    printf ("TrId = 0x%08X\n", ident); 
    printf ("Qa:\n"); printPoint(qAlfa);
    
    code = rdr_crypt_agreement_1(context,&qAlfa,&kOut, ident, FKC_TRANSACTION_IS_NEW);
    if (code == SUP_ERR_NO) {
	printf ("kOut:\n"); printPoint(kOut);
	printf ("DH finished.\n");
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "DH finished.")));
    } else {
	printf ("DH failed.\n");
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "DH failed.")));
    }
    memcpy(K2,kOut.x,SECRET_KEY_LEN);
    memcpy(K2+SECRET_KEY_LEN,kOut.y,SECRET_KEY_LEN);

    return code;

}



TSupErr reader_test_fkc_auth_change_first(TSupSysEContext *context, 
					     TRdrLoginInfoType type, 
					     TRdrFkcEKEChallenge_id id, 
					     BYTE * u1, BYTE *u2, TRdrFkcTrID ident, TRdrFkcTrNewID newID)
{
    TSupErr code= SUP_ERR_NO;

    TRdrFkcEKEChallengeFirst2fkc toFKC;
    TRdrFkcEKEChallengeFirst2csp toCSP;
    //const TRdrChallenge2folder *toFKCunt = CH2P(TRdrFkcEKEChallengeFirst2fkc, &toFKC);
    //TRdrChallenge2rdr *toCSPunt = CH2P(TRdrFkcEKEChallengeFirst2csp, &toCSP);
    TCHAR unf [(2*SECRET_KEY_LEN)];

        
    setNameOfUnfinity(unf, id);
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Change First Step: %s..."), unf));
    _tprintf (_TEXT("Change First Step: %s..."), unf);

    toFKC.size_of = sizeof(toFKC);
    toFKC.TrId = ident;
    toFKC.IsNewTr = newID;
    memcpy(toFKC.u1.x,u1,SECRET_KEY_LEN);
    memcpy(toFKC.u1.y,u1+SECRET_KEY_LEN,SECRET_KEY_LEN);

    toCSP.size_of = sizeof(toCSP);
    printf ("u1:\n"); printPoint(toFKC.u1);
    printf ("TrId = 0x%08X\n", toFKC.TrId); 
    printf ("IsNewTr = %d\n", toFKC.IsNewTr); 

    code = rdr_auth_change (context, type, TRECc_first, id, 
	CH2P(TRdrFkcEKEChallengeFirst2fkc, &toFKC), 
	CH2P(TRdrFkcEKEChallengeFirst2csp, &toCSP));

    memcpy(u2,toCSP.u2.x,SECRET_KEY_LEN);
    memcpy(u2+SECRET_KEY_LEN,toCSP.u2.y,SECRET_KEY_LEN);

    if (code == RDR_ERR_BLOCK) {
	printf ("u2:\n"); printPoint(toCSP.u2);
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Change First Step finished: %s."), unf));
	_tprintf (_TEXT("Change First Step finished: %s."), unf);
    }
    return code;
}

TSupErr reader_test_fkc_auth_change_commit(TSupSysEContext *context, 
					     TRdrLoginInfoType type, 
					     TRdrFkcEKEChallenge_id id,
					     BYTE * Qs, TRdrFkcTrID ident, TRdrFkcCommitMask mask)
{
    TSupErr code= SUP_ERR_NO;
    TCHAR pin [] = _TEXT("wonderfull password");

    TRdrFkcEKEChallengeChangeMask2fkc toFKC;
    toFKC.size_of = sizeof(toFKC);
    toFKC.TrId = ident;
    toFKC.savemask = mask;

    printf("Change commite started\n");

    memcpy(toFKC.uQs.x,Qs,SECRET_KEY_LEN);
    memcpy(toFKC.uQs.y,Qs+SECRET_KEY_LEN,SECRET_KEY_LEN);
    _tcscpy((TCHAR*)toFKC.utf8PIN,pin);

    printf ("TrId = 0x%08X\n", toFKC.TrId); 
    printf ("Qs:\n"); printPoint(toFKC.uQs);
    printf ("mask = %04x:\n", toFKC.savemask);
    
    code = rdr_auth_change (context, type, TRECc_commit, id, CH2P(TRdrFkcEKEChallengeChangeMask2fkc, &toFKC), NULL);
    if (code != SUP_ERR_NO)
	goto done;
    printf("Change commit finished\n");
done:
    return code;
}


TSupErr reader_test_fkc_auth_change_second(TSupSysEContext *context, 
					     TRdrLoginInfoType type, 
					     TRdrFkcEKEChallenge_id id, 
					     DWORD *rdr_sync,
					     BYTE * u3, TRdrFkcTrID ident)
{
    TSupErr code= SUP_ERR_NO;
    TCHAR unf [(2*SECRET_KEY_LEN)];

        
    setNameOfUnfinity(unf, id);
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Change Second Step: %s..."), unf));
    //printf ("Change Second Step: %S...", unf);

    switch (id) {
	case TRECi_syncroBIS:
	    {
		TRdrFkcEKEChallengeWriteSyncro2fkc toFKC;
		TRdrFkcEKEChallengeWriteSyncro2csp toCSP;
		toFKC.size_of = sizeof(toFKC);
		toFKC.uiS1 = (USHORT)*rdr_sync;
		toFKC.TrId = ident;
		printf ("Sygma1 = 0x%04X\n", toFKC.uiS1); 
		printf ("TrId = 0x%08X\n", toFKC.TrId); 
		memcpy(toFKC.u3.v,u3,RDR_FKC_SYNCRO_SIZE);
		printf ("u3:\n"); printSyncro(toFKC.u3); printf ("\n");
		toCSP.size_of = sizeof(toCSP);
		code = rdr_auth_change (context, type, TRECc_second, id, 
		    CH2P(TRdrFkcEKEChallengeWriteSyncro2fkc, &toFKC), 
		    CH2P(TRdrFkcEKEChallengeWriteSyncro2csp, &toCSP));
		if (code == RDR_ERR_BLOCK ) {
		    *rdr_sync = toCSP.uiS2;
		    printf ("Sygma2 = 0x%04X\n", toCSP.uiS2); 
		}
	    }
	    break;
	case TRECi_deltaBIS:
	    {
		TRdrFkcEKEChallengeWriteDelta2fkc toFKC;
		toFKC.size_of = sizeof(TRdrFkcEKEChallengeWriteDelta2fkc);
		toFKC.TrId = ident;
		
		memcpy(toFKC.u3.v,u3,SECRET_KEY_LEN);
		printf ("TrId = 0x%08X\n", toFKC.TrId); 
		printf ("u3:\n"); printOrder(toFKC.u3); printf ("\n");
		code = rdr_auth_change (context, type, TRECc_second, id, 
		    CH2P(TRdrFkcEKEChallengeWriteDelta2fkc, &toFKC), NULL);
	    }
	    break;
	case TRECi_Qpw:
	    {
		TRdrFkcEKEChallengeWriteQPW2fkc toFKC;
		toFKC.size_of = sizeof(toFKC);
		toFKC.TrId = ident;
		memcpy(toFKC.u3.x,u3,SECRET_KEY_LEN);
		memcpy(toFKC.u3.y,u3+SECRET_KEY_LEN,SECRET_KEY_LEN);
		printf ("TrId = 0x%08X\n", toFKC.TrId); 
		printf ("u3:\n"); printPoint(toFKC.u3); 
		code = rdr_auth_change (context, type, TRECc_second, id, 
		    CH2P(TRdrFkcEKEChallengeWriteQPW2fkc, &toFKC), NULL);
	    }
	    break;
	case TRECi_Qs:
	case TRECi_syncro: 
	case TRECi_Qfkc:
	    break;
    }
    if (code == SUP_ERR_NO)
    {
	printf ("Change Second Step finished: %s.", unf);
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Change Second Step finished: %s."), unf));
    } 
    return code;
}




TSupErr reader_test_fkc_auth_challenge_first(TSupSysEContext *context, 
					     TRdrLoginInfoType type, 
					     TRdrFkcEKEChallenge_id id, 
					     BYTE * u1, BYTE *u2, TRdrFkcTrID ident, TRdrFkcTrNewID newID)
{
    TSupErr code= SUP_ERR_NO;

    TRdrFkcEKEChallengeFirst2fkc toFKC;
    TRdrFkcEKEChallengeFirst2csp toCSP;
    //const TRdrChallenge2folder *toFKCunt = CH2P(TRdrFkcEKEChallengeFirst2fkc, &toFKC);
    //TRdrChallenge2rdr *toCSPunt = CH2P(TRdrFkcEKEChallengeFirst2csp, &toCSP);
    TCHAR unf [(2*SECRET_KEY_LEN)];

        
    setNameOfUnfinity(unf, id);
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Auth First Step: %s..."), unf));
    _tprintf (_TEXT("Auth First Step: %s..."), unf);

    toFKC.size_of = sizeof(toFKC);
    memcpy(toFKC.u1.x,u1,SECRET_KEY_LEN);
    memcpy(toFKC.u1.y,u1+SECRET_KEY_LEN,SECRET_KEY_LEN);
    toFKC.TrId = ident;
    toFKC.IsNewTr = newID;

    printf ("u1:\n"); printPoint(toFKC.u1);
    printf ("TrId = 0x%08X\n", toFKC.TrId); 
    printf ("IsNewTr = %d\n", toFKC.IsNewTr); 

    toCSP.size_of = sizeof(toCSP);

    code = rdr_auth_challenge (context, type, TRECc_first, id, 
	CH2P(TRdrFkcEKEChallengeFirst2fkc, &toFKC), 
	CH2P(TRdrFkcEKEChallengeFirst2csp, &toCSP));

    if (code == RDR_ERR_BLOCK) {
	printf ("u2:\n"); printPoint(toCSP.u2);
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Auth First Step finished: %s."), unf));
	_tprintf (_TEXT("Auth First Step finished: %s."), unf);
    }
    memcpy(u2,toCSP.u2.x,SECRET_KEY_LEN);
    memcpy(u2+SECRET_KEY_LEN,toCSP.u2.y,SECRET_KEY_LEN);
    return code;
}


TSupErr reader_test_fkc_auth_challenge_second(TSupSysEContext *context, 
					     TRdrLoginInfoType type, 
					     TRdrFkcEKEChallenge_id id, 
					     DWORD *rdr_sync,
					     BYTE * u3, TRdrFkcTrID ident)
{
    TSupErr code= SUP_ERR_NO;
    TCHAR unf [(2*SECRET_KEY_LEN)];

        
    setNameOfUnfinity(unf, id);
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Auth Second Step: %s..."), unf));
    _tprintf (_TEXT("Auth Second Step: %s..."), unf);

    switch (id) {
	case TRECi_syncro: 
	    {
		TRdrFkcEKEChallengeReadSyncro2fkc toFKC;
		TRdrFkcEKEChallengeReadSyncro2csp toCSP;
		toFKC.size_of = sizeof(toFKC);
		toFKC.uiS1 = (USHORT)*rdr_sync;  // TODO: ������ ����� �������������� ����
		toFKC.TrId = ident;
		printf ("Sygma1 = 0x%04X\n", toFKC.uiS1); 
		printf ("TrId = 0x%08X\n", toFKC.TrId); 
		toCSP.size_of = sizeof(toCSP);
		code = rdr_auth_challenge (context, type, TRECc_second, id, 
		    CH2P(TRdrFkcEKEChallengeReadSyncro2fkc, &toFKC), 
		    CH2P(TRdrFkcEKEChallengeReadSyncro2csp, &toCSP));
		if (code == SUP_ERR_NO) {
		    *rdr_sync = toCSP.uiS2;
		    memcpy(u3,toCSP.u3.v,RDR_FKC_SYNCRO_SIZE);
		    printf ("Sygma2 = 0x%04X\n", toCSP.uiS2); 
		    printf ("u3:\n"); printSyncro(toCSP.u3); printf ("\n");
		}
	    }
	    break;
	case TRECi_Qfkc:
	    {
		TRdrFkcEKEChallengeReadQFKC2csp toCSP;
		TRdrFkcEKEChallengeReadQFKC2fkc toFKC;
		toCSP.size_of = sizeof(toCSP);
		toFKC.TrId = ident;
		toFKC.size_of = sizeof(toFKC);
		printf ("TrId = 0x%08X\n", toFKC.TrId); 
		code = rdr_auth_challenge (context, type, TRECc_second, id, CH2P(TRdrFkcEKEChallengeReadQFKC2fkc,&toFKC), CH2P(TRdrFkcEKEChallengeReadQFKC2csp, &toCSP));
		memcpy(u3,toCSP.u3.x,SECRET_KEY_LEN);
		memcpy(u3+SECRET_KEY_LEN,toCSP.u3.y,SECRET_KEY_LEN);
		printf ("u3:\n"); printPoint(toCSP.u3);
	    }
	    break;
	case TRECi_deltaBIS:
	case TRECi_Qpw:
	case TRECi_Qs:
	case TRECi_syncroBIS:
	    break;
    }
    if (code == SUP_ERR_NO)
    {
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Auth Second Step finished: %s."), unf));
	_tprintf (_TEXT("Auth Second Step finished: %s."), unf);
    } 
    return code;
}


TSupErr reader_test_fkc_get_param_password(TSupSysEContext *context, BOOL *need, TCHAR *dst) {
    size_t size;
    TRdrFkcFolderPasswordParam pPar;
    TRdrFkcFolderDisablePasswordParam dPPar;
    TSupErr code= SUP_ERR_NO;

    printf ("GetParam for password\n");
    printf ("rdr_folder_get_param, id = %d\n", TCEP_disablePassword);

    size = sizeof(dPPar);
    dPPar.size_of = size;
    code = rdr_folder_get_param(context,TCEP_disablePassword,CH2P(TRdrFkcFolderDisablePasswordParam,&dPPar),&size);
    if (code) goto done;
    if (dPPar.bDisablePassword) {
#ifdef PRINT_COMMENT	
	printf("Password disabled\n");
#endif
	*need = FALSE;
    }
    else
    {
	*need = TRUE;
#ifdef PRINT_COMMENT	
	printf("Password enabled\n");
#endif	
	size = sizeof(pPar);
	pPar.size_of = size;
	printf ("rdr_folder_get_param, id = %d\n", TCEP_password);
	code = rdr_folder_get_param(context,TCEP_password,CH2P(TRdrFkcFolderPasswordParam,&pPar),&size);
	if (code) goto done;
	//printf ("rdr_folder_get_param, password = %S\n", pPar.tPassword);

#ifdef PRINT_COMMENT	
	_tprintf(_TEXT("Password = %s\n"),pPar.tPassword);
#endif
	_tcscpy(dst, pPar.tPassword);
    }

    printf ("GetParam for password done\n");
done:
    return code;
}


TSupErr reader_test_fkc_get_param(TSupSysEContext *context, BOOL *abletoset) {
    size_t size;
    TRdrFkcFolderPasswordParam pPar;
    TRdrFkcFolderDisablePasswordParam dPPar;
    TRdrFkcFolderNewKeysParam nkPar;
    TRdrFkcFolderCountersParam couPar;
    TRdrFkcFolderOID0Param oidPar;
    TSupErr code= SUP_ERR_NO;



    size = sizeof(dPPar);
    dPPar.size_of = size;
    	    
    printf ("fkc_get_param\n");
    printf ("ID = %d\n", TCEP_disablePassword);

    code = rdr_folder_get_param(context,TCEP_disablePassword,CH2P(TRdrFkcFolderDisablePasswordParam,&dPPar),&size);
    if (code) goto done;
    if (dPPar.bDisablePassword) {
#ifdef PRINT_COMMENT	
	printf("Password disabled\n");
#endif
    }
    else
    {
#ifdef PRINT_COMMENT	
	printf("Password enabled\n");
#endif	
	size = sizeof(pPar);
	pPar.size_of = size;
	printf ("fkc_get_param\n");
	printf ("ID = %d\n", TCEP_password);
	code = rdr_folder_get_param(context,TCEP_password,CH2P(TRdrFkcFolderPasswordParam,&pPar),&size);
	if (code) goto done;
#ifdef PRINT_COMMENT	
	_tprintf(_TEXT("Password = %s\n"),pPar.tPassword);
#endif
    }
    size = sizeof(nkPar);
    nkPar.size_of = size;
    printf ("fkc_get_param\n");
    printf ("ID = %d\n", TCEP_newKeys);
    code = rdr_folder_get_param(context,TCEP_newKeys,CH2P(TRdrFkcFolderNewKeysParam,&nkPar),&size);
    if (code) goto done;

#ifdef PRINT_COMMENT	
    if (nkPar.bEnableInitKeys) printf("Is able to create keys\n"); else printf ("Can't create keys\n");
    if (nkPar.bEnableSetKeys) printf("Is able to set keys\n"); else printf ("Can't set keys\n");
#endif

    *abletoset = nkPar.bEnableSetKeys;

    size = sizeof(couPar);
    couPar.size_of = size;
    printf ("fkc_get_param\n");
    printf ("ID = %d\n", TCEP_counters);
    code = rdr_folder_get_param(context,TCEP_counters,CH2P(TRdrFkcFolderCountersParam,&couPar),&size);
    if (code) goto done;

//#ifdef PRINT_COMMENT	
//    DbTrace(DB_TRACE, (FTEXT(support_context_io, "\t Counters:")));
//    DbTrace(DB_TRACE, (FTEXT(support_context_io, "\t\t DH = %u"), couPar.initCounters[TRIFc_DH]));
//    DbTrace(DB_TRACE, (FTEXT(support_context_io, "\t\t SIG = %u"), couPar.initCounters[TRIFc_Sign]));
//    DbTrace(DB_TRACE, (FTEXT(support_context_io, "\t\t EKE = %u"), couPar.initCounters[TRIFc_EKE]));
//    DbTrace(DB_TRACE, (FTEXT(support_context_io, "\t\t SFLS = %u"), couPar.initCounters[TRIFc_cfail]));
//    DbTrace(DB_TRACE, (FTEXT(support_context_io, "\t\t FLS = %u"), couPar.initCounters[TRIFc_fail]));
//#endif
    size = sizeof(oidPar);
    oidPar.size_of = size;
    printf ("fkc_get_param\n");
    printf ("ID = %d\n", TCEP_oid0);
    code = rdr_folder_get_param(context,TCEP_oid0,CH2P(TRdrFkcFolderOID0Param, &oidPar),&size);
    if (code) goto done;

#ifdef PRINT_COMMENT	
    _tprintf(_TEXT("oid0 = %s\n"),oidPar.tOID0);
#endif
    printf ("GetParam done\n");
done:
    return code;
}

TSupErr reader_test_fkc_set_param(TSupSysEContext *context, TCHAR *newPass) {
    TRdrFkcFolderPasswordParam pPar;
    TRdrFkcFolderDisablePasswordParam dPPar;
    TSupErr code= SUP_ERR_NO;

    dPPar.size_of = sizeof(dPPar);
    dPPar.bDisablePassword = FALSE;
    dPPar.paramID = TCEP_disablePassword;
        
    printf ("SetParam\n");
    //printf ("DisablePassword = FALSE, New Password = %S\n", newPass);

    code = rdr_folder_set_param(context,CH2P(TRdrFkcFolderDisablePasswordParam,&dPPar));
    if (code) goto done;
    pPar.size_of = sizeof(pPar);
#ifdef PRINT_COMMENT	
    _tcscpy(pPar.tPassword,_TEXT("passwordword"));
#endif
    pPar.paramID = TCEP_password;
    _tcscpy((TCHAR*)pPar.tPassword,newPass);
    code = rdr_folder_set_param(context,CH2P(TRdrFkcFolderPasswordParam,&pPar));
    if (code) goto done;

    printf ("SetParam done\n");
done:
    return code;
}


//_RDR_DECL TSupErr rdr_folder_set_param(		// TODO: doc
//    TSupSysEContext * context,
//    const TRdrFolderParamValue *paramValue );


TSupErr reader_test_fkc_set_fname(TSupSysEContext *context, TCHAR * newname) 
{
    TSupErr code= SUP_ERR_NO;
    //printf ("FriendlyName set. FN = %S\n", newname);
    code = rdr_friendly_name_set(context, newname);
    printf ("FriendlyName set done\n");
    return code;
}


TSupErr reader_test_fkc_folder_create(
    TSupSysEContext *context,
    const TCHAR *folder,
    DWORD oid,
    BOOL enableDH)
{
    TSupErr code;
    TrdrInfoFolderOpenEx_fkc_param params;

    params.size_of = sizeof(TrdrInfoFolderOpenEx_fkc_param);
    params.bEnableDH = enableDH;
    params.uiIDg = oid;

    //printf ("Creating FKC folder %S\n", folder);
    printf ("\tOID = %d\n", oid);
    printf ("\tenableDH = %d\n", enableDH);

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Creating FKC folder...")));    

    code = rdr_folder_open_ex( context, _TEXT( "w" ), folder, CH2P(TrdrInfoFolderOpenEx_fkc_param,&params ));
    if (code!=SUP_ERR_NO) {
	return code;
    }
    printf ("Creating FKC folder success\n");
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Creating FKC folder success.")));    
    return code;
}


TSupErr reader_test_folder_create(
    TSupSysEContext *context,
    const TCHAR *folder )
{
    TSupErr code;
    TCHAR *real_name;
    TRdrFolderEnumContext *enum_ctx;
    size_t folder_length;

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Creating folder...")));    

    code = rdr_folder_enum_open( context, &enum_ctx, &folder_length,
	folder, RDR_FOLDER_ENUM_FLAG_NEW );
    if( code )
	return test_error( context, code );
    real_name = malloc( ( folder_length + 1 ) * sizeof( TCHAR ) );
    if( real_name == NULL )
    {
	rdr_folder_enum_close( enum_ctx );
	return test_error( context, code );
    }
    code = RDR_ERR_FILE_EXIST;
    while( code == RDR_ERR_FILE_EXIST )
    {
	code = rdr_folder_enum_next( enum_ctx, real_name );
	if( code )
	{
	    free( real_name );
	    rdr_folder_enum_close( enum_ctx );
	    return test_error( context, code );
	}
	code = rdr_folder_open( context, _TEXT( "w" ), real_name );
    }
    free( real_name );
    rdr_folder_enum_close( enum_ctx );
    if( code )
	return test_error( context, code ); 

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Open folder success.")));    
    return SUP_ERR_NO;
}

TSupErr reader_test_fkc_folder_open(
    TSupSysEContext *context,
    const TCHAR *folder, BOOL enableDH)
{
    TSupErr code;

    UNUSED(enableDH);
    //TrdrInfoFolderOpenEx_fkc_param params;

    //params.size_of = sizeof(TrdrInfoFolderOpenEx_fkc_param);
    //params.bEnableDH = enableDH;
    //params.uiIDg = RDR_FKC_IDG_CP_OPTIONAL_PARAMSET;

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Opening FKC folder...")));    
    //printf ("Opening FKC folder %S\n", folder);
    
    code = rdr_folder_open( context, _TEXT( "r" ), folder);

    if (code == SUP_ERR_NO) {
	printf ("Opening FKC folder success\n");
	DbTrace(DB_TRACE, (FTEXT(support_context_io, "Opening FKC folder success.")));
    }
    return code;
}


/* ������� ������������ �������� �����. */
TSupErr reader_test_folder_open( 
    TSupSysEContext *context,
    const TCHAR *folder )
{
    TSupErr code;
    printf ("Open (read) folder\n");
 //   if (folder)
	//printf ("folder = %S\n", folder);
 //   else
	//printf ("folder = NULL\n");

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Opening folder...")));    
    
    code = rdr_folder_open( context, _TEXT( "r" ), folder );
    if( code )
	return test_error( context, code ); 
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Open folder success.")));    
    printf ("Open folder success\n");

    return SUP_ERR_NO;
}

/* ������������ �������� �����. */
TSupErr reader_test_folder_close( 
    TSupSysEContext *context )
{
    TSupErr code;
    printf ("Closing folder...\n");    
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Closing folder...")));    
    
    code = rdr_folder_close( context );
    if( code )
	return test_error( context, code ); 

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Folder closed successfully.")));    
    printf ("Folder closed successfully\n");    
    
    return SUP_ERR_NO;
}

TSupErr reader_test_folder_enum(
    const TSupSysEContext *context )
{
    TSupErr code;
    TRdrFolderEnumContext *enum_ctx;
    size_t folder_len;
    TCHAR *cur_folder;

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Enumerating folders...")));    
    printf ("Enumerating folders started \n");
    
    code = rdr_folder_enum_open( context, &enum_ctx, &folder_len, NULL, 0 );
    if( code )
	return test_error( context, code ); 
    cur_folder = malloc( ( folder_len + 1 ) * sizeof( TCHAR ) );
    if( !cur_folder )
    {
	rdr_folder_enum_close( enum_ctx );
	return test_error( context, SUP_ERR_MEMORY );
    }
    code = rdr_folder_enum_next( enum_ctx, cur_folder );
    while( !code )
    {
	//printf ("folder =  %S\n", cur_folder);
        DbTrace(DB_TRACE, (FTEXT(support_context_io, "%s"), cur_folder));    	
	code = rdr_folder_enum_next( enum_ctx, cur_folder );
    }
    free( cur_folder );
    if( code != RDR_ERR_FILE_NOT_FOUND )
    {
	rdr_folder_enum_close( enum_ctx );
	return test_error( context, code );
    }
    code = rdr_folder_enum_close( enum_ctx );
    if( code )
	return test_error( context, code );

    printf ("Enumerating folders finished \n");
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Enumerating folders success.")));    	    
    return SUP_ERR_NO;
}

/* ������� ������������. */
TSupErr reader_test_lock( TSupSysEContext *context)
{
    TSupErr code;

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Locking...")));    
        
    printf ("rdr_lock\n");
    code = rdr_lock( context );
    if( code )
	return test_error( context, code ); 
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Lock success.")));    
    return SUP_ERR_NO;
}
/* ������� ���������������. */
TSupErr reader_test_unlock( TSupSysEContext *context)
{
    TSupErr code;

    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Unlocking...")));    
    
    printf ("rdr_unlock\n");
    code = rdr_unlock( context );
    if( code )
	return test_error( context, code ); 
    DbTrace(DB_TRACE, (FTEXT(support_context_io, "Unlock success.")));    
    return SUP_ERR_NO;
}
/*+ end of file:$Id: tst_log.c 87410 2013-04-01 09:24:35Z borodin $ +*/

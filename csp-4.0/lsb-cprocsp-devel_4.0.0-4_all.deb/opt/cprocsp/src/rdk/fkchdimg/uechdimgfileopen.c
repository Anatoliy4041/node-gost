#include "fkchdimgprj.h"

TSupErr uechdimg_file_open( TSupSysContext *context, TSupSysInfo *info )
{
    TReaderInfoOpen *inf = (TReaderInfoOpen*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;
    TSupErr code;
    size_t real_file_len = 0;

    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );
    SUPSYS_PRE_INFO( info, TReaderInfoOpen );
    SUPSYS_PRE_READ_PTRS( inf->mode, sizeof( TReaderInfoOpenFlags ) );
    SUPSYS_PRE( inf->mode_bits >= READER_MODEFLAG_BITS );
    SUPSYS_PRE( inf->mode );
    SUPSYS_PRE( inf->num < USHRT_MAX && inf->num > 0 );

    if (!_tcscmp(inf->name.text,_TEXT("name.key"))) {
	ctx->file_length = (DWORD) CF_NAME2_SIZE;
	ctx->path = ctx->info_path;
	inf->num = 7;	
    }
    else if (!_tcscmp(inf->name.text,_TEXT("header.key"))) {
	ctx->file_length = (DWORD) CF_HEAD2_SIZE;
	ctx->path = ctx->header_path;
	inf->num = 4;
    }
    else 
	return SUP_ERR_PARAM;

    ctx->file_id = (BYTE)inf->num;

    if (!inf->mode->o_write) {
	code = support_registry_get_hex(ctx->path, &real_file_len, NULL);
	if (code)
	    return RDR_ERR_FILE_NOT_FOUND;

	ctx->file = malloc (real_file_len);
	if (!ctx->file) 
	    return SUP_ERR_MEMORY;

	code = support_registry_get_hex(ctx->path, &real_file_len, ctx->file);
	if (code) {
	    if (ctx->file) 
		free(ctx->file);
	    return RDR_ERR_FILE_NOT_FOUND;
	}
    }
    else {
	ctx->file = malloc (ctx->file_length);
	if (!ctx->file) 
	    return SUP_ERR_MEMORY;
	memset (ctx->file, 0, ctx->file_length);
    }
    inf->size_of = sizeof( TReaderInfoOpen );
    return SUP_ERR_NO;
}

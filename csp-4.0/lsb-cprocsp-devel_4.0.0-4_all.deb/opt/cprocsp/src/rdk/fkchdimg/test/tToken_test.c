#include "tst12prj.h" /*+ Project (READER/FAT12/TEST) include.
    ������ include ���� ��� ������� (READER/FAT12/TEST). +*/

extern const BYTE SaltPublic[5][3][PUBLICBLOBLEN];

static USHORT makeSygma2BE(USHORT s);
static USHORT makeSygma2LE(USHORT s);

typedef struct OtherSideKey_ {
    HCRYPTPROV prov;
    HCRYPTKEY key;
    LPBYTE pkey;
    DWORD pkeysize;
} OtherSideKey, *POtherSideKey;

static TRdrFkcEKEChallenge_id makeIDfromIndex(DWORD ind) {
    switch (ind)
    {
    case 0: return TRECi_syncro;
    case 1: return TRECi_syncroBIS;
    case 2: return TRECi_deltaBIS;
    case 3: return TRECi_Qpw;
    case 4: return TRECi_Qfkc;
    //�����������
    default: return TRECi_Qfkc;
    }

}

static void makeCounters(COUNTS *dest, TRdrFkcInfoCounters *src);

static TSupErr reader_test_fkc_auth_type(TSupSysEContext *context, void * pFKC_);
static TSupErr reader_test_fkc_get_counters(TSupSysEContext *context, void * pFKC_);

static void makePointFromBlob_t(BYTE *Point, BYTE *blob) 
{
    be2le_t(Point, blob+0x24, SECRET_KEY_LEN);
    be2le_t(Point+SECRET_KEY_LEN,blob+0x24+SECRET_KEY_LEN,SECRET_KEY_LEN);
}

static TSupErr reader_test_HEADER_CV_COMPARE (TSupSysEContext *context, LPTOKEN_CONTAINER pCSP)
{
    DWORD err =0;
    BYTE buf [16];

    err = reader_test_HEADER_GET( context, buf); 
    if(err) goto done;

    if (memcmp(buf,pCSP->controlvector,8)) {
	err = SUP_ERR_CANCEL;
	goto done;
    }

done:
    if (err) {
	printf ("Error in HEADER Control Vector Compare: %x\n", err);
    }
    return err;

}

static DWORD makeNewTransIdentificator (LPTOKEN_CONTAINER pCSP)
{
    if (!CryptGenRandom(pCSP->hContainer,4,(BYTE*)&pCSP->randidentificator))
	return GetLastError();
    return 0;
}

/*���� ������ ������!!!*/
static DWORD testTransaction(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP)
{
    TSupErr code= SUP_ERR_NO;
    TRdrFkcOrder r;
    TRdrFkcOrder ur;

    if (!CryptGenRandom(pCSP->hContainer,SECRET_KEY_LEN,r.v)) {
	printf ("Error in GenRandom");
	return SUP_ERR_CANCEL;
    }

    code = makeNewTransIdentificator (pCSP);
    if (code)
	return code;

    code = rdr_crypt_signature_2(ctx,&r,&ur,pCSP->randidentificator);
    if (code != RDR_ERR_FKC_TRANSACTION ) {
	printf("Wrong Error Code when signature2 after transaction break called: %x\n", code);
	return RDR_ERR_FKC_TRANSACTION;
    } else {
	printf ("Transaction break test finished succesfully\n");
	return SUP_ERR_NO;
    }
}

static DWORD testSign(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP, BYTE * data, DWORD datalen, BYTE * pbSignature)
{
    HCRYPTPROV hProv;
    HCRYPTHASH hHash;
    DWORD dwKeySpec;
    DWORD err =0, dwHashLen = SECRET_KEY_LEN, dwR1Len=sizeof(CRYPT_HASH_BLOB_EX*), dwSigLen=(2*SECRET_KEY_LEN);
    BYTE pbHashVal[SECRET_KEY_LEN];
    BYTE inverthash[SECRET_KEY_LEN];
    BYTE pbRsend[SECRET_KEY_LEN];
    BYTE pbR2[(2*SECRET_KEY_LEN)];
    BYTE pbSignature2send[SECRET_KEY_LEN];
    CRYPT_HASH_BLOB_EX dbR2, dbR, dbS2;

/*  CSP  */
    hProv = pCSP->hContainer;
    dwKeySpec = pCSP->dwKeySpec;

    err = reader_test_HEADER_CV_COMPARE (ctx, pCSP);
    if (err) goto done;
    if(!CryptCreateHash( hProv, CALG_GR3411, 0, 0, &hHash)) {
	err = GetLastError();
	goto done;
    }
    if(!CryptHashData( hHash, data, datalen, 0)) {
	err = GetLastError();
	goto done;
    }
        
    if(!CryptGetHashParam( hHash, HP_HASHVAL,(LPBYTE)pbHashVal,&dwHashLen,0)) {
	err = GetLastError();
	goto done;
    }
    /*le2be() -----*/
    be2le_t(inverthash,pbHashVal,dwHashLen);

    err = makeNewTransIdentificator(pCSP);
    if(err) goto done;

    err = reader_test_fkc_signature1(ctx,inverthash,pbR2,(TRdrFkcTrID)pCSP->randidentificator);
    if (err!=RDR_ERR_BLOCK)
	return err;

    be2le_t(dbR2.pbData,pbR2,SECRET_KEY_LEN);
    be2le_t(dbR2.pbData+SECRET_KEY_LEN,pbR2+SECRET_KEY_LEN,SECRET_KEY_LEN);

    dbR2.tPublicKeyParam.BlobHeader.aiKeyAlg = pCSP->dwKeySpec;
    dbR2.tPublicKeyParam.KeyParam.Magic = GR3410_1_MAGIC;
    dbR2.tPublicKeyParam.KeyParam.BitLen = sizeof(CRYPT_HASH_BLOB_EX)*8;
    dbR2.tPublicKeyParam.BlobHeader.bType = HASHPUBLICKEYEXBLOB;
    dbR2.tPublicKeyParam.BlobHeader.bVersion = BLOB_VERSION;

/*  CSP  */
    if (!CryptSetHashParam(hHash, HP_KEYSPEC_SIGN,(LPBYTE)&(pCSP->dwKeySpec),0)) {
	err = GetLastError();
	goto done;
    }

    if(!CryptSetHashParam( hHash, HP_R2_SIGN,(LPBYTE)&dbR2,0)) {
	err = GetLastError();
	goto done;
    }

    dwR1Len = sizeof(dbR);
    if(!CryptGetHashParam( hHash, HP_R_SIGN,(LPBYTE)&dbR,&dwR1Len,0)) { 
	err = GetLastError();
	goto done;
    }
    /* le2be() ---  */
    be2le_t(pbRsend,dbR.pbData,SECRET_KEY_LEN);
    err = reader_test_fkc_signature2(ctx,pbRsend,pbSignature2send,(TRdrFkcTrID)pCSP->randidentificator);
    if(err) goto done;

    {
	BYTE pbRsend_copy [SECRET_KEY_LEN];
	BYTE pbSignature2send_copy [SECRET_KEY_LEN];
	memcpy(pbRsend_copy, pbRsend, SECRET_KEY_LEN);


	err = reader_test_fkc_signature2(ctx,pbRsend_copy,pbSignature2send_copy,(TRdrFkcTrID)pCSP->randidentificator);
	if(err != SUP_ERR_CANCEL) 
	{
	    printf("Second call of fkc_signature2 is not wrong\n");
	    goto done;
	}
    }

    dbS2.tPublicKeyParam.BlobHeader.aiKeyAlg = pCSP->dwKeySpec;
    dbS2.tPublicKeyParam.KeyParam.Magic = GR3410_1_MAGIC;
    dbS2.tPublicKeyParam.KeyParam.BitLen = sizeof(CRYPT_HASH_BLOB_EX)*8;
    dbS2.tPublicKeyParam.BlobHeader.bType = HASHPUBLICKEYEXBLOB;
    dbS2.tPublicKeyParam.BlobHeader.bVersion = BLOB_VERSION;
    be2le_t(dbS2.pbData,pbSignature2send,SECRET_KEY_LEN);
    /*be2le() -----*/
    if(!CryptSetHashParam( hHash, HP_S2_SIGN,(LPBYTE)&dbS2,0)) {
	err = GetLastError();
	goto done;
    }
    if(!CryptSignHash( hHash, dwKeySpec, NULL, 0, pbSignature, &dwSigLen)) {
	err = GetLastError();
	printf("Error %lx during CryptSignHash!\n", (unsigned long)err);
	goto done;
    }
    CryptDestroyHash(hHash);
    return 0;
done:
  return err;
}

DWORD loginToNull(TSupSysEContext * ctx, BYTE defar[128], DWORD first) 
{
    DWORD err;
    BOOL isNeed;
    TCHAR passs[160];
    BYTE dupar[128];

    err = reader_test_fkc_get_param_password(ctx, &isNeed, passs);
    if( err ) goto done;
    err = reader_test_folder_open(ctx, NULL); 
    if( err ) goto done;
    if (!first) {
	err = reader_test_DEF_READ(ctx, dupar);
	if( err ) goto done;
    
	if (memcmp(dupar, defar, 128)) {
	    err = 1;
	    goto done;
	}
    }
    if (isNeed) {
	err = reader_test_login(ctx, passs); 
	if( err ) goto done;
	//err = reader_test_fkc_set_param(ctx, _TEXT("newpassword"));
	//if( err ) goto done;
    }
    if (first) {
	err = reader_test_DEF_WRITE(ctx,defar); 
	if( err ) goto done;
    }

    err = reader_test_folder_close( ctx); 
    if( err ) goto done;
    printf ("login to NULL and change password finished successfully\n");
done:
    if (err) printf ("login to NULL failed!\n");
    return err;
}

static DWORD
FKCTCreateAgreedKey(TSupSysEContext * ctx, TOKEN_CONTAINER* pCSP,
		    LPBYTE pbSenderPubKeyBlob, HCRYPTKEY* phAgreeKey)
{
    HCRYPTPROV hProv = pCSP->hContainer;
    HCRYPTKEY hAgreeKeyCSP=0, hPubKeyFKC=0, hAKey=0;
    CRYPT_DATA_BLOB sParam;
    LPBYTE pbPubKeyBlobToFKC=NULL, pbPubKeyBlobForCSP=NULL;
    LPBYTE pbAPubKeyBlob=NULL, pbQ_FKCBubBlob=NULL;
    BYTE pbPubKeyBlobFromFKC[PUBLICBLOBLEN];
    DWORD A[8];
    BYTE par1[2*SECRET_KEY_LEN];
    BYTE par2[2*SECRET_KEY_LEN];
    DWORD err =0, dwBlobLen = pCSP->dwPubBlobLen;

/*���������: d1==d_csp, d2==d_fkc -- �������� �����
 *	     Q1==Q_csp, Q2==Q_fkc -- �������� �����
 *	     Qs==Q_sender	  -- ..............
 *	     u	-- ukm
 */
    pbAPubKeyBlob = malloc(dwBlobLen);
    if(!pbAPubKeyBlob) goto done;
    pbQ_FKCBubBlob = malloc(dwBlobLen);
    if(!pbQ_FKCBubBlob) goto done;

    Printf_PublicBlob(pbSenderPubKeyBlob, "SenderPublic");

/*  CSP  *******************************************************/
    if(!CryptGenRandom(hProv, sizeof(DWORD)*8, (BYTE*)A))
	err = GetLastError();
    if(err) goto done;
    sParam.cbData = SECRET_KEY_LEN;
    sParam.pbData=(LPBYTE)A;
    /* hAKey <- Q_csp */
    if(!CryptImportKey(hProv, pCSP->pbPublicKeyBlob, dwBlobLen, 0, 0, &hAKey))
	err = GetLastError();
    if(err) goto done;
    sParam.cbData = SECRET_KEY_LEN;
    sParam.pbData = (BYTE*)A;
    if(!CryptSetKeyParam(hAKey, KP_MULX, (LPBYTE)&sParam, 0))
	err = GetLastError();
    if(err) goto done;
    /* pbAPubKeyBlob <- a*Q_csp */ 
    if(!CryptExportKey(hAKey, 0, PUBLICKEYBLOB, 0, pbAPubKeyBlob, &dwBlobLen))
	err = GetLastError();
    if(err) goto done;
    Printf_ECCPoint((LPDWORD)pbAPubKeyBlob, "Q_A");
    /*	(Qs+aQ1) -> pbPubKeyBlobToFKC */
    err = FKCAddPubKey_t(hProv, pbSenderPubKeyBlob, pbAPubKeyBlob, &dwBlobLen, 0, &pbPubKeyBlobToFKC);
    if(err) goto done;
    /*	(Qs-aQ2) -> pbPubKeyBlobForCSP */
    if(!CryptImportKey(hProv, pCSP->pbFKCPublicKeyBlob, dwBlobLen, 0, 0,&hPubKeyFKC))
	err = GetLastError();
    if(err) goto done;
    sParam.cbData = SECRET_KEY_LEN;
    sParam.pbData = (BYTE*)A;
    if(!CryptSetKeyParam(hPubKeyFKC, KP_MULX, (LPBYTE)&sParam, 0))
	err = GetLastError();
    if(err) goto done;
    if(!CryptExportKey(hPubKeyFKC, 0, PUBLICKEYBLOB, 0, pbQ_FKCBubBlob, &dwBlobLen))
	err = GetLastError();
    if(err) goto done;
    err = FKCAddPubKey_t(hProv, pbQ_FKCBubBlob, pbSenderPubKeyBlob, &dwBlobLen, 1, &pbPubKeyBlobForCSP);
    if(err) goto done;

    err = makeNewTransIdentificator(pCSP);
    if(err) goto done; 

    makePointFromBlob_t(par1,pbPubKeyBlobToFKC);
    err = reader_test_fkc_agreement(ctx,par1,par2,(TRdrFkcTrID)pCSP->randidentificator);
    if(err) goto done;
    makePublicBlob_t (pCSP, pbPubKeyBlobFromFKC, par2);

/*  CSP  CPImportKey *****************************************/

    //printf("\n-------CSP  CPImportKey-------- FKC ");
    /*	����	d1, (Qs-aQ2)   PubKeyBlobForCSP*/
    if(!CryptImportKey(hProv, pbPubKeyBlobForCSP, dwBlobLen, pCSP->hKeyPair, 0, &hAgreeKeyCSP))
	err = GetLastError();
    if(err) goto done; 

    /*	������	d1, (Qs-aQ2)=PubKeyBlobForCSP  ; d2*(Qs+aQ1)=pbPubKeyBlobFromFKC*/
    sParam.pbData=pbPubKeyBlobFromFKC;
    sParam.cbData=dwBlobLen;
    if(!CryptSetKeyParam(hAgreeKeyCSP, KP_DEMASKPUBLIC, (LPBYTE)&sParam, 0))
	err = GetLastError();
    if(err) goto done; 

    /*	�������/������ ������ �� ����� u*(d1+d2)*Qs = 
		u*d1*(Qs-aQ2) + u*d2*(Qs+aQ1)	*/

    *phAgreeKey = hAgreeKeyCSP;

    CryptDestroyKey(hPubKeyFKC);
    free(pbPubKeyBlobToFKC);
    CryptDestroyKey(hAKey);

    free(pbPubKeyBlobForCSP);
    free(pbAPubKeyBlob);
    free(pbQ_FKCBubBlob);
    return 0;

done:
    if(hPubKeyFKC) CryptDestroyKey(hPubKeyFKC);
    if(hAgreeKeyCSP) CryptDestroyKey(hAgreeKeyCSP);
    if(hAKey) CryptDestroyKey(hAKey);

    if(pbPubKeyBlobToFKC) free(pbPubKeyBlobToFKC);
    if(pbPubKeyBlobForCSP) free(pbPubKeyBlobForCSP);
    if(pbAPubKeyBlob) free(pbAPubKeyBlob);
    if(pbQ_FKCBubBlob) free(pbQ_FKCBubBlob);

    return err;
}

static DWORD
FKCTExportKey(TSupSysEContext * ctx, TOKEN_CONTAINER* pCSP,LPBYTE pbSenderPubKeyBlob,
	      HCRYPTKEY hExpKey, PCRYPT_DATA_BLOB psSipleBlob)
{
    HCRYPTKEY hAgreeKeyCSP=0;	  
    LPBYTE pbSimpleBlob=NULL;
    DWORD err =0, dwSimpleBlobLen;
    DWORD SV[2]={3,0};

    err = FKCTCreateAgreedKey(ctx, pCSP, pbSenderPubKeyBlob, /*pConf, */&hAgreeKeyCSP);
    if(err) goto done;
    if(!CryptSetKeyParam(hAgreeKeyCSP,KP_SV,(LPBYTE)SV,0)){err = GetLastError();}; 
    if(err) goto done;

    if(!CryptExportKey( hExpKey, hAgreeKeyCSP, SIMPLEBLOB , 0, NULL, &dwSimpleBlobLen)){err = GetLastError();};
    if(err) goto done; 
    pbSimpleBlob = malloc(dwSimpleBlobLen);
    if(!pbSimpleBlob) {
	err = (DWORD)NTE_NO_MEMORY;
	goto done; 
    }
    /*	������� ����� ExpKey �� ����� u(d1+d2)*Qs = u*(d1*Qs + d2*Qs)
		ud1*(Qs+(d1**(-1))*(d2*Qs) )		*/
    if(!CryptExportKey(hExpKey, hAgreeKeyCSP, SIMPLEBLOB , 0, pbSimpleBlob, &dwSimpleBlobLen)){err = GetLastError();};
    if(err) goto done; 
    psSipleBlob->pbData = pbSimpleBlob;
    psSipleBlob->cbData = dwSimpleBlobLen;

done:
    if(hAgreeKeyCSP) CryptDestroyKey(hAgreeKeyCSP);
    if(err && pbSimpleBlob) free(pbSimpleBlob);
    return err;
}

static DWORD
FKCTImportKey(TSupSysEContext * ctx, TOKEN_CONTAINER* pCSP,LPBYTE pbSenderPubKeyBlob,
	      PCRYPT_DATA_BLOB psSipleBlob, HCRYPTKEY* phImpKey)
{
    HCRYPTPROV hProv = pCSP->hContainer;
    HCRYPTKEY hAgreeKeyCSP=0, hImpKey;
    DWORD err =0;

    err = FKCTCreateAgreedKey(ctx,pCSP,pbSenderPubKeyBlob,&hAgreeKeyCSP);
    if(err) goto done;
    if(!CryptImportKey( hProv,psSipleBlob->pbData,
	psSipleBlob->cbData,hAgreeKeyCSP,0,&hImpKey)){err = GetLastError();};
    if(err) goto done;  
    *phImpKey=hImpKey;

done:
    if(hAgreeKeyCSP) CryptDestroyKey(hAgreeKeyCSP);
    return err;
}

static DWORD testAgree(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP, POtherSideKey pOtherKey)
{
    DWORD err = 0;
    HCRYPTKEY hExpKey = 0;
    HCRYPTKEY hNewExpKey = 0;
    CRYPT_DATA_BLOB sblob = {0};
    BYTE sv [8] = {0,1,2,3,4,5,6,7};
    BYTE plaintext [1040];
    BYTE savedtext [1040];
    DWORD textlen = 1024;
    int i;

    err = reader_test_HEADER_CV_COMPARE (ctx, pCSP);
    if (err) goto done;

    for (i=0;i<1040;i++) {
	plaintext[i] = (BYTE)(i&0xff);
	savedtext[i] = (BYTE)(i&0xff);
    }

    if(!CryptGenKey(pCSP->hContainer, CALG_G28147, CRYPT_EXPORTABLE ,&hExpKey))
    {
	err = GetLastError();
	goto done;
    }
    if(!CryptSetKeyParam(hExpKey,KP_SV,sv,0))
    {
	err = GetLastError();
	goto done;
    }
    memset(&sblob, 0, sizeof(sblob));
    err = FKCTExportKey(ctx, pCSP,pOtherKey->pkey,hExpKey, &sblob);
    if (err)
	goto done;

    err = FKCTImportKey(ctx, pCSP,pOtherKey->pkey,&sblob,&hNewExpKey);
    if (err)
	goto done;

    if(!CryptSetKeyParam(hNewExpKey,KP_SV,sv,0))
    {
	err = GetLastError();
	goto done;
    }

    if (!CryptEncrypt(hExpKey,0,TRUE,0,plaintext,&textlen,1040))
    {
	err = GetLastError();
	goto done;
    }

    if (!memcmp(plaintext,savedtext,1040)) {
	err = 1;
	goto done;
    }

    if (!CryptDecrypt(hNewExpKey,0,TRUE,0,plaintext,&textlen))
    {
	err = GetLastError();
	goto done;
    }

    if (memcmp(plaintext,savedtext,1040)) {
	err = 1;
	goto done;
    }
    printf ("\nDH test done. Key Export and Import done.\n");

done:
    if (hExpKey) CryptDestroyKey(hExpKey);
    if (hNewExpKey) CryptDestroyKey(hNewExpKey);
    free(sblob.pbData);
    return err;
}

static DWORD testCommit(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP)
{
    BYTE u3[(2*SECRET_KEY_LEN)];
    DWORD err;
        
    makePointFromBlob_t(u3, pCSP->pbSaltPublicBlob);

    err = reader_test_fkc_auth_change_commit(ctx, pCSP->logType, TRECi_syncroBIS, u3, pCSP->randidentificator, FKC_TRANS_SET_ALL);

    return err;
}

/*������� �������� ������� 0 � �������� Qpw'*/
static DWORD testWrongCase3(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP)
{
    DWORD err;
    BYTE u1[2*SECRET_KEY_LEN];
    BYTE u2[2*SECRET_KEY_LEN];
    BYTE u3[2*SECRET_KEY_LEN];
    BYTE blob[PUBLICBLOBLEN];
    TOKEN_DATA dCSP_EKE_data;
    TOKEN_DATA dFKC_EKE_data;
    TOKEN_DATA send;
    
    ZeroMemory(&dCSP_EKE_data,sizeof(TOKEN_DATA));//src
    send.pbData = NULL;
    send.cbData = 2*SECRET_KEY_LEN;
    send.tControl = id_Q_PW;
    dCSP_EKE_data.tControl = send.tControl;

    err = FKCGetEKE_A_(pCSP,&dCSP_EKE_data, FALSE);
    if(err) goto done;

    makePointFromBlob_t(u1,dCSP_EKE_data.pbData);
    free(dCSP_EKE_data.pbData);	/* dim: ct\reated at l.501 -- FKCGetEKE_A_() */
    dCSP_EKE_data.pbData = NULL;
	
    err = makeNewTransIdentificator(pCSP);
    if(err) goto done; 

    err = reader_test_fkc_auth_change_first(ctx, pCSP->logType, makeIDfromIndex(send.tControl), u1, u2, pCSP->randidentificator, FKC_TRANSACTION_IS_NEW);
    if (err!=RDR_ERR_BLOCK) 
	goto done;

    makePublicBlob_t(pCSP,blob,u2);
    dFKC_EKE_data.pbData = blob;
    dFKC_EKE_data.tControl = id_Q_PW;
    dFKC_EKE_data.tVerify = 0;
    dFKC_EKE_data.cbData = PUBLICBLOBLEN;
    
    err = FKCSetEKE_A_(pCSP,&dFKC_EKE_data);
    if(err) goto done;

    send.tControl = id_Unique;
    err = FKCGetEKE_DATA_(pCSP,&send);
    CryptDestroyKey(pCSP->hEKEAgree_A_B); /* dim: � ����� ���������? */
    pCSP->hEKEAgree_A_B = 0;
    if(err) goto done;

    makePointFromBlob_t(u3,send.pbData);
    free(send.pbData);

    err = reader_test_fkc_auth_change_second(ctx, pCSP->logType, makeIDfromIndex(id_Q_PW), &(send.tVerify), u3, pCSP->randidentificator);
    if (err!=RDR_ERR_BLOCK) 
	goto done;
    else
	err = 0;

    printf("\nSuccess: Wrong operation 3 returned! \n");
done: 
    return err;
}

static DWORD testWriteQpw(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP, BOOL first)
{
    DWORD err;
    BYTE u1[2*SECRET_KEY_LEN];
    BYTE u2[2*SECRET_KEY_LEN];
    BYTE u3[2*SECRET_KEY_LEN];
    BYTE blob[PUBLICBLOBLEN];
    TOKEN_DATA dCSP_EKE_data;
    TOKEN_DATA dFKC_EKE_data;
    TOKEN_DATA send;
    
    ZeroMemory(&dCSP_EKE_data,sizeof(TOKEN_DATA));//src
    send.pbData = NULL;
    send.cbData = 2*SECRET_KEY_LEN;
    send.tControl = id_Q_PW;
    dCSP_EKE_data.tControl = send.tControl;

    err = FKCGetEKE_A_(pCSP,&dCSP_EKE_data, FALSE);
    if(err) goto done;

    makePointFromBlob_t(u1,dCSP_EKE_data.pbData);
    free(dCSP_EKE_data.pbData);	/* dim: ct\reated at l.501 -- FKCGetEKE_A_() */
    dCSP_EKE_data.pbData = NULL;

    if (first) {
	err = makeNewTransIdentificator(pCSP);
	if(err) goto done; 
	err = reader_test_fkc_auth_change_first(ctx, pCSP->logType, makeIDfromIndex(send.tControl), u1, u2, pCSP->randidentificator, FKC_TRANSACTION_IS_NEW);
    } else {
	err = reader_test_fkc_auth_change_first(ctx, pCSP->logType, makeIDfromIndex(send.tControl), u1, u2, pCSP->randidentificator, FKC_TRANSACTION_IS_SAME);
    }
    if (err!=RDR_ERR_BLOCK) 
	goto done;

    makePublicBlob_t(pCSP,blob,u2);
    dFKC_EKE_data.pbData = blob;
    dFKC_EKE_data.tControl = id_Q_PW;
    dFKC_EKE_data.tVerify = 0;
    dFKC_EKE_data.cbData = PUBLICBLOBLEN;
    
    err = FKCSetEKE_A_(pCSP,&dFKC_EKE_data);
    if(err) goto done;

    err = FKCGetEKE_DATA_(pCSP,&send);
    CryptDestroyKey(pCSP->hEKEAgree_A_B); /* dim: � ����� ���������? */
    pCSP->hEKEAgree_A_B = 0;
    if(err) goto done;

    makePointFromBlob_t(u3,send.pbData);
    free(send.pbData);

    err = reader_test_fkc_auth_change_second(ctx, pCSP->logType, makeIDfromIndex(send.tControl), &(send.tVerify), u3, pCSP->randidentificator);
    if (err!=RDR_ERR_BLOCK) 
	goto done;
    else
	err = 0;

    printf("\n Writing Qpw success! \n");
done: 
    return err;
}

static DWORD testWriteDelta(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP, BYTE * newdelta, BOOL first)
{
    DWORD err;
    BYTE u1[(2*SECRET_KEY_LEN)];
    BYTE u2[(2*SECRET_KEY_LEN)];
    BYTE u3[SECRET_KEY_LEN];
    BYTE blob[PUBLICBLOBLEN];
#ifdef PRINT_COMMENT
    int i;
#endif
    BYTE prntsync [SECRET_KEY_LEN];
    TOKEN_DATA dCSP_EKE_data;
    TOKEN_DATA dFKC_EKE_data;
    TOKEN_DATA send;
    
    ZeroMemory(&dCSP_EKE_data,sizeof(TOKEN_DATA));//src
    send.pbData = newdelta;
    send.cbData = SECRET_KEY_LEN;
    send.tControl = id_delta;
    dCSP_EKE_data.tControl = send.tControl;

    err = FKCGetEKE_A_(pCSP,&dCSP_EKE_data, FALSE);
    if(err) goto done;

    makePointFromBlob_t(u1,dCSP_EKE_data.pbData);
    free(dCSP_EKE_data.pbData);	/* dim: was created in l.564 -- FKCGetEKE_A_() */
    dCSP_EKE_data.pbData = NULL;

    if (first) {
	err = makeNewTransIdentificator(pCSP);
	if(err) goto done; 
	err = reader_test_fkc_auth_change_first(ctx, pCSP->logType, makeIDfromIndex(send.tControl), u1, u2, pCSP->randidentificator, FKC_TRANSACTION_IS_NEW);
    } else {
	err = reader_test_fkc_auth_change_first(ctx, pCSP->logType, makeIDfromIndex(send.tControl), u1, u2, pCSP->randidentificator, FKC_TRANSACTION_IS_SAME);
    }
    if (err!=RDR_ERR_BLOCK) 
	goto done;

    makePublicBlob_t(pCSP,blob,u2);
    dFKC_EKE_data.pbData = blob;
    dFKC_EKE_data.tControl = id_delta;
    dFKC_EKE_data.tVerify = 0;
    dFKC_EKE_data.cbData = PUBLICBLOBLEN;
    
    err = FKCSetEKE_A_(pCSP,&dFKC_EKE_data);
    if(err) goto done;

    be2le_t (prntsync,newdelta,SECRET_KEY_LEN);
#ifdef PRINT_COMMENT
    printf("\nIn CSP delta' = ");
    for (i=0;i<SECRET_KEY_LEN;i++) printf("%00x",prntsync[i]);
    printf("\n");
#endif
    err = FKCGetEKE_DATA_(pCSP,&send);
    CryptDestroyKey(pCSP->hEKEAgree_A_B); /* dim: pCSP->hEKEAgree_A_B */
    pCSP->hEKEAgree_A_B = 0;
    if(err) goto done;

    be2le_t(u3,send.pbData,SECRET_KEY_LEN);

    err = reader_test_fkc_auth_change_second(ctx, pCSP->logType, makeIDfromIndex(send.tControl), &(send.tVerify), u3, pCSP->randidentificator);
    if (err!=RDR_ERR_BLOCK) 
	goto done;
    else
	err = 0;

    printf("\n Writing delta success! \n");
done: 
    return err;

}

static DWORD testWriteSyncro(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP, BYTE * newsyncro, BOOL first)
{
    DWORD err;
    BYTE u1[(2*SECRET_KEY_LEN)];
    BYTE u2[(2*SECRET_KEY_LEN)];
    BYTE u3[RDR_FKC_SYNCRO_SIZE];
    BYTE blob[PUBLICBLOBLEN];
#ifdef PRINT_COMMENT
    int i;
#endif
    BYTE prntsync [SECRET_KEY_LEN];
    BYTE tmpsync [SECRET_KEY_LEN];
    TOKEN_DATA dCSP_EKE_data;
    TOKEN_DATA dFKC_EKE_data;
    TOKEN_DATA send;
    DWORD s2;

    
    ZeroMemory(&dCSP_EKE_data,sizeof(TOKEN_DATA));//src
    send.pbData = tmpsync;
    memcpy(send.pbData,newsyncro,SECRET_KEY_LEN);
    send.cbData = SECRET_KEY_LEN;
    send.tControl = id_syncro_;
    dCSP_EKE_data.tControl = send.tControl;

    err = FKCGetEKE_A_(pCSP,&dCSP_EKE_data, FALSE);
    if(err) goto done;

    makePointFromBlob_t(u1,dCSP_EKE_data.pbData);
    free(dCSP_EKE_data.pbData);
    dCSP_EKE_data.pbData = 0;

    if (first) {
	err = makeNewTransIdentificator(pCSP);
	if(err) goto done; 
	err = reader_test_fkc_auth_change_first(ctx, pCSP->logType, makeIDfromIndex(send.tControl), u1, u2, pCSP->randidentificator, FKC_TRANSACTION_IS_NEW);
    } else {
	err = reader_test_fkc_auth_change_first(ctx, pCSP->logType, makeIDfromIndex(send.tControl), u1, u2, pCSP->randidentificator, FKC_TRANSACTION_IS_SAME);
    }
    if (err!=RDR_ERR_BLOCK) 
	goto done;

    makePublicBlob_t(pCSP,blob,u2);
    dFKC_EKE_data.pbData = blob;
    dFKC_EKE_data.tControl = id_syncro_;
    dFKC_EKE_data.tVerify = 0;
    dFKC_EKE_data.cbData = PUBLICBLOBLEN;
    
    err = FKCSetEKE_A_(pCSP,&dFKC_EKE_data);
    if(err) goto done;

    be2le_t (prntsync,newsyncro,SECRET_KEY_LEN);
#ifdef PRINT_COMMENT
    printf("\nIn CSP syncro' = ");
    for (i=0;i<SECRET_KEY_LEN;i++) printf("%00x",prntsync[i]);
    printf("\n");
#endif
    err = FKCGetEKE_DATA_(pCSP,&send);
    if(err) goto done; 
    err = FKCCreateEKEVerify1(pCSP,&send,&send);
    if(err) goto done; 

    be2le_t(u3,send.pbData+8,RDR_FKC_SYNCRO_SIZE);

	// ���� �������� ��������, �� �� ���-������� ������ ��������� ����� �������� ����
    s2 = makeSygma2BE((USHORT)le2be_d2s(send.tVerify));
    err = reader_test_fkc_auth_change_second(ctx, pCSP->logType, makeIDfromIndex(send.tControl), &s2, u3, pCSP->randidentificator);
    if (err!=RDR_ERR_BLOCK) 
	goto done;

    s2 = makeSygma2LE((USHORT)s2);

    err = FKCCreateEKEVerify2(pCSP, &send, &send);
    if(err) goto done; 

    err = FKCVerifyEKE_t(pCSP,s2);
    CryptDestroyKey(pCSP->hEKEAgree_A_B); /* dim: pCSP->hEKEAgree_A_B */
    pCSP->hEKEAgree_A_B = 0;
    if (err) goto done; 
	    
    printf("\n Writing syncro success! \n");
done: 
    return err;

}

static DWORD testAuthChall(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP);

static DWORD testAuthChange(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP, TCHAR * newPW)
{
    DWORD err=0;
    TOKEN_DATA dSyncro, dDelta;
    char str[NAME_LENTH];

    _2asciicpy(str, newPW);

    ZeroMemory(&dSyncro,sizeof(TOKEN_DATA));
    dSyncro.tControl = id_syncro_;
    ZeroMemory(&dDelta,sizeof(TOKEN_DATA));
    dDelta.tControl = id_delta;

    Printf_ECCPoint((LPDWORD)pCSP->pbSaltPublicBlob, "Q_SALT when change =");
    err = FKCCreatePWPublic(pCSP, str);
    if(err) goto done;

    err= testWriteQpw(ctx, pCSP, TRUE);
    if(err) goto done;
 
    err = reader_test_fkc_get_counters(ctx, pCSP);
    if(err) goto done;
    err = FKCCreateSyncro_e(pCSP,&dSyncro);
    if(err) goto done;

    err = testWriteSyncro(ctx, pCSP, dSyncro.pbData, FALSE);
    if(err) goto done;

    err = SetTokenData(id_delta,dSyncro.pbData,dSyncro.cbData,&dDelta);
    if(err) goto done;

    err = FKCCreateDelta_e(pCSP,dDelta.pbData);
    if(err) goto done;

    err = testWriteDelta(ctx, pCSP, dDelta.pbData, FALSE);
    if(err) goto done;

    if (!CryptGenRandom(pCSP->hContainer,8,pCSP->controlvector)) {
	err = GetLastError();
	goto done;
    }

    err = testCommit(ctx,pCSP);
    if(err) goto done;

    free(pCSP->pbPWPublicKeyBlob);
    pCSP->pbPWPublicKeyBlob = pCSP->pbPWPublicKeyBlob_d;

    printf ("\nAuthentification after AuthChange\n");
    err = testAuthChall(ctx, pCSP);
    if(err) goto done; 

    err = reader_test_HEADER_WRITE( ctx, pCSP->controlvector, 2040); 

done:
    FreeTokenData(&dSyncro);
    FreeTokenData(&dDelta);
    return err;
}

static DWORD testCounters(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP)
{
    DWORD err;

    err = reader_test_fkc_get_counters(ctx, pCSP);
    if (err!=SUP_ERR_NO) goto done;

    err = testWriteSyncro(ctx, pCSP, pCSP->syncro, TRUE);
    if (err!=SUP_ERR_NO) goto done;

    pCSP->C.c_eke--;
    err = testWriteSyncro(ctx, pCSP, pCSP->syncro, TRUE);
    if (err!=SUP_ERR_NO) goto done;

    printf("EKE counter is correct\n");
done:
    return err;
}

static DWORD testNewFriendlyName(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP)
{
    DWORD err;
    TCHAR * nname = _TEXT("newTestName");

    err = reader_test_fkc_set_fname(ctx, nname);
    if (err!=SUP_ERR_NO) goto done;

    _2asciicpy((LPSTR)pCSP->friendlyname,nname);

    err = reader_test_fkc_get_counters(ctx, pCSP);
    if (err!=SUP_ERR_NO) goto done;

    err = testWriteSyncro(ctx, pCSP, pCSP->syncro, TRUE);
    if (err!=SUP_ERR_NO) goto done;

    err = reader_test_fkc_get_counters(ctx, pCSP);
    if(err) goto done;

    printf("Setting Friendly Name success!\n");
done:
    return err;
}

static DWORD readQfkc(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP)
{
    DWORD err;
    BYTE u1[(2*SECRET_KEY_LEN)];
    BYTE u2[(2*SECRET_KEY_LEN)];
    BYTE u3[(2*SECRET_KEY_LEN)];
    BYTE blob[PUBLICBLOBLEN];
    TOKEN_DATA dCSP_EKE_data;
    
    ZeroMemory(&dCSP_EKE_data,sizeof(TOKEN_DATA));//src
    dCSP_EKE_data.tControl = id_Q_FKC;

    err = FKCGetEKE_A_(pCSP,&dCSP_EKE_data, FALSE);
    if(err) goto done;

    makePointFromBlob_t(u1,dCSP_EKE_data.pbData);
    free(dCSP_EKE_data.pbData);	/* dim: created at l.816 -- FKCGetEKE_A_() */
    dCSP_EKE_data.pbData = NULL;

    err = makeNewTransIdentificator(pCSP);
    if(err) goto done; 

    err = reader_test_fkc_auth_challenge_first(ctx, pCSP->logType, TRECi_Qfkc, u1, u2,
	(TRdrFkcTrID)pCSP->randidentificator,FKC_TRANSACTION_IS_NEW);
    if (err!=RDR_ERR_BLOCK) 
	return err;

    makePublicBlob_t(pCSP,blob,u2);
    dCSP_EKE_data.pbData = blob;
    dCSP_EKE_data.tControl = id_Q_FKC;
    dCSP_EKE_data.tVerify = 0;
    dCSP_EKE_data.cbData = PUBLICBLOBLEN;
    
    err = FKCSetEKE_A_(pCSP,&dCSP_EKE_data);
    if(err) goto done;
        
    err = reader_test_fkc_auth_challenge_second(ctx, pCSP->logType, TRECi_Qfkc, NULL, u3,(TRdrFkcTrID)pCSP->randidentificator);
    if(err) goto done; 

    makePublicBlob_t(pCSP,blob,u3);
    dCSP_EKE_data.pbData = blob;
    dCSP_EKE_data.tControl = id_Q_FKC;
    dCSP_EKE_data.tVerify = 0;
    dCSP_EKE_data.cbData = PUBLICBLOBLEN;
    
    err = FKCSetEKE_DATA_(pCSP,&dCSP_EKE_data);
    if(err) goto done; 
    CryptDestroyKey(pCSP->hEKEAgree_A_B);
    pCSP->hEKEAgree_A_B = 0;

    printf("\nReading Qfkc success! \n");
done: 
    return err;
}

/*������� ��������� ���������� ������ ��� �������� 0 ������ Qa*/

static DWORD testWrongCase1(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP)
{
    DWORD err;
    BYTE u1[(2*SECRET_KEY_LEN)];
    BYTE u2[(2*SECRET_KEY_LEN)];
    BYTE u3[(2*SECRET_KEY_LEN)];
    BYTE blob[PUBLICBLOBLEN];
    TOKEN_DATA dCSP_EKE_data;
    
    ZeroMemory(&dCSP_EKE_data,sizeof(TOKEN_DATA));//src
    dCSP_EKE_data.tControl = id_Q_FKC;

    err = FKCGetEKE_A_(pCSP,&dCSP_EKE_data, TRUE);
    if(err) goto done;

    makePointFromBlob_t(u1,dCSP_EKE_data.pbData);
    free(dCSP_EKE_data.pbData);	/* dim: created at l.816 -- FKCGetEKE_A_() */
    dCSP_EKE_data.pbData = NULL;

    err = makeNewTransIdentificator(pCSP);
    if(err) goto done; 

    err = reader_test_fkc_auth_challenge_first(ctx, pCSP->logType, TRECi_Qfkc, u1, u2,
	(TRdrFkcTrID)pCSP->randidentificator,FKC_TRANSACTION_IS_NEW);
    if (err!=RDR_ERR_BLOCK) 
    {
	printf("\nERROR: Wrong error code in wrong operation 1, should be RDR_ERR_BLOCK\n");
	err = err?err:(DWORD)NTE_FAIL;
	goto done;
    }

    makePublicBlob_t(pCSP,blob,u2);
    dCSP_EKE_data.pbData = blob;
    dCSP_EKE_data.tControl = id_Q_FKC;
    dCSP_EKE_data.tVerify = 0;
    dCSP_EKE_data.cbData = PUBLICBLOBLEN;
    
    err = FKCSetEKE_A_(pCSP,&dCSP_EKE_data);
    if(err) goto done;
        
    err = reader_test_fkc_auth_challenge_second(ctx, pCSP->logType, TRECi_Qfkc, NULL, u3,(TRdrFkcTrID)pCSP->randidentificator);
    if(err) goto done; 

done: 
    if (pCSP->hEKEAgree_A_B)
    {
	CryptDestroyKey(pCSP->hEKEAgree_A_B);
	pCSP->hEKEAgree_A_B = 0;
    }
    return err;
}


/* ������� ��������� ����� �������������� � ����� */
static DWORD testWrongCase2(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP)
{
    DWORD err;
    BYTE u1[(2*SECRET_KEY_LEN)];
    BYTE u2[(2*SECRET_KEY_LEN)];
    BYTE u3[(2*SECRET_KEY_LEN)];
    BYTE blob[PUBLICBLOBLEN];
    TOKEN_DATA dCSP_EKE_data;
    
    ZeroMemory(&dCSP_EKE_data,sizeof(TOKEN_DATA));//src
    dCSP_EKE_data.tControl = id_Q_FKC;

    err = FKCGetEKE_A_(pCSP,&dCSP_EKE_data, FALSE);
    if(err) goto done;

    makePointFromBlob_t(u1,dCSP_EKE_data.pbData);
    free(dCSP_EKE_data.pbData);	/* dim: created at l.816 -- FKCGetEKE_A_() */
    dCSP_EKE_data.pbData = NULL;

    err = makeNewTransIdentificator(pCSP);
    if(err) goto done; 

    err = reader_test_fkc_auth_challenge_first(ctx, pCSP->logType, TRECi_Qfkc, u1, u2,
	(TRdrFkcTrID)pCSP->randidentificator,FKC_TRANSACTION_IS_NEW);
    if (err == RDR_ERR_FKC_NEED_CONT_AUTH)
    {
	err = 0;
	printf("\nSuccess: Wrong operation 2: RDR_ERR_FKC_NEED_CONT_AUTH is expected behavior!\n");
	goto done;
    } else if (err == RDR_ERR_BLOCK)
    {
    } else
    {
	printf("\nERROR: Wrong error code in wrong operation 2, should be RDR_ERR_FKC_NEED_CONT_AUTH or RDR_ERR_BLOCK\n");
	err = err?err:(DWORD)NTE_FAIL;
	goto done;
    }

    makePublicBlob_t(pCSP,blob,u2);
    dCSP_EKE_data.pbData = blob;
    dCSP_EKE_data.tControl = id_Q_FKC;
    dCSP_EKE_data.tVerify = 0;
    dCSP_EKE_data.cbData = PUBLICBLOBLEN;
    
    err = FKCSetEKE_A_(pCSP,&dCSP_EKE_data);
    if(err) goto done;
        
    err = reader_test_fkc_auth_challenge_second(ctx, pCSP->logType, TRECi_Qfkc, NULL, u3,(TRdrFkcTrID)pCSP->randidentificator);
    if(!err) {
	printf("\nERROR: Successfull wrong operation 2\n");
	err = (DWORD)NTE_FAIL;
    } else if (err == RDR_ERR_FKC_NEED_CONT_AUTH)
    {
	err = 0;
	printf("\nSuccess: Wrong operation 2: RDR_ERR_FKC_NEED_CONT_AUTH is expected behavior!\n");
    } else
    {
	printf("\nERROR: Wrong error code in wrong operation 2, should be RDR_ERR_FKC_NEED_CONT_AUTH\n");
	err = (DWORD)NTE_FAIL;
    }
    CryptDestroyKey(pCSP->hEKEAgree_A_B);
    pCSP->hEKEAgree_A_B = 0;

done: 
    CryptDestroyKey(pCSP->hKey_A);
    pCSP->hKey_A = 0;
    return err;
}


static DWORD testAuthChall(TSupSysEContext * ctx, LPTOKEN_CONTAINER pCSP)
{
    DWORD err;
    BYTE u1[(2*SECRET_KEY_LEN)];
    BYTE u2[(2*SECRET_KEY_LEN)];
    BYTE u3[RDR_FKC_SYNCRO_SIZE];
    BYTE u4[SECRET_KEY_LEN];
    BYTE blob[PUBLICBLOBLEN];
    BYTE prntsync [SECRET_KEY_LEN];
#ifdef PRINT_COMMENT
    int i;
#endif
    TOKEN_DATA dCSP_EKE_data;
    TOKEN_DATA dFKC_EKE_data;
    TOKEN_DATA ssend;
    DWORD s2;
    PTOKEN_DATA send = &ssend;
    
    printf ("Protocol AuthChallenge started\n");
    send->pbData = NULL;
    err = SetTokenData(id_syncro,NULL,SECRET_KEY_LEN,send);
    if(err) goto done;

    err = reader_test_fkc_auth_type(ctx, pCSP);
    if(err) goto done;

    ZeroMemory(&dCSP_EKE_data,sizeof(TOKEN_DATA));//src
    dCSP_EKE_data.tControl = send->tControl;

    err = FKCGetEKE_A_(pCSP,&dCSP_EKE_data, FALSE);
    free(pCSP->pbEKE_A);	/* dim: � ����� ��� ���� ���������? */
    pCSP->pbEKE_A = 0;
    if(err) goto done;

    makePointFromBlob_t(u1,dCSP_EKE_data.pbData);
    free(dCSP_EKE_data.pbData);

    err = makeNewTransIdentificator(pCSP);
    if(err) goto done;

    err = reader_test_fkc_auth_challenge_first(ctx, pCSP->logType, makeIDfromIndex(send->tControl), u1, u2,
	(TRdrFkcTrID)pCSP->randidentificator,FKC_TRANSACTION_IS_NEW);
    if (err!=RDR_ERR_BLOCK) 
	return err;

    makePublicBlob_t(pCSP,blob,u2);
    dFKC_EKE_data.pbData = blob;
    dFKC_EKE_data.tControl = id_syncro;
    dFKC_EKE_data.tVerify = 0;
    dFKC_EKE_data.cbData = PUBLICBLOBLEN;
    
    /* Qb Transport */
    err = FKCSetEKE_A_(pCSP,&dFKC_EKE_data);
    if(err) goto done;
        
    err = FKCCreateEKEVerify1(pCSP,send,send);
    if(err) goto done; 

	// ���� �������� ��������, �� �� ���-������� ������ ��������� ����� �������� ����
    s2 = makeSygma2BE((USHORT)le2be_d2s(send->tVerify));

    err = reader_test_fkc_auth_challenge_second(ctx, pCSP->logType, 
	makeIDfromIndex(send->tControl), &s2, u3,(TRdrFkcTrID)pCSP->randidentificator);
    if(err) goto done; 

    s2 = makeSygma2LE((USHORT)s2);
    dFKC_EKE_data.pbData = u4;
    memset(dFKC_EKE_data.pbData,0,8);
    be2le_t(dFKC_EKE_data.pbData+8,u3,RDR_FKC_SYNCRO_SIZE);
    dFKC_EKE_data.cbData = SECRET_KEY_LEN;
    dFKC_EKE_data.tControl = id_syncro;
    dFKC_EKE_data.tVerify = 0;

    err = SetTokenData(id_syncro,NULL,SECRET_KEY_LEN,send);
    if(err) goto done;

    memset(send->pbData,0,8);
    be2le_t(send->pbData+8,u3,RDR_FKC_SYNCRO_SIZE);
    err = FKCCreateEKEVerify2(pCSP, send, send);
    if(err) goto done; 

    err = FKCVerifyEKE_t(pCSP,s2);
    if(err) goto done; 
    
    err = FKCSetEKE_DATA_(pCSP,&dFKC_EKE_data);
    if(err) goto done; 

    		
    be2le_t (prntsync,u4,SECRET_KEY_LEN);
#ifdef PRINT_COMMENT
    printf("\nIn CSP syncro = ");
    for (i=0;i<SECRET_KEY_LEN;i++) printf("%00x",prntsync[i]);
    printf("\n");
#endif
    memcpy(pCSP->syncro, u4, SECRET_KEY_LEN);
	    
    printf("\n EKE Verification success! \n");
done:
    printf ("Protocol AuthChallenge finished\n");
    CryptDestroyKey(pCSP->hEKEAgree_A_B);
    pCSP->hEKEAgree_A_B = 0;
    free(send->pbData);
    return err;
}

void makePublicBlob_t (LPTOKEN_CONTAINER pFkc, BYTE * blob, BYTE *Point) 
{
    memcpy(blob, pFkc->pbPWPublicKeyBlob, 0x24);
    be2le_t(blob+0x24,Point,SECRET_KEY_LEN);
    be2le_t(blob+0x24+SECRET_KEY_LEN,Point+SECRET_KEY_LEN,SECRET_KEY_LEN);
}

static DWORD Test_FKCAdminOpenAndTest(TSupSysEContext * ctx, TSupSysEContext * dupctx, LPTSTR pszFKCContainerName, DWORD dwKeySpec, char * pszKeyOID, LPTSTR pszPW)
{
    DWORD err;
    LPTOKEN_CONTAINER pCSP=NULL;
    DWORD dwBlobLen;
    DWORD dwControl = CRYPT_VERIFYCONTEXT | FKC_GENKEY;
    BYTE point [(2*SECRET_KEY_LEN)];
    BYTE qs [(2*SECRET_KEY_LEN)];
    BYTE SomeGarbage [2048];
    BYTE tmpcontrol[16];
    TOKEN_DATA send;
    BYTE signat [(2*SECRET_KEY_LEN)];
    int i=0;
    char *makepass[NAME_LENTH];
    DWORD oid;
    TCHAR * prov_name = NULL;
    size_t prov_name_len = 0;
    
    err = IntCSPTContainer(pszFKCContainerName, dwControl, dwKeySpec, pszKeyOID, &pCSP);
    if(err) goto done;

    ZeroMemory(&send,sizeof(TOKEN_DATA));//src
    for (i=0;i<2048;i++) SomeGarbage[i] = (BYTE)((i+17)&0xff);

    dwBlobLen = pCSP->dwPubBlobLen;

    _2asciicpy((LPSTR)makepass,pszPW);
    err = CSPCreateTContainer((LPSTR)makepass, pCSP);
    if(err) goto done;
    /* ������ Q_csp */
    err = SetPublicKeyBlob_test(pCSP);
    if(err) goto done;
    /*--- CSP ---*/
    /*  Q_s  */
    err = SetDataPublicTokenContainer(id_Q_S,(BYTE*)&(SaltPublic[pCSP->Num_ECC-1][0][0]),dwBlobLen,pCSP);
    /* CSP ������ Qpw, Qpw_0*/
    if(err) goto done;
    Printf_ECCPoint((LPDWORD)pCSP->pbSaltPublicBlob, "Q_SALT when open =");
    err = FKCCreatePWPublic(pCSP,(LPSTR)makepass);
    if(err) goto done;

    if(!pCSP->pbPWPublicKeyBlob)
	pCSP->pbPWPublicKeyBlob = pCSP->pbPWPublicKeyBlob_d;

    makePointFromBlob_t(point, pCSP->pbPWPublicKeyBlob);
    makePointFromBlob_t(qs, pCSP->pbSaltPublicBlob);

    err = reader_test_fkc_folder_open(ctx, pszFKCContainerName, (dwKeySpec!=AT_SIGNATURE));
    if(err) goto done;

    err = reader_test_HEADER_GET( ctx, tmpcontrol); 
    if(err) goto done;
    memcpy(pCSP->controlvector, tmpcontrol, 8);

    err = testAuthChall(ctx, pCSP);
    if(err) goto done;

    err = readQfkc(ctx, pCSP);
    if(err) goto done;

    err = testWrongCase2(ctx, pCSP);
    if(err) goto done;

    err = testAuthChall(ctx, pCSP);
    if(err) goto done;

    CryptDestroyKey(pCSP->hKeyPW_Pair); /* dim: was created in FKCCreatePWPublic(), l.993  */
    pCSP->hKeyPW_Pair = 0;

    err = testWrongCase1(ctx, pCSP);
    if(err) goto done;

    err = testAuthChall(ctx, pCSP);
    if(err) goto done;

    err = FKCCreateKeysManyMany(pCSP);
    if(err) goto done;

    err = testWrongCase3(ctx, pCSP);
    if(err) goto done;

    err = testAuthChange(ctx, pCSP, pszPW);
    if(err) goto done;

    err = FKCCreateKeysManyMany(pCSP);
    if(err) goto done;

/* ����� �������� ����... */
    err = readQfkc(ctx, pCSP);
    if(err) goto done;

    err = testAuthChall(ctx, pCSP);
    if(err) goto done;

    err = FKCCreateKeysManyMany(pCSP);
    if(err) goto done;

/**/
    err = reader_test_fkc_get_counters(ctx, pCSP);
    if(err) goto done;

    err = testSign(ctx, pCSP, SomeGarbage, 2048, signat);
    if(err) goto done;
    err=FKCVerifySign(pCSP->hContainer, pCSP->pbUserPublicKeyBlob,pCSP->dwPubBlobLen,
	SomeGarbage, 2048, signat);
    if(err) {
	goto done;
    } else {
	printf("Signature verified first time\n");    // TODO: Check FKCVevifySign
    }

    reader_test_unlock(ctx);

    printf("Other context locking\n");
    err = reader_test_lock( dupctx );
    if (err) goto done;
    oid = srtOIDtoDWORD(pszKeyOID);
    printf("Other context locked. Other context Folder Create\n");
    err = reader_test_fkc_folder_create(dupctx, FKC_DUP_CONTAINER_NAME, oid, (dwKeySpec!=AT_SIGNATURE));
    if(err) {
	reader_test_unlock(dupctx);
	goto done;
    }
    printf("Other context Folder Created\n");
    reader_test_unlock(dupctx);

    err = reader_test_lock(ctx);
    if(err) goto done;

    err = testSign(ctx, pCSP, SomeGarbage, 2048, signat);
    if(err) {
	reader_test_unlock(ctx);
	goto done;
    }
    err=FKCVerifySign(pCSP->hContainer, pCSP->pbUserPublicKeyBlob,pCSP->dwPubBlobLen,
	SomeGarbage, 2048, signat);
    if(err) {
	reader_test_unlock(ctx);
	goto done;
    } else {
	printf("Signature in first context verified second time\n");    // TODO: Check FKCVevifySign
    }
    reader_test_unlock(ctx);

    err = reader_test_lock(dupctx);
    if(err) goto done;

    printf("Other context Folder Clearing\n");
    err = reader_test_folder_clear(dupctx);
    if(err) {
	reader_test_unlock(dupctx);
	goto done;
    }
    reader_test_unlock(dupctx);

    printf("Other context Unlocked\n");

    err = reader_test_lock(ctx);
    if(err) goto done;

    err = testTransaction(ctx, pCSP);
    if(err) goto done;

    if (dwKeySpec==AT_KEYEXCHANGE) {
	HCRYPTPROV newprov;
	HCRYPTKEY newkey;
	BYTE expkeyblob [PUBLICBLOBLEN];
	DWORD dwlen = PUBLICBLOBLEN;
	OtherSideKey otherkey;
	TSupErr code = SUP_ERR_NO;

	prov_name = NULL;
	prov_name_len = 0;

	code = support_registry_get_string (FKCHDIMG_PATH, &prov_name_len, NULL);
	if (code) {
	    printf ("Test is going to start on default provider. Please install FKCHDIMG\n");
	    prov_name = NULL;
	}
	else {
	    prov_name = malloc ((prov_name_len + 1) * sizeof (TCHAR));
	    if (!prov_name) {
		err = (DWORD) NTE_NO_MEMORY;
		goto done;
	    }
	    code = support_registry_get_string (FKCHDIMG_PATH, &prov_name_len, prov_name);
	    if (code) {
		printf ("Test is going to start on default provider. Please configure FKCHDIMG\n");
		if (prov_name) free (prov_name);
		prov_name = NULL;
	    }
	}

#if defined UNIX
	CryptAcquireContext(&newprov,_TEXT("\\\\.\\hdimage\\testDHcontainer"),prov_name,PROV_GOST_2001_DH,CRYPT_DELETEKEYSET);
	if (!CryptAcquireContext(&newprov,_TEXT("\\\\.\\hdimage\\testDHcontainer"),prov_name,PROV_GOST_2001_DH,CRYPT_NEWKEYSET)) {
#else
	CryptAcquireContext(&newprov,_TEXT("\\\\.\\REGISTRY\\testDHcontainer"),prov_name,PROV_GOST_2001_DH,CRYPT_DELETEKEYSET);
	if (!CryptAcquireContext(&newprov,_TEXT("\\\\.\\REGISTRY\\testDHcontainer"),prov_name,PROV_GOST_2001_DH,CRYPT_NEWKEYSET)) {
#endif /* UNIX */
	    printf ("Bad provider or registry/hdimage module\n");
	    err = GetLastError();
	    goto done;
	}
	if(!CryptSetProvParam( newprov,PP_DHOID,(LPBYTE)pCSP->pszKeyOID,0)) {
	    err = GetLastError();
	    goto done;
	};
	if(!CryptSetProvParam( newprov,PP_SIGNATURE_PIN,(LPBYTE)"",0))
	{
	    err = GetLastError();
	    goto done;
	};
	if(!CryptGenKey(newprov, AT_KEYEXCHANGE, 0, &newkey)) {
	    err = GetLastError();
	    goto done;
	};
	if (!CryptExportKey(newkey,0,PUBLICKEYBLOB,0,expkeyblob,&dwlen)) {
	    err = GetLastError();
	    goto done;
	}

	otherkey.key = newkey;
	otherkey.pkey = expkeyblob;
	otherkey.pkeysize = dwlen;
	otherkey.prov = newprov;
	
	err = testAgree(ctx, pCSP, &otherkey);
	if(err) goto done;
	CryptDestroyKey(newkey);
	CryptReleaseContext(newprov, 0);
    }

    err = reader_test_fkc_get_counters(ctx, pCSP);
    if(err) goto done;
    err = testNewFriendlyName(ctx, pCSP);
    if(err) goto done;
    err = testCounters(ctx, pCSP);
    if(err) goto done;
    free(pCSP->pbEKE_A);	/* dim: created in testCounters()  */
    pCSP->pbEKE_A = NULL;
    err = reader_test_folder_close(ctx);
    if(err) goto done;

    FKCtstReleaseTContainer(pCSP);
done:
    if (prov_name) {
	free (prov_name);
	prov_name = NULL;
    }
    if(err)
	printf ("Open test FAILED\n");
    return err;
}

static void DWORDtosrtOID(char * pszKeyOID, DWORD uidg, BOOL enableDH) 
{
    switch (uidg) {
	case RDR_FKC_IDG_CP_B_PARAMSET:
	    strcpy(pszKeyOID,szOID_GostR3410_2001_CryptoPro_B_ParamSet);
	    break;
	case RDR_FKC_IDG_CP_C_PARAMSET:
	    if (enableDH) strcpy(pszKeyOID,szOID_GostR3410_2001_CryptoPro_XchB_ParamSet);
	    else strcpy(pszKeyOID,szOID_GostR3410_2001_CryptoPro_C_ParamSet);
	    break;
	case RDR_FKC_IDG_CP_OPTIONAL_PARAMSET:
	case RDR_FKC_IDG_CP_A_PARAMSET:
	default:
	    if (enableDH) strcpy(pszKeyOID,szOID_GostR3410_2001_CryptoPro_XchA_ParamSet);
	    else strcpy(pszKeyOID,szOID_GostR3410_2001_CryptoPro_A_ParamSet);
	    break;
    }
}

static TSupErr reader_test_fkc_get_counters(TSupSysEContext *context, void * pFKC_)
{
    TRdrFkcFolderCountersParam countPar;
    TSupErr code= SUP_ERR_NO;
    size_t sizeo = sizeof(TRdrFkcFolderCountersParam);
    LPTOKEN_CONTAINER pFKC = (LPTOKEN_CONTAINER)pFKC_;

    countPar.paramID = TCEP_counters;
    countPar.size_of = sizeo;
    printf("Get get_counters.\n");

    code = rdr_folder_get_param( context,TCEP_counters,CH2P(TRdrFkcFolderCountersParam,&countPar),&sizeo);

    if (code == SUP_ERR_NO) 
    {
	makeCounters(&(pFKC->C), &(countPar.initCounters));
    }
    printf("Get get_counters finished successfully.\n");

    return code;
}

static TSupErr reader_test_fkc_auth_type(TSupSysEContext *context, void * pFKC_)
{
    TRdrInfoAuthTypeEKE teke;
    TSupErr code= SUP_ERR_NO;
    TCHAR friendlyname[NAME_LENTH+1];
    LPTOKEN_CONTAINER pFKC = (LPTOKEN_CONTAINER)pFKC_;
    size_t sizeo = sizeof(TRdrInfoAuthTypeEKE);

    memset(&teke, 0, sizeof(teke)); /* dim: made Valgrind happy */
    teke.size_of = sizeof(TRdrInfoAuthTypeEKE);

    printf ("auth_type started\n");
    code = rdr_auth_type(context,CH2P(TRdrInfoAuthTypeEKE,&teke),&sizeo);
    printf ("auth_type finished:\n");

    if (code == SUP_ERR_NO) {
#ifdef PRINT_COMMENT	
	printf("Get authtype success.\n");
#endif
	if (_tcslen(teke.tFriendlyName)!=0) {
	    _2asciicpy((LPSTR)pFKC->friendlyname,teke.tFriendlyName);
//	    printf ("\tfriendly name = %S\n", teke.tFriendlyName);
	} else {
	    pFKC->friendlyname[0] = 0;
	    printf ("\tfriendly name has 0 length\n");
	}

	pFKC->logType = teke.type;

	printf("\t Auth Type = 0x%x\n", teke.type);
//	printf("\t FriendlyName = %s\n", pFKC->friendlyname);

	makeCounters(&(pFKC->C), &(teke.c));
	
	printf("\t Counters:\n");
	printf("\t\t DH = %u\n", pFKC->C.c_dh);
	printf("\t\t SIG = %u\n", pFKC->C.c_sig);
	printf("\t\t EKE = %u\n", pFKC->C.c_eke);
	printf("\t\t SFLS = %u\n", pFKC->C.c_seqfls);
	printf("\t\t FLS = %u\n", pFKC->C.c_fls);

	pFKC->dwKeySpec = teke.bEnableDH ? AT_KEYEXCHANGE : AT_SIGNATURE;

//	printf("\t keySpec = %s\n", (teke.bEnableDH)?"AT_KEYEXCHANGE":"AT_SIGNATURE");
	DWORDtosrtOID((LPSTR)pFKC->pszKeyOID, teke.uiIDg, teke.bEnableDH);
	_ascii2cpy(friendlyname, (LPSTR)pFKC->pszKeyOID);
	printf("\t oid = %s\n", pFKC->pszKeyOID);
    }
    return code;
}

DWORD Test_FKCAdminCreate(TSupSysEContext * ctx, TSupSysEContext * dupctx, LPTSTR pszFKCContainerName, DWORD dwKeySpec, char * pszKeyOID, LPSTR pszPW, BOOL skey)
{
    DWORD err;
    LPTOKEN_CONTAINER pCSP=NULL;
    DWORD oid;
    DWORD dwBlobLen;
    DWORD dwControl = CRYPT_VERIFYCONTEXT | FKC_GENKEY;
    TCHAR pssswd [] = _TEXT("wonder");
    TCHAR newPW [] = _TEXT("qwerty");
    BYTE point [(2*SECRET_KEY_LEN)];
    BYTE qs [(2*SECRET_KEY_LEN)];
    TOKEN_DATA send;
 
    printf ("FKCAdminCreate started\n\n");
    err = IntCSPTContainer(pszFKCContainerName, dwControl, dwKeySpec, pszKeyOID, &pCSP);
    if(err) goto done;

    ZeroMemory(&send,sizeof(TOKEN_DATA));//src

    dwBlobLen = pCSP->dwPubBlobLen;

    err = CSPCreateTContainer(pszPW, pCSP);
    if(err) goto done;
    /* ������ Q_csp */
    err = SetPublicKeyBlob_test(pCSP);
    if(err) goto done;
    /*--- CSP ---*/
    /*  Q_s  */
    err = SetDataPublicTokenContainer(id_Q_S,(BYTE*)&(SaltPublic[pCSP->Num_ECC-1][0][0]),dwBlobLen,pCSP);
    if(err) goto done;
    /* CSP ������ Qpw, Qpw_0*/
    /* dim: ��� ���������� ������ pCSP->pbPWPublicKeyBlob_d */
    /* dim: ��������� ������ */
    if(!pCSP->pbPWPublicKeyBlob) {
	err = FKCCreatePWPublic(pCSP,pszPW_0);
	if(err)
	    goto done;
	pCSP->pbPWPublicKeyBlob = pCSP->pbPWPublicKeyBlob_d;
	pCSP->pbPWPublicKeyBlob_d = NULL;
	CryptDestroyKey(pCSP->hKeyPW_Pair);
	pCSP->hKeyPW_Pair = 0;
	CryptDestroyKey(pCSP->hKeyPW);
	pCSP->hKeyPW = 0;

	Printf_ECCPoint((LPDWORD)pCSP->pbPWPublicKeyBlob, "Q_PW 0 =");
    }

    err = FKCCreatePWPublic(pCSP,pszPW);
    free(pCSP->pbPWPublicKeyBlob_d); /* dim: �� �����. ��� ����� ��� ���������� ������ */
    pCSP->pbPWPublicKeyBlob_d = NULL;
    CryptDestroyKey(pCSP->hKeyPW_Pair);
    pCSP->hKeyPW_Pair = 0;
    if(err) goto done;

    makePointFromBlob_t(point, pCSP->pbPWPublicKeyBlob);
    makePointFromBlob_t(qs, pCSP->pbSaltPublicBlob);

    oid = srtOIDtoDWORD(pszKeyOID);
    err = reader_test_fkc_folder_create(ctx, pszFKCContainerName, oid, (dwKeySpec!=AT_SIGNATURE));
    if(err) goto done;
    if (skey) {
	static const BYTE dFKC[] = { 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,
				     0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
	BYTE syncro[RDR_FKC_SYNCRO_SIZE];
	memset(pCSP->syncro,0,8);
	if (!CryptGenRandom(pCSP->hContainer,RDR_FKC_SYNCRO_SIZE,pCSP->syncro+8)) {
	    err = GetLastError();
	    goto done;
	}
	/*������������ ������� random-��������, �� ������-�� ����� le2be(dFKC)*/

	be2le_t(syncro,pCSP->syncro+8,RDR_FKC_SYNCRO_SIZE);
	err = reader_test_fkc_set_key(ctx, pssswd, point, qs, dFKC, syncro);
	if(err) goto done;
    } else {
	err = reader_test_fkc_gen_key(ctx, pssswd, point, qs);
	if(err) goto done;
    }
    err = testAuthChall(ctx, pCSP);
    if(err) goto done;
    err = testAuthChange(ctx, pCSP, newPW);
    if(err) goto done;
    err = reader_test_folder_close(ctx);
    if(err) goto done;

    err = Test_FKCAdminOpenAndTest(ctx, dupctx, pszFKCContainerName, dwKeySpec, pszKeyOID, newPW);
    if(err) goto done;
    printf("first Open Test finished\n");
    err = Test_FKCAdminOpenAndTest(ctx, dupctx, pszFKCContainerName, dwKeySpec, pszKeyOID, newPW);
    if(err) goto done;
    printf("second Open Test finished\n");

    err = reader_test_fkc_folder_open(ctx, pszFKCContainerName, (dwKeySpec!=AT_SIGNATURE));
    if(err) goto done;
    err = reader_test_folder_clear(ctx);
 
done:
    if (err)
	printf ("Full FKC test FAILED\n");
    FKCtstReleaseTContainer(pCSP);
    return err;
}

static USHORT makeSygma2BE(USHORT s) 
{
    return ((s&0xff00)>>8)|((s&0xff)<<8);
}

static USHORT makeSygma2LE(USHORT s) 
{
    return ((s&0xff00)>>8)|((s&0xff)<<8);
}

static DWORD makeDWORD2LE(DWORD be) 
{
    return ((be&0xFF000000)>>24)|((be&0xFF0000)>>8)|((be&0xFF00)<<8)|((be&0xFF)<<24);
}

static void makeCounters(COUNTS *dest, TRdrFkcInfoCounters *src)
{
    dest->c_dh = makeDWORD2LE((*src)[TRIFc_DH]);
    dest->c_eke = makeDWORD2LE((*src)[TRIFc_EKE]);
    dest->c_fls = makeDWORD2LE((*src)[TRIFc_fail]);
    dest->c_seqfls = makeDWORD2LE((*src)[TRIFc_cfail]);
    dest->c_sig = makeDWORD2LE((*src)[TRIFc_Sign]);
}

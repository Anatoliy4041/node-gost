#include "tst12prj.h" /*+ Project (READER/FAT12/TEST) include.
    ������ include ���� ��� ������� (READER/FAT12/TEST). +*/
#include <stdio.h>

void
Printf_B_(LPBYTE pB, DWORD dwLen, LPSTR pstr) 
{
    int i;
    if(pB) {
	printf("\n%s ",pstr);
	for(i=0;i<(int)dwLen;i++) {
	    if(i%4==0)printf(" ");
	    printf("%02lx",(unsigned long)pB[i]);
	}
	printf("\n");
    }
}

#ifdef PRINT_SIGMA
void Printf_B_BE(LPBYTE pB, DWORD dwLen, LPSTR pstr)
{
    int i;
    if(pB) {
       printf("\n%s ",pstr);
       for(i=(int)dwLen-1;i>=0;i--) {
           if((dwLen-1-i)%4==0)printf(" ");
           printf("%02lx",(unsigned long)pB[i]);
       }
       printf("\n");
    }
}
#else
void Printf_B_BE(LPBYTE pB, DWORD dwLen, LPSTR pstr)
{
UNUSED(pB);UNUSED(dwLen);UNUSED(pstr);
}
#endif

#ifdef PRINT_COMMENT
void Print_PW(DWORD Direct,LPSTR pszPW)
{
    if(Direct==CSP_C)
	printf("\n------------------------------CSP Set PW %s",pszPW);
    else
	printf("\n------------------------------FKC Set PW %s",pszPW);
}
#else
void Print_PW(DWORD Direct,LPSTR pszPW)
{
    UNUSED(Direct);UNUSED(pszPW);
}
#endif

#ifdef PRINT_ECC_POINT
void
Printf_ECCPoint(LPDWORD pB, LPSTR pstr) 
{ /* Big Endian */
    int i;
    LPBYTE ptB = ((LPBYTE)pB)+PUBLICBLOBLEN-(2*SECRET_KEY_LEN);
    if(pB) {
	printf("\n%s ",pstr);
	printf("\n x= ");
	for(i=31;i>=0;i--) {
	    if(i%4==3)printf(" ");
	    printf("%02lx",(unsigned long)ptB[i]);
	}
	printf("\n y= ");
	for(i=31;i>=0;i--) {
	    if(i%4==3)printf(" ");
	    printf("%02lx",(unsigned long)ptB[i+SECRET_KEY_LEN]);
	}
    }
    printf("\n");
}
#else
void
Printf_ECCPoint(LPDWORD pB, LPSTR pstr) 
{
    UNUSED(pB); UNUSED(pstr);
}
#endif

#ifdef PRINT_ECC_POINT
void Printf_PublicBlob(LPBYTE pB, LPSTR pstr) 
{ /* Big Endian */
    unsigned i;
    LPBYTE ptB = (LPBYTE)pB;
 
    if(pB) {
	printf("\n%s ",pstr);
	printf(" h=");
	for(i=0;i<PUBLICBLOBLEN-(2*SECRET_KEY_LEN);i++) {
	    if(i%4==0)printf(" ");
	    printf("%02lx",(unsigned long)ptB[i]);
	}
	ptB = ((LPBYTE)pB)+PUBLICBLOBLEN-(2*SECRET_KEY_LEN);
	printf("\n x= ");
	for(i=31;i>=0;i--) {
	    if(i%4==3)printf(" ");
	    printf("%02lx",(unsigned long)ptB[i]);
	}
	printf("\n y= ");
	for(i=31;i>=0;i--) {
	    if(i%4==3)printf(" ");
	    printf("%02lx",(unsigned long)ptB[i+SECRET_KEY_LEN]);
	}
    }
}
#else
void Printf_PublicBlob(LPBYTE pB, LPSTR pstr) 
{ /* Big Endian */
    UNUSED(pB); UNUSED(pstr);
}
#endif

void  be2le_t(unsigned char *pdst, unsigned char *psrc, DWORD dwLen) 
{
    unsigned char *ptmp = psrc + dwLen - 1;
    DWORD i;
    for(i=0; i < dwLen; i++) *(pdst + i) = *(ptmp - i);
}

DWORD le2be_d2s (DWORD src) {    

#ifdef WORDS_BIGENDIAN
    return src>>16;
#else /* WORDS_BIGENDIAN */
    return src;
#endif /* WORDS_BIGENDIAN */
}


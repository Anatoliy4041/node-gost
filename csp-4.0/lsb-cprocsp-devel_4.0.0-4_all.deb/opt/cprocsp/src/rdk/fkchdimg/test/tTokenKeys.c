#include "tst12prj.h" /*+ Project (READER/FAT12/TEST) include.
    ������ include ���� ��� ������� (READER/FAT12/TEST). +*/
#include <stdio.h>

void
FKCtstReleaseTContainer( LPTOKEN_CONTAINER psRootKeys)
{
  if(!psRootKeys) return;
  if((psRootKeys->hKeyPair)!=0)	CryptDestroyKey( psRootKeys->hKeyPair);
  if((psRootKeys->hPublicKey)!=0) CryptDestroyKey( psRootKeys->hPublicKey);
  if((psRootKeys->hKeyPW)!=0) CryptDestroyKey( psRootKeys->hKeyPW);

  if((psRootKeys->hKeyPW_Pair)!=0) CryptDestroyKey( psRootKeys->hKeyPW_Pair);
  if((psRootKeys->hPWPublicKey)!=0) CryptDestroyKey( psRootKeys->hPWPublicKey);
  if((psRootKeys->hKey_A)!=0) CryptDestroyKey( psRootKeys->hKey_A);
  if((psRootKeys->hEKEAgree_A_B)!=0) CryptDestroyKey( psRootKeys->hEKEAgree_A_B);

  if((psRootKeys->hUserPublicKey)!=0) CryptDestroyKey( psRootKeys->hUserPublicKey);
  if((psRootKeys->hFKCPublicKey)!=0) CryptDestroyKey( psRootKeys->hFKCPublicKey);

  if((psRootKeys->hContainer)!=0) CryptReleaseContext( psRootKeys->hContainer,0);
    
  if(psRootKeys->pbPublicKeyBlob) free(psRootKeys->pbPublicKeyBlob);
  if(psRootKeys->pbUserPublicKeyBlob) free(psRootKeys->pbUserPublicKeyBlob);
  if(psRootKeys->pbFKCPublicKeyBlob) free(psRootKeys->pbFKCPublicKeyBlob);
  if(psRootKeys->pbPWPublicKeyBlob) free(psRootKeys->pbPWPublicKeyBlob);
  if(psRootKeys->pbSaltPublicBlob) free(psRootKeys->pbSaltPublicBlob);
  
  free(psRootKeys);
}

DWORD 
IntCSPTContainer(LPTSTR pszTokenName, DWORD dwControl,
		 DWORD dwKeySpec,char *  pszKeyOID,
		 LPTOKEN_CONTAINER* ppCSP)
{
    LPTOKEN_CONTAINER pCSP=NULL;
    HCRYPTPROV	hCSP=0;
    TCHAR CSPName[NAME_LENTH];	
    DWORD err = 0;
    TSupErr code = SUP_ERR_NO;
    TCHAR * prov_name = NULL;
    size_t prov_name_len = 0;

    pCSP = malloc(sizeof(TOKEN_CONTAINER));
    if(!pCSP) {
	SetLastError((DWORD)NTE_NO_MEMORY);
	return (DWORD)NTE_NO_MEMORY;
    }

    ZeroMemory(pCSP,sizeof(TOKEN_CONTAINER));

    _tcscpy(pCSP->TokenName,pszTokenName);
    _2asciicpy((LPSTR)pCSP->UniqueTokenName,pszTokenName);
    _tcscpy(CSPName,pszTokenName);
    _tcscat(CSPName,_TEXT("_CSP"));
    strcpy((char*)pCSP->pszKeyOID,pszKeyOID);
    pCSP->dwKeySpec = dwKeySpec;
    pCSP->dwControl = dwControl;

    code = support_registry_get_string (FKCHDIMG_PATH, &prov_name_len, NULL);
    if (code) {
	printf ("Test is going to start on default provider. Please install FKCHDIMG\n");
	prov_name = NULL;
    }
    else {
	prov_name = malloc ((prov_name_len + 1) * sizeof (TCHAR));
	if (!prov_name) {
	    err = (DWORD) NTE_NO_MEMORY;
	    goto done;
	}
	code = support_registry_get_string (FKCHDIMG_PATH, &prov_name_len, prov_name);
	if (code) {
	    printf ("Test is going to start on default provider. Please configure FKCHDIMG\n");
	    free (prov_name);
	    prov_name = NULL;
	}
    }

    if(!CryptAcquireContext(&hCSP, NULL, prov_name, PROV_GOST_2001_DH, CRYPT_VERIFYCONTEXT |CRYPT_TOKEN_SHARED)) {
	err = GetLastError();
	if (err == (DWORD)NTE_BAD_FLAGS) {
	    printf ("Underlying provider does not support CRYPT_TOKEN_SHARED flag\n");
	}
	goto done;
    }

    free (prov_name);
    pCSP->hContainer = hCSP;
    pCSP->dwPubBlobLen = PUBLICBLOBLEN;
    *ppCSP = pCSP;
    return 0;

done:
    free (prov_name);
    free(pCSP);
    return err;
}

DWORD
CSPCreateTContainer(LPSTR pszPW, LPTOKEN_CONTAINER psRootKeys)
{
    HCRYPTPROV	hCreateContaner=psRootKeys->hContainer;
    DWORD dwKeySpec = psRootKeys->dwKeySpec;
    DWORD err=0, dwControl = psRootKeys->dwControl;
    LPCSTR pszKeyOID = (LPCSTR)psRootKeys->pszKeyOID;

    psRootKeys->aAlgId = CALG_GR3410EL;
    if(dwKeySpec==AT_KEYEXCHANGE)
	psRootKeys->aAlgId = CALG_DH_EL_EPHEM;

    if(psRootKeys->pszKeyOID) {
	if(dwKeySpec==AT_SIGNATURE) {
	    if(!CryptSetProvParam( hCreateContaner,PP_SIGNATUREOID,(LPBYTE)pszKeyOID,0)) {
		err = GetLastError();
		return err;
	    }
	}
	if(dwKeySpec==AT_KEYEXCHANGE) {
	    if(!CryptSetProvParam( hCreateContaner,PP_DHOID,(LPBYTE)pszKeyOID,0)) {
		err = GetLastError();
		return err;
	    }
	}
	if(!strcmp(pszKeyOID,OID_ECCSignDHOSCAR) )	    
	    psRootKeys->Num_ECC = 1;
	if(!strcmp(pszKeyOID,OID_ECCSignDHPRO) )
	    psRootKeys->Num_ECC = 2;
	if(!strcmp(pszKeyOID,OID_ECCSignDHVar_1) )
	    psRootKeys->Num_ECC = 3;
	if(!strcmp(pszKeyOID,OID_ECCDHPRO) )
	    psRootKeys->Num_ECC = 4;
	if(!strcmp(pszKeyOID,OID_ECCDHPVar_1) )
	    psRootKeys->Num_ECC = 5;
    } else {
	err = S_FALSE;
	goto done;
    }

  /*��������� ������ ����������� � ��������� ������ ���������� */
    if(pszPW) {
	if(!CryptSetProvParam( hCreateContaner,PP_SIGNATURE_PIN,(LPBYTE)pszPW,0)) {
	    err = GetLastError();
	    printf("Faild CryptSetProvParam( PP_SIGNATURE_PIN)");
	    goto done;
	}
	Print_PW(CSP_C,pszPW);
    } else {
	printf("\n  PASSWORD Mast be Set   \n");
	err = S_FALSE;
	goto done;
    }

    /* �������� / �������� ����� */
    if((dwControl&FKC_GENKEY)==FKC_GENKEY)
	dwControl=(dwControl^FKC_GENKEY)|CRYPT_NEWKEYSET;
    if((dwControl&CRYPT_NEWKEYSET)==CRYPT_NEWKEYSET) {/*Gen Key*/
	if(!CryptGenKey(hCreateContaner, dwKeySpec, CRYPT_TOKEN_SHARED, &psRootKeys->hKeyPair)) {
	    err = GetLastError();
	    goto done;
	}
    } else { /*Open Key*/
	if((dwControl & CRYPT_VERIFYCONTEXT)==CRYPT_VERIFYCONTEXT) {
	    if(!CryptGenKey(hCreateContaner, dwKeySpec, CRYPT_TOKEN_SHARED, &psRootKeys->hKeyPair)) {
		err = GetLastError();
		goto done;
	    }
	} else {/*(dwControl & CRYPT_VERIFYCONTEXT)==CRYPT_VERIFYCONTEXT*/
	    if(!CryptGetUserKey(hCreateContaner, dwKeySpec, &psRootKeys->hKeyPair)) {
		err = GetLastError();
		printf("%s:%d: Error %lx during GetUserKey!\n", __FILE__, __LINE__, (unsigned long)err);
		goto done;
	    } 
	}/*(dwControl & CRYPT_VERIFYCONTEXT)==CRYPT_VERIFYCONTEXT*/
    }/*Open Key*/

done:
    return err;
}

DWORD
FKCTCreateUserPublicKey(HCRYPTPROV hProv,
			LPBYTE pbPkeyBlobCSP, LPBYTE pbPkeyBlobFKC, DWORD dwBlobLen, DWORD dwECCSign,
			HCRYPTKEY* phUserPubKey, LPBYTE* ppbUserPubKeyBlob)
{
    HCRYPTKEY hPubKey=0;
    DWORD err =0;

    if(!pbPkeyBlobCSP || !pbPkeyBlobFKC)
	return S_FALSE;
    if(*phUserPubKey)
	return S_FALSE;
  /* CSP Public key */
    if(!CryptImportKey(hProv,pbPkeyBlobCSP,dwBlobLen,0,0,&hPubKey)) { 
	err = GetLastError();
    }
    if(err) goto done;
  /* Public key */
    if(!CryptImportKey(hProv, pbPkeyBlobFKC, dwBlobLen, hPubKey, dwECCSign ? CRYPT_ECCNEGATIVE : 0, phUserPubKey)) {
	err = GetLastError();
    }
    if(err) goto done;
  /* Public key Blob*/
    *ppbUserPubKeyBlob = malloc(dwBlobLen);	
    if(!*ppbUserPubKeyBlob) {
	err = (DWORD) NTE_NO_MEMORY;
	goto done;
    }
    if(!CryptExportKey(*phUserPubKey, 0, PUBLICKEYBLOB, 0, *ppbUserPubKeyBlob, &dwBlobLen)) {
	err = GetLastError();
    };
    if(err) goto done;
done:
    if(hPubKey) CryptDestroyKey(hPubKey);
    return err;
}

DWORD CreatePublicKeyBlob_test(HCRYPTKEY hKeyPair, DWORD* pdwPubBlobLen, LPBYTE* ppPubKeyBlob)
{
    DWORD err=0, dwBlobLen;

    if(!CryptExportKey(hKeyPair, 0, PUBLICKEYBLOB, 0, NULL, &dwBlobLen)) {
	err = GetLastError();
    }
    if(err) {
	printf("Error %lx computing blob length!\n", (unsigned long)GetLastError());
	goto done;
    }
    *ppPubKeyBlob = malloc(dwBlobLen);	
    if(!*ppPubKeyBlob) {
	err = (DWORD) NTE_NO_MEMORY;
	goto done;
    }
    *pdwPubBlobLen=dwBlobLen;
    if(!CryptExportKey(hKeyPair, 0, PUBLICKEYBLOB, 0, *ppPubKeyBlob, &dwBlobLen)) {
	err = GetLastError();
    }
    if(err) {
	printf("Error %lx during CPExportKey!\n", (unsigned long)GetLastError());
	goto done;
    }
done:
    return err;
}

DWORD srtOIDtoDWORD(const char * pszKeyOID) {
    DWORD oid = RDR_FKC_IDG_CP_OPTIONAL_PARAMSET;

    if ((!strcmp(pszKeyOID,szOID_GostR3410_2001_CryptoPro_XchA_ParamSet))||
	(!strcmp(pszKeyOID,szOID_GostR3410_2001_CryptoPro_A_ParamSet))) {
	    oid = RDR_FKC_IDG_CP_A_PARAMSET;
    }
    if (!strcmp(pszKeyOID,szOID_GostR3410_2001_CryptoPro_B_ParamSet)) {
	    oid = RDR_FKC_IDG_CP_B_PARAMSET;
    }
    if ((!strcmp(pszKeyOID,szOID_GostR3410_2001_CryptoPro_XchB_ParamSet))||
	(!strcmp(pszKeyOID,szOID_GostR3410_2001_CryptoPro_C_ParamSet))) {
	    oid = RDR_FKC_IDG_CP_C_PARAMSET;
    }
    return oid;
}

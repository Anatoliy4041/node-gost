#include "fkchdimgprj.h"

TSupErr uechdimg_file_close( TSupSysContext *context, TSupSysInfo *info )
{
    TReaderInfoClose *inf = (TReaderInfoClose*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;
    TSupErr code = SUP_ERR_NO;

    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );
    SUPSYS_PRE_INFO( info, TReaderInfoClose );

    code = support_registry_put_hex((TCHAR*)ctx->path, ctx->file_length, ctx->file);

    ctx->file_length = 0;
    ctx->file_id = 0;

    if (ctx->file)
	free (ctx->file);
    ctx->file = NULL;
    ctx->path = NULL;

    inf->size_of = sizeof( TReaderInfoClose );
    return code;
}

#include "fkchdimgprj.h"

TSupErr uechdimg_file_read( TSupSysContext *context, TSupSysInfo *info )
{
    TReaderInfoRead *inf = (TReaderInfoRead*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );
    SUPSYS_PRE_INFO( info, TReaderInfoRead );
    SUPSYS_PRE_WRITE_PTRS( inf->info.info, inf->info.length );

	inf->size_of = sizeof( TReaderInfoRead );
    if( ctx->file_length < inf->from )
    {
	inf->info.length = 0;
	return SUP_ERR_NO;
    }
    if( ctx->file_length - inf->from > inf->info.length )
	inf->info.length = inf->info.length;
    else
	inf->info.length = ctx->file_length - inf->from;
    memcpy( inf->info.info, ctx->file + inf->from, inf->info.length );
    inf->info.length = 0;
    return SUP_ERR_NO;
}

/*
 * Copyright(C) 2000 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/*!
 * \file $RCSfile$
 * \version $Revision: 126987 $
 * \date $Date:: 2015-09-08 17:51:58 +0400#$
 * \author $Author: pav $
 * \brief ������� ���������� ��������������
 */

#include "fkchdimgprj.h"

/*todo*/
TSupErr fkchdimg_eke_auth_change ( 
    TSupSysContext *context, 
    TSupSysInfo *info )
{
    TReaderInfoAuthChallenge * chal = (TReaderInfoAuthChallenge *)info;
    TFKCHDImgContext * ctx = (TFKCHDImgContext*)context;
    TSupErr err;

    SUPSYS_PRE_CONTEXT( context, TFKCHDImgContext );
    SUPSYS_PRE_INFO( info, TReaderInfoAuthChange );

    SUPSYS_PRE(TRLIT_class(chal->type)==TRLITc_eke);
    SUPSYS_PRE(TRLIT_type(chal->type)==TRLITt_container);
        
    err = init_read(ctx);
    if (err) goto done;

    err = RDR_ERR_BLOCK;

    if(isCNULL(ctx)
	||(chal->id == TRECi_syncro)
	||(chal->id == TRECi_Qfkc)) 
    {
	err= SUP_ERR_PARAM;
	goto done;
    }

    if( !ctx->auth) {
	err = RDR_ERR_FKC_NEED_CONT_AUTH;
	goto done;
    }

    if (!ctx->cont.C.c_eke) {
	err = RDR_ERR_FKC_OPLIMIT_REACHED;
	goto doneErr;
    }

    switch(chal->Class)
    {
#if _DEBUG
    case TRECc_first_dbg:
	{
	    BYTE u1point [PUBLICBLOBLEN];
	    BYTE u2point [PUBLICBLOBLEN];
	    BYTE secretB [SECRET_KEY_LEN];
	    const TRdrFkcEKEChallengeFirst2fkc_debug * _2fkc;
	    TRdrFkcEKEChallengeFirst2csp * _2csp;
	    
	    _2fkc = CONSTP2CH(TRdrFkcEKEChallengeFirst2fkc_debug, chal->toFolder);
	    _2csp = P2CH(TRdrFkcEKEChallengeFirst2csp, chal->fromFolder);
	    //SUPSYS_PRE_INFO( (TRdrFkcEKEChallengeFirst2fkc*)_2fkc, TRdrFkcEKEChallengeFirst2fkc );

	    if (_2fkc->IsNewTr == FKC_TRANSACTION_IS_NEW) {
		ctx->cont.curmask = FKC_TRANS_SET_ZERO;
		ctx->cont.curtrid = _2fkc->TrId;
	    } else {
		if (ctx->cont.curtrid) {
		    if (ctx->cont.curtrid != _2fkc->TrId) {
			err = RDR_ERR_FKC_TRANSACTION;
			goto done;
		    }
		}
	    }

	    if (ctx->cont.lpEKEop) eke_cont_release (ctx->cont.lpEKEop);
	    eke_cont_init(&(ctx->cont.lpEKEop));

	    ctx->cont.lpEKEop->curChalClass = TRECc_first;
	    ctx->cont.lpEKEop->curChalID = chal->id;

	    makePublicBlob(&ctx->cont,u1point,(LPBYTE)_2fkc->u1.x, (LPBYTE)_2fkc->u1.y);
	    err = isInCurve(&ctx->cont, u1point);
	    if (err) {
		err = SUP_ERR_PARAM;
		goto done;
	    }
	    be2le(secretB,(LPBYTE)_2fkc->betta.v,SECRET_KEY_LEN);
	    err = FKCCreateEKE (&ctx->cont, u1point, secretB, chal->id, u2point);
	    memset(secretB,0,SECRET_KEY_LEN);
	    if (err) {
		err = SUP_ERR_CANCEL;
		goto done;
	    }
	    makePointFromBlob(_2csp->u2.x,_2csp->u2.y,u2point);

	    err = RDR_ERR_BLOCK;
	}
	break;
#endif /*_DEBUG*/

    case TRECc_first:
	{
	    BYTE u1point [PUBLICBLOBLEN];
	    BYTE u2point [PUBLICBLOBLEN];
	    const TRdrFkcEKEChallengeFirst2fkc * _2fkc;
	    TRdrFkcEKEChallengeFirst2csp * _2csp;
	    
	    _2fkc = CONSTP2CH(TRdrFkcEKEChallengeFirst2fkc, chal->toFolder);
	    _2csp = P2CH(TRdrFkcEKEChallengeFirst2csp, chal->fromFolder);
	    //SUPSYS_PRE_INFO( (TRdrFkcEKEChallengeFirst2fkc*)_2fkc, TRdrFkcEKEChallengeFirst2fkc );

	    if (_2fkc->IsNewTr == FKC_TRANSACTION_IS_NEW) {
		ctx->cont.curmask = FKC_TRANS_SET_ZERO;
		ctx->cont.curtrid = _2fkc->TrId;
	    } else {
		if (ctx->cont.curtrid) {
		    if (ctx->cont.curtrid != _2fkc->TrId) {
			err = RDR_ERR_FKC_TRANSACTION;
			goto done;
		    }
		}
	    }

	    if (ctx->cont.lpEKEop) eke_cont_release (ctx->cont.lpEKEop);
	    eke_cont_init(&(ctx->cont.lpEKEop));

	    ctx->cont.lpEKEop->curChalClass = TRECc_first;
	    ctx->cont.lpEKEop->curChalID = chal->id;

	    makePublicBlob(&ctx->cont,u1point,(LPBYTE)_2fkc->u1.x, (LPBYTE)_2fkc->u1.y);
	    err = isInCurve(&ctx->cont, u1point);
	    if (err) {
		err = SUP_ERR_PARAM;
		goto done;
	    }
	    err = FKCCreateEKE (&ctx->cont, u1point, NULL, chal->id, u2point);
	    if (err) {
		err = SUP_ERR_CANCEL;
		goto done;
	    }
	    makePointFromBlob(_2csp->u2.x,_2csp->u2.y,u2point);

	    err = RDR_ERR_BLOCK;
	}

	break;
    case TRECc_second:
	if (!ctx->cont.lpEKEop||
	    (ctx->cont.lpEKEop->curChalClass!=TRECc_first)||
	    ((int)ctx->cont.lpEKEop->curChalID != chal->id)) 
	{
	    err = SUP_ERR_PARAM;
	    goto done;
	}

	switch(chal->id) 
	{
	case TRECi_syncroBIS:
	    {
		DWORD s1;
		const TRdrFkcEKEChallengeWriteSyncro2fkc * _2fkc;
		TRdrFkcEKEChallengeWriteSyncro2csp * _2csp;
		BYTE mkpbData [SECRET_KEY_LEN];
			    
		_2fkc = CONSTP2CH(TRdrFkcEKEChallengeWriteSyncro2fkc, chal->toFolder);
		_2csp = P2CH(TRdrFkcEKEChallengeWriteSyncro2csp, chal->fromFolder);

		if ( ctx->cont.C.c_seqfls && ctx->cont.C.c_fls) 
		{
		    ctx->cont.C.c_seqfls--;
		    ctx->cont.C.c_fls--;
		} else {
		    err = RDR_ERR_FKC_OPLIMIT_REACHED;
		    goto doneErr;
		}

		if (ctx->cont.curtrid) {
		    if (ctx->cont.curtrid != _2fkc->TrId) {
			err = RDR_ERR_FKC_TRANSACTION;
			goto done;
		    }
		}

		s1 = makeSygma2LE(_2fkc->uiS1);
		memset(mkpbData, 0, 8);
		be2le(mkpbData+8, (BYTE*)_2fkc->u3.v, 24);

		err = FKCCreateEKEVerify(chal->id,&ctx->cont,mkpbData,ctx->names.RealName, 
					    ctx->names.FriendlyName);
		if(err) goto doneErr;
    
		err = FKCEKEEncrypt(ctx->cont.lpEKEop, CRYPT_MODE_EKEXOR, 
				    FALSE, mkpbData, SECRET_KEY_LEN);
		if(err) {
		    err = RDR_ERR_INVALID_PASSWD_FORMAT;
		    goto doneErr;
		}
		memset(mkpbData, 0, 2*sizeof(DWORD));

		err = FKCVerifyEKE(ctx->cont.lpEKEop, s1);
		if(err) {
		    memset (mkpbData, 0, SECRET_KEY_LEN);
		    err = RDR_ERR_INVALID_PASSWD;
		    goto doneErr;
		}

		memcpy(ctx->cont.syncroNew,mkpbData,SECRET_KEY_LEN);
		ctx->cont.readyChange|=1;

		_2csp->uiS2 = makeSygma2BE((USHORT)ctx->cont.lpEKEop->Verify_B);
		memset (mkpbData, 0, SECRET_KEY_LEN);

		ctx->cont.C.c_fls++;
		ctx->cont.C.c_seqfls = C_SEQ_FALSE;
	    }
	    break;
	case TRECi_deltaBIS:
	    {
		BYTE prntdelta [SECRET_KEY_LEN];
		const TRdrFkcEKEChallengeWriteDelta2fkc * _2fkc;
		BYTE mkpbData [SECRET_KEY_LEN];
			    
		_2fkc = CONSTP2CH(TRdrFkcEKEChallengeWriteDelta2fkc, chal->toFolder);

		if (ctx->cont.curtrid) {
		    if (ctx->cont.curtrid != _2fkc->TrId) {
			err = RDR_ERR_FKC_TRANSACTION;
			goto done;
		    }
		}

		be2le(mkpbData, (BYTE*)_2fkc->u3.v, SECRET_KEY_LEN);

		err = FKCEKEEncrypt(ctx->cont.lpEKEop, CRYPT_MODE_EKEXOR, 
				    TRUE, mkpbData, SECRET_KEY_LEN);
		if(err) {
		    goto doneErr;
		}

		be2le(prntdelta,mkpbData,SECRET_KEY_LEN);
		memcpy(ctx->cont.deltaNew,mkpbData,SECRET_KEY_LEN);
		ctx->cont.readyChange|=2;
	    }
	    break;
	case TRECi_Qpw:
	    {
		const TRdrFkcEKEChallengeWriteQPW2fkc * _2fkc;
		BYTE mkpbData [PUBLICBLOBLEN];
			    
		_2fkc = CONSTP2CH(TRdrFkcEKEChallengeWriteQPW2fkc, chal->toFolder);
		
		if (ctx->cont.curtrid) {
		    if (ctx->cont.curtrid != _2fkc->TrId) {
			err = RDR_ERR_FKC_TRANSACTION;
			goto done;
		    }
		}

		makePublicBlob(&ctx->cont,mkpbData,(LPBYTE)_2fkc->u3.x,(LPBYTE)_2fkc->u3.y);

		err = isInCurve(&ctx->cont,mkpbData);
		if (err) {
		    goto doneErr;
		}

		err = FKCEKEEncrypt(ctx->cont.lpEKEop, CRYPT_MODE_EKEECADD, 
				    ECC_PLUS, mkpbData, PUBLICBLOBLEN);
		if(err) {
		/*�������� kEKE �� ���� */
		    HCRYPTKEY hqpw = 0;
		    LPBYTE mkpbDataoth = NULL;
		    DWORD len = PUBLICBLOBLEN;
            	
		    if(!CryptGenKey(ctx->cont.hContainer,CALG_DH_EL_EPHEM,//pCSP->aAlgId,
			CRYPT_EXPORTABLE | CRYPT_PREGEN | CRYPT_TOKEN_SHARED,&hqpw)) 
		    {
			err = GetLastError();
			goto done; 
		    }

		    {
			DWORD dwParam = KP_SIGNATUREOID;
			if(ctx->cont.dwKeySpec == AT_KEYEXCHANGE) dwParam = KP_DHOID;
			if(!CryptSetKeyParam(hqpw,dwParam,(LPBYTE)ctx->cont.pszKeyOID,0))
			{
			    err = GetLastError();
			    CryptDestroyKey(hqpw);
			    goto done; 
			};
		    }
                
		    if(!CryptSetKeyParam(hqpw,KP_X,NULL,0))
		    {
			err = GetLastError();
			CryptDestroyKey(hqpw);
			goto done;
		    };

		    err = CreatePublicKeyBlob(hqpw,&len,&mkpbDataoth);
		    if (err) {
			CryptDestroyKey(hqpw);
			goto done;
		    };
		    CryptDestroyKey(hqpw);
		    memcpy (mkpbData,mkpbDataoth,PUBLICBLOBLEN);
		    free (mkpbDataoth);
		}

		if (ctx->cont.pbPWPublicKeyBlobNew) free (ctx->cont.pbPWPublicKeyBlobNew);
		ctx->cont.pbPWPublicKeyBlobNew = malloc (PUBLICBLOBLEN);
		memcpy(ctx->cont.pbPWPublicKeyBlobNew,mkpbData,PUBLICBLOBLEN);

		ctx->cont.readyChange|=4;
	    }
	    break;
	}
	if (ctx->cont.lpEKEop) eke_cont_release (ctx->cont.lpEKEop);
	ctx->cont.lpEKEop = NULL;
	err = RDR_ERR_BLOCK;
	ctx->cont.C.c_eke--;
	break;
    case TRECc_commit:
	{
	    BYTE mkpbData [PUBLICBLOBLEN];
	    const TRdrFkcEKEChallengeChangeMask2fkc * _2fkc;
	    TRdrFkcCommitMask mymask;

	    _2fkc = CONSTP2CH(TRdrFkcEKEChallengeChangeMask2fkc, chal->toFolder);

	    if (ctx->cont.curtrid) {
		if (ctx->cont.curtrid != _2fkc->TrId) {
		    err = RDR_ERR_FKC_TRANSACTION;
		    goto done;
		}
	    }

	    if (_2fkc->savemask == FKC_TRANS_SET_ALL) {
		mymask = FKC_TRANS_SET_SYNCRO_BIT | FKC_TRANS_SET_DELTA_BIT |
		    FKC_TRANS_SET_QPW_BIT | FKC_TRANS_SET_QS_BIT;
	    } else
	    {
		mymask = _2fkc->savemask;
	    }
	    if ((mymask&FKC_TRANS_SET_QS_BIT)==FKC_TRANS_SET_QS_BIT)
	    {
		makePublicBlob(&ctx->cont,mkpbData,(LPBYTE)_2fkc->uQs.x,(LPBYTE)_2fkc->uQs.y);

		err = isInCurve(&ctx->cont,mkpbData);
		if (err) {
		    goto doneErr;
		}
		if (!ctx->cont.pbSaltPublicBlob) ctx->cont.pbSaltPublicBlob = malloc(0x64);
		memcpy (ctx->cont.pbSaltPublicBlob, mkpbData, 0x64);
	    }
	    if ( (((mymask&FKC_TRANS_SET_SYNCRO_BIT)==FKC_TRANS_SET_SYNCRO_BIT) && ((ctx->cont.readyChange&1)!=1))
		 || (((mymask&FKC_TRANS_SET_DELTA_BIT)==FKC_TRANS_SET_DELTA_BIT) && ((ctx->cont.readyChange&2)!=2))
		 || (((mymask&FKC_TRANS_SET_QPW_BIT)==FKC_TRANS_SET_QPW_BIT) && ((ctx->cont.readyChange&4)!=4)))
	    {
		err = SUP_ERR_PARAM;
		memset (ctx->cont.syncroNew, 0, SECRET_KEY_LEN);
		memset (ctx->cont.deltaNew, 0, SECRET_KEY_LEN);
		if (ctx->cont.pbPWPublicKeyBlobNew) free (ctx->cont.pbPWPublicKeyBlobNew);
		ctx->cont.pbPWPublicKeyBlobNew = NULL;
		ctx->cont.readyChange = 0;
		goto doneErr;
	    }

	    if (((ctx->cont.readyChange&1)==1)&&((mymask&FKC_TRANS_SET_SYNCRO_BIT)==FKC_TRANS_SET_SYNCRO_BIT))
	    {
		memcpy (ctx->cont.syncro,ctx->cont.syncroNew,SECRET_KEY_LEN);
		memset (ctx->cont.syncroNew, 0, SECRET_KEY_LEN);
	    }
	    if (((ctx->cont.readyChange&2)==2)&&((mymask&FKC_TRANS_SET_DELTA_BIT)==FKC_TRANS_SET_DELTA_BIT))
	    {
		err = FKCSetDelta_e(&ctx->cont,ctx->cont.deltaNew);
		if (err) {
		    goto doneErr;
		}
		memset (ctx->cont.deltaNew, 0, SECRET_KEY_LEN);
	    }
	    if (((ctx->cont.readyChange&4)==4)&&((mymask&FKC_TRANS_SET_QPW_BIT)==FKC_TRANS_SET_QPW_BIT))
	    {
		if (!ctx->cont.pbPWPublicKeyBlob)  ctx->cont.pbPWPublicKeyBlob = malloc (PUBLICBLOBLEN);
		memcpy (ctx->cont.pbPWPublicKeyBlob, ctx->cont.pbPWPublicKeyBlobNew, PUBLICBLOBLEN);
		free (ctx->cont.pbPWPublicKeyBlobNew);
		ctx->cont.pbPWPublicKeyBlobNew = NULL;
	    }
	    ctx->cont.readyChange = 0;

	    /*������� ���� ��������� �����*/
	    err = SetPublicKeyBlob(&ctx->cont);
	    if (err) {
		goto doneErr;
	    }
	    ctx->auth = FALSE;
	    err = SUP_ERR_NO;
	}
	break;
    }

done:
doneErr:
    if (err && err != RDR_ERR_BLOCK) {
	switch (err) {
	    case RDR_ERR_INVALID_PASSWD_FORMAT:
	    case RDR_ERR_FKC_NEED_ROOT_AUTH:
	    case RDR_ERR_FKC_NEED_CONT_AUTH:
	    case SUP_ERR_PARAM:
	    case RDR_ERR_FKC_TRANSACTION:
	    case RDR_ERR_FKC_OPLIMIT_REACHED:
		break;
	    case RDR_ERR_INVALID_PASSWD:
		if (!ctx->cont.C.c_fls || !ctx->cont.C.c_seqfls) {
		    err = RDR_ERR_PASSWD_LOCKED;
		}
		break;
	    default:
		err = SUP_ERR_PARAM;
	}
	if (ctx->cont.lpEKEop) eke_cont_release (ctx->cont.lpEKEop);
	ctx->cont.lpEKEop = NULL;
    }
    fkchdimg_infofile_write(ctx);
    return err;
}


USHORT makeSygma2BE(USHORT s) 
{
    return ((s&0xff00)>>8)|((s&0xff)<<8);
}

USHORT makeSygma2LE(USHORT s) 
{
    return ((s&0xff00)>>8)|((s&0xff)<<8);
}

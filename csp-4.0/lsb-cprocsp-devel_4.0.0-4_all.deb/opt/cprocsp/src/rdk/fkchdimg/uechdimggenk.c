#include "fkchdimgprj.h"

static DWORD CreateKeyIntoRegistry (TUECHDImgContext * ctx, BYTE * pubKey) 
{
    HCRYPTPROV hProv = 0;
    HCRYPTKEY hKey = 0;
    HCRYPTKEY hKeyEnc = 0;
    HCRYPTHASH hHash = 0;
    BYTE * pass = (BYTE*) MAGIC_IMPORT_KEY_CONST;
    DWORD pass_len = (DWORD) strlen ((char*)MAGIC_IMPORT_KEY_CONST);
    ALG_ID ExportAlgid = CALG_PRO_EXPORT;  
    ALG_ID GenAlgID = CALG_DH_EL_SF;
    BYTE * key_blob = NULL;
    DWORD key_blob_length = 0;
    DWORD err = 0;
    TSupErr code = 0;
    BYTE * pubKey_blob = NULL;
    DWORD pubKey_blob_len = 0;
    DWORD keyind = 0;

    if (!CryptAcquireContext (&hProv, NULL, NULL, 75, CRYPT_VERIFYCONTEXT )){
	err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptAcquireContext: %x"), err));
	goto done;
    }
    if (!CryptSetProvParam(hProv, PP_SIGNATURE_PIN, (BYTE*)MAGIC_PIN, 0)) {
	err = GetLastError();
	//DbTrace(DB_TRACE, (FTEXT(db_ctx, "Error CryptSetProvParam: %x"), err));
	goto done;
    }
    if (!CryptGenKey(hProv, GenAlgID, CRYPT_EXPORTABLE, &hKey )) {
	err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptGenKey: %x"), err));
	goto done;
    }
    if (!CryptCreateHash(hProv, CALG_GR3411, 0, 0, &hHash)) {
	err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptCreateHash: %x"), err));
	goto done;
    }
    if (!CryptHashData(hHash, pass, pass_len, 0)) {
	err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptHashData: %x"), err));
	goto done;
    }
    if (!CryptDeriveKey(hProv, CALG_G28147, hHash, 0, &hKeyEnc)) {	
	err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptDeriveKey: %x"), err));
	goto done;
    }   
    if (!CryptSetKeyParam(hKeyEnc, KP_ALGID, (BYTE*)&ExportAlgid, 0)) {
	err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptSetKeyParam: %x"), err));
	goto done;
    }
    if (!CryptExportKey (hKey, hKeyEnc, PRIVATEKEYBLOB, 0, NULL, &key_blob_length)) {
	err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptExportKey: %x"), err));
	goto done;
    }
    key_blob = malloc (key_blob_length);
    if (!key_blob) {
	err = (DWORD) NTE_NO_MEMORY;
	goto done;
    }
    if (!CryptExportKey (hKey, hKeyEnc, PRIVATEKEYBLOB, 0, key_blob, &key_blob_length)) {
	err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptExportKey: %x"), err));
	goto done;
    }

    code = support_registry_put_hex (ctx->key_blob_path, key_blob_length, key_blob);
    if (code) {
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "support_registry_put_hex: %x"), err));
	err = (DWORD)NTE_FAIL;
	goto done;
    }

    if (!CryptExportKey(hKey, 0, PUBLICKEYBLOB, 0, NULL, &pubKey_blob_len)) {
	err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptExportKey: %x"), err));
	goto done;
    }

    pubKey_blob = malloc (pubKey_blob_len);
    if (!pubKey_blob) {
	err = (DWORD)NTE_NO_MEMORY;
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "Memory error: %x"), err));
	goto done;
    }

    if (!CryptExportKey(hKey, 0, PUBLICKEYBLOB, 0, pubKey_blob, &pubKey_blob_len)) {
	err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptExportKey: %x"), err));
	goto done;
    }

    keyind = pubKey_blob_len - RDR_FKC_POINT_SIZE;
    memcpy( pubKey, &pubKey_blob[keyind], RDR_FKC_POINT_SIZE );

done:
    if (pubKey_blob) free (pubKey_blob);
    if (key_blob) free (key_blob);
    if (hKeyEnc) CryptDestroyKey(hKeyEnc);
    if (hKey) CryptDestroyKey(hKey);
    if (hHash) CryptDestroyHash(hHash);
    if (hProv) CryptReleaseContext(hProv, 0);
    return err;
}

TSupErr uechdimg_new_key ( 
		      TSupSysContext *context, 
		      TSupSysInfo *info )
{
    DWORD err = 0;
    TReaderFkcKeyGen *inf = (TReaderFkcKeyGen*)info;
    BYTE pubKey[RDR_FKC_POINT_SIZE];
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    SUPSYS_PRE_INFO( info, TReaderFkcKeyGen );

    if (!inf->pubKey)
	return SUP_ERR_PARAM;

    err = CreateKeyIntoRegistry(ctx, &pubKey[0]);
    if (err)
	return err;

    memcpy( inf->pubKey, &pubKey[0], RDR_FKC_POINT_SIZE);
    return SUP_ERR_NO;
}

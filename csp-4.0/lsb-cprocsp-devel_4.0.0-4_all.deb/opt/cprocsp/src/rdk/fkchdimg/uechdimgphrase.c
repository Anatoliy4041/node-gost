#include "fkchdimgprj.h"

TSupErr uechdimg_auth_phrase( TSupSysContext *context, TSupSysInfo *info )
{
    TReaderInfoPasswdName *inf = (TReaderInfoPasswdName*)info;
    TSupErr code = 0;

    UNUSED (context);

    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );
    SUPSYS_PRE_INFO( info, TReaderInfoPasswdName );


    if (inf->term.length == 0 && inf->term.text == NULL) {
	inf->term.length = strlen((char*)AUTH_PHRASE);
	goto done;
    }
    inf->term.length = strlen((char*)AUTH_PHRASE);
    if (inf->term.text != NULL ) {
	_ascii2cpy(inf->term.text, (char*)AUTH_PHRASE);
    }
    inf->size_of = sizeof( TReaderInfoPasswdName );
done: 
    return code;
}

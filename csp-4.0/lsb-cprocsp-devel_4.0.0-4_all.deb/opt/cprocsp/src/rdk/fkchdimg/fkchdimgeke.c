#include "fkchdimgprj.h"

static const
LPCSTR e_[6] = {"syncro", "syncro\"", "delta\"", "Q\"_PW", "Q_FKC", "Q_S"};

static DWORD le2be_d2s (DWORD src) {    

#ifdef WORDS_BIGENDIAN
    return src>>16;
#else /* WORDS_BIGENDIAN */
    return src;
#endif /* WORDS_BIGENDIAN */
}

BOOL eke_cont_init (LPEKE_CONTAINER * new_cont)
{
    LPEKE_CONTAINER res;

    res = (LPEKE_CONTAINER)malloc(sizeof(EKE_CONTAINER));
    if(!res)
	return FALSE;
    memset (res, 0, sizeof(EKE_CONTAINER));

    *new_cont = res;
    return TRUE;
}

void eke_cont_release (LPEKE_CONTAINER cont)
{
    if (cont->hEKEAgree_A_B) CryptDestroyKey(cont->hEKEAgree_A_B);
    if (cont->pbEKE_MA_Verify) free (cont->pbEKE_MA_Verify);
    if (cont->pbEKE_MB_Verify) free (cont->pbEKE_MB_Verify);
    memset (cont, 0, sizeof(EKE_CONTAINER));
    free (cont);
}

static
void CreateEKEMultiplaer(TRdrFkcEKEChallenge_id id, PCRYPT_DATA_BLOB pMult)
{
    DWORD i, c = (DWORD)strlen(e_[id-1]);
    for(i=0;i<c;i++) pMult->pbData[SECRET_KEY_LEN-1-i] = e_[id-1][i];
}

static DWORD
FKCEKEHashData(HCRYPTPROV  hProv, LPEKE_CONTAINER pEKE, PTOKEN_VERIFYDATA pbData)
{
    HCRYPTHASH hHash=0;
    DWORD   dwParam = CALG_PRO_AGREEDKEY_DH, 
	    err=0, 
	    dwBufLen = sizeof(TOKEN_VERIFYDATA)- sizeof(DWORD);
    BYTE *pBuf = NULL;
    BYTE  SeansVector[8]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

    pBuf = malloc(dwBufLen);
    if(!pBuf) {
	err = (DWORD)NTE_NO_MEMORY;
	goto done;
    }
    CopyMemory(pBuf,&(pbData->e_),3*SECRET_KEY_LEN);
    CopyMemory(pBuf+3*SECRET_KEY_LEN,&(pbData->xQ_ab),SECRET_KEY_LEN);
    CopyMemory(pBuf+4*SECRET_KEY_LEN,&(pbData->xQ_pw),SECRET_KEY_LEN);

    if(!CryptSetKeyParam(pEKE->hEKEAgree_A_B, KP_SV, SeansVector,0))
    {
	err = GetLastError();
	goto done;
    };
    if(!CryptSetKeyParam(pEKE->hEKEAgree_A_B, KP_ALGID,(LPBYTE)&dwParam,0))
    {
	err = GetLastError();
	goto done;
    };
    if(!CryptCreateHash( hProv, CALG_EKEVERIFY_HASH, pEKE->hEKEAgree_A_B, 0, &hHash))
    {
	err = GetLastError();
	goto done;
    };
    if(!CryptHashData(hHash, pBuf, dwBufLen, 0))
    {
	err = GetLastError();
	goto done;
    };
    dwBufLen = sizeof(DWORD);
    if(!CryptGetHashParam(hHash, HP_HASHVAL, (BYTE*)&(pbData->Verify), &dwBufLen, 0))
    {
	err = GetLastError();
	goto done;
    };

done:
    if(hHash) CryptDestroyHash(hHash);
    free(pBuf);
    return err;
}

/* 
 * pTKN - pCSP / pFKC
 * Direct - CSP_C / TOKEN_ (Verify in CSP / Veryfi in FKC )
 *
 */
static DWORD 
FKCCreateSigma_1(HCRYPTPROV  hProv, 
		 LPEKE_CONTAINER pEKE, 
		 LPBYTE pbEKEPublic, 
		 LPBYTE pbPWPublic, 
		 LPBYTE pbData, TCHAR* cn)
{
    DWORD err = 0, dwDataLen;
    int dlen;
    TOKEN_VERIFYDATA v_d;
    TOKEN_VERIFYDATA v_d2;
    char tmp [NAME_LENTH];
    int i;

    ZeroMemory(&v_d,sizeof(TOKEN_VERIFYDATA));
    ZeroMemory(&v_d2,sizeof(TOKEN_VERIFYDATA));
    
    dlen = supfkc_2utf8scpy((BYTE*)tmp,NAME_LENTH,cn);
    if (dlen <= 0 ) {
	err = (DWORD)NTE_BAD_LEN;
	goto done;
    }
    dwDataLen = dlen;
    memset(v_d2.e_,0,(3*SECRET_KEY_LEN));
    if((dwDataLen) > 3*SECRET_KEY_LEN) dwDataLen = (3*SECRET_KEY_LEN)-2;

    /* ��������. ������������� UniqueTokenName � der UTF8String (prefix=0x0c<NN>)
    done */

    CopyMemory(v_d2.e_,tmp,dwDataLen);
    be2le(v_d.e_, v_d2.e_, SECRET_KEY_LEN);
    be2le(v_d.e_+SECRET_KEY_LEN, v_d2.e_+SECRET_KEY_LEN, SECRET_KEY_LEN);
    be2le(v_d.e_+2*SECRET_KEY_LEN, v_d2.e_+2*SECRET_KEY_LEN, SECRET_KEY_LEN);

    CopyMemory(v_d.xQ_ab,pbEKEPublic+PUBLIC_ECCPOINT,SECRET_KEY_LEN);
    CopyMemory(v_d.xQ_pw,pbPWPublic+PUBLIC_ECCPOINT,SECRET_KEY_LEN);
    if (pbData)
	for(i=0;i<DW_KEYLEN;i++) ((DWORD*)v_d.xQ_ab)[i] ^= ((DWORD*)pbData)[i];
 
    err = FKCEKEHashData(hProv,pEKE,&v_d);
    if(err) goto done;

	// ����� ��� ����������� ��������� ����� � ������ � ����������
    pEKE->Verify_A = le2be_d2s (v_d.Verify);
done:
    return err;
}

static void InversDWORD(BYTE* dst, DWORD src)
{
    dst[0] = (BYTE)(src>>16);
    dst[1] = (BYTE)(src>>8);
    dst[2] = (BYTE)(src);
}

static DWORD 
FKCCreateSigma_2(HCRYPTPROV  hProv, 
		 LPEKE_CONTAINER pEKE,
		 COUNTS * C,
		 LPBYTE pbEKEPublic, 
		 LPBYTE pbPWPublic, 
		 LPBYTE pbData,
		 TCHAR *fname,
		 BOOL frnamenull)
		 
{
    DWORD err = 0,i, dwDataLen;
    int dlen;
    TOKEN_VERIFYDATA v_d;
    TOKEN_VERIFYDATA v_d2;
    BYTE invers[3];
    BYTE tmp[NAME_LENTH];

    ZeroMemory(&v_d,sizeof(TOKEN_VERIFYDATA));
    ZeroMemory(&v_d2,sizeof(TOKEN_VERIFYDATA));
    ZeroMemory(tmp,NAME_LENTH);

    /* ��������� ������������� ��� �� TCHAR � UTF8String */
    if ((fname && fname[0] != 0) || !frnamenull)
	dlen = supfkc_2utf8scpy(tmp, NAME_LENTH, fname);
    else
	dlen = supfkc_2utf8scpy(tmp, NAME_LENTH, NULL);
    if (dlen <= 0 ) {
	err =(DWORD) NTE_BAD_LEN;
	goto done;
    }
    memset(v_d2.e_,0,3*SECRET_KEY_LEN);

    dwDataLen = dlen;
    if(dwDataLen > 3*SECRET_KEY_LEN-4*3+1) dwDataLen = 3*SECRET_KEY_LEN-4*3-1;

    CopyMemory(v_d2.e_,tmp, dwDataLen < 19 ? dwDataLen : 19);
    if(dwDataLen > 19)
	CopyMemory(v_d2.e_+SECRET_KEY_LEN,tmp+19,dwDataLen-19);

    v_d2.e_[19] = (BYTE)(C->c_seqfls+1);
    InversDWORD(invers, C->c_fls+1);
    CopyMemory(v_d2.e_ + 20, invers, 3);
    InversDWORD(invers, C->c_dh);
    CopyMemory(v_d2.e_ + 23, invers, 3);
    InversDWORD(invers, C->c_sig);
    CopyMemory(v_d2.e_ + 26, invers, 3);
    InversDWORD(invers, C->c_eke);
    CopyMemory(v_d2.e_ + 29, invers, 3);
    be2le(v_d.e_, v_d2.e_, SECRET_KEY_LEN);
    be2le(v_d.e_+SECRET_KEY_LEN, v_d2.e_+SECRET_KEY_LEN, SECRET_KEY_LEN);
    be2le(v_d.e_+2*SECRET_KEY_LEN, v_d2.e_+2*SECRET_KEY_LEN, SECRET_KEY_LEN);
    CopyMemory(v_d.xQ_ab, pbEKEPublic+PUBLIC_ECCPOINT, SECRET_KEY_LEN);
    CopyMemory(v_d.xQ_pw, pbPWPublic+PUBLIC_ECCPOINT, SECRET_KEY_LEN);

      /* ���� ���������� */
    if (pbData)
	for(i=0;i<DW_KEYLEN;i++) ((DWORD*)v_d.xQ_ab)[i] ^= ((DWORD*)pbData)[i];
 
    err = FKCEKEHashData(hProv,pEKE,&v_d);
    if(err) goto done;

	// ����� ��� ����������� ��������� ����� � ������ � ����������
    pEKE->Verify_B = le2be_d2s (v_d.Verify);

done:
    return err;
}

DWORD 
FKCVerifyEKE(LPEKE_CONTAINER pEKE, DWORD pEKEData)
{
    return (pEKEData != pEKE->Verify_A) ? (DWORD) RDR_ERR_INVALID_PASSWD : SUP_ERR_NO;
}

DWORD
FKCCreateEKEVerify(TRdrFkcEKEChallenge_id id, LPTOKEN_CONTAINER pTKN, LPBYTE pbData,
		   TCHAR * contname, TCHAR * frname)
{
    LPEKE_CONTAINER pEKE;
    LPBYTE pbEKEPublicMB, pbEKEPublicMA;
    LPBYTE sigma1Data = NULL, sigma2Data = NULL;
    DWORD err = 0;

    pEKE = pTKN->lpEKEop;
    if (!pEKE) return RDR_ERR_INVALID_PASSWD;
    pbEKEPublicMB = pEKE->pbEKE_MB_Verify;
    pbEKEPublicMA = pEKE->pbEKE_MA_Verify;

    if(!pbEKEPublicMB || !pbEKEPublicMA) return RDR_ERR_INVALID_PASSWD;
    if (id == TRECi_syncro) sigma2Data = pbData;
    else if (id == TRECi_syncroBIS) sigma1Data = pbData;

    err = FKCCreateSigma_1(pTKN->hContainer,pTKN->lpEKEop,pbEKEPublicMA,pTKN->pbPWPublicKeyBlob,sigma1Data,contname);
    if(err) goto done;
    err = FKCCreateSigma_2(pTKN->hContainer,pTKN->lpEKEop,&pTKN->C,pbEKEPublicMB,pTKN->pbPWPublicKeyBlob,sigma2Data,frname,pTKN->isnew_fofrname);
    if(err) goto done;

done:
    return err;
}



DWORD FKCCreateEKE (LPTOKEN_CONTAINER pFKC, LPBYTE pData, LPBYTE kBVal, TRdrFkcEKEChallenge_id id, LPBYTE dataRes)
{
    HCRYPTPROV hContainer = pFKC->hContainer;
    HCRYPTKEY hEKE_B=0, hPubEKE_MA=0, hEKEAgreeB=0;
    CRYPT_DATA_BLOB dM_B;
    LPBYTE pbEKEPublicMB=NULL;
    LPBYTE pbEKEPublicMA=NULL;
    DWORD err=0,dwDataLen;
    DWORD dwSign = ECC_PLUS;
    DWORD dwParam = KP_SIGNATUREOID;
    BYTE pbMB[SECRET_KEY_LEN];
    DWORD err_in_add = 0;

#if _DEBUG
    CRYPT_DATA_BLOB dK_B;
    if (kBVal) {
	dK_B.pbData = kBVal;
	dK_B.cbData = SECRET_KEY_LEN;
    }
#else
    UNUSED(kBVal);
#endif

    memset (&dM_B,0,sizeof(CRYPT_DATA_BLOB));
    dM_B.pbData = pbMB;
    dM_B.cbData = SECRET_KEY_LEN;
    memset (pbMB,0,SECRET_KEY_LEN);

    dwDataLen = pFKC->dwPubBlobLen;

    err = FKCAddPubKey( hContainer, pData, pFKC->pbPWPublicKeyBlob, &dwDataLen, dwSign, &pbEKEPublicMA, &err_in_add);
    if(err) goto done;

    if(!CryptGenKey(hContainer,CALG_DH_EL_EPHEM,//pFKC->aAlgId,
	CRYPT_EXPORTABLE | CRYPT_PREGEN | CRYPT_TOKEN_SHARED,&hEKE_B)) 
    {
	err = GetLastError();
	goto done; 
    }

    if (pFKC->dwKeySpec == AT_KEYEXCHANGE) dwParam = KP_DHOID;
    if (!CryptSetKeyParam(hEKE_B,dwParam,(LPBYTE)pFKC->pszKeyOID,0))
    {
	err = GetLastError();
	goto done;
    };

#if _DEBUG
    if (kBVal) {
	if(!CryptSetKeyParam(hEKE_B,KP_X,(LPBYTE)&dK_B,0)) 
	{
	    err = GetLastError();
	    goto done; 
	}
    } else
#endif
    if(!CryptSetKeyParam(hEKE_B,KP_X,NULL,0)) 
    {
	err = GetLastError();
	goto done; 
    }

    CreateEKEMultiplaer(id,&dM_B);
    if(!CryptSetKeyParam(hEKE_B,KP_MULX,(LPBYTE)&dM_B,0))
    {
	err = GetLastError();
	goto done;
    };
    err = CreatePublicKeyBlob(hEKE_B,&dwDataLen,&pbEKEPublicMB);
    if(err) goto done;
    if(!CryptSetKeyParam(hEKE_B,KP_MULX_INVERS,(LPBYTE)&dM_B,0))
    {
	err = GetLastError();
	goto done;
    };

    /*�������� 0 ��� ��������� Qpw*/
    if (err_in_add)
    {
	/*����� �� ������� ��������� mA, ����� �������� �� B. � ����� ����� ������ �� ����, ���������� ������ 
	���������� ��������� ���� � �������� ����� ������*/
	HCRYPTKEY hEKEA = 0;
	
	if(!CryptGenKey(hContainer,CALG_DH_EL_EPHEM,//pCSP->aAlgId,
	    CRYPT_EXPORTABLE | CRYPT_PREGEN | CRYPT_TOKEN_SHARED,&hEKEA)) 
	{
	    err = GetLastError();
	    goto done; 
	}

	{
	    DWORD dwParam = KP_SIGNATUREOID;
	    if(pFKC->dwKeySpec == AT_KEYEXCHANGE) dwParam = KP_DHOID;
	    if(!CryptSetKeyParam(hEKEA,dwParam,(LPBYTE)pFKC->pszKeyOID,0))
	    {
		err = GetLastError();
		CryptDestroyKey(hEKEA);
		goto done; 
	    };
	}
    
	if(!CryptSetKeyParam(hEKEA,KP_X,NULL,0))
	{
	    err = GetLastError();
	    CryptDestroyKey(hEKEA);
	    goto done;
	};

	err = CreatePublicKeyBlob(hEKEA,&dwDataLen,&pbEKEPublicMA);
	if (err) {
	    CryptDestroyKey(hEKEA);
	    goto done;
	};
	CryptDestroyKey(hEKEA);
    }

    {
	if(!CryptImportKey(hContainer,pbEKEPublicMA,PUBLICBLOBLEN,0,0,&hPubEKE_MA))
	{
	    err = GetLastError();
	    goto done;
	};
    /*  �������� K_eke_B */
	if(!CryptImportKey( hContainer,pbEKEPublicMA,dwDataLen,hEKE_B,0,&hEKEAgreeB))
	{
	    err = GetLastError();
	    goto done;
	};
	pFKC->lpEKEop->hEKEAgree_A_B = hEKEAgreeB;
    }


    err = FKCAddPubKey( hContainer, pbEKEPublicMB,pFKC->pbPWPublicKeyBlob,
			&dwDataLen, dwSign, &dataRes, &err_in_add);
    if(err) goto done;

    if(id == TRECi_syncro || id == TRECi_syncroBIS) {
	if(pFKC->lpEKEop->pbEKE_MB_Verify) free(pFKC->lpEKEop->pbEKE_MB_Verify);
	pFKC->lpEKEop->pbEKE_MB_Verify = pbEKEPublicMB;

	if(pFKC->lpEKEop->pbEKE_MA_Verify) free(pFKC->lpEKEop->pbEKE_MA_Verify);
	pFKC->lpEKEop->pbEKE_MA_Verify = pbEKEPublicMA;
    } else {
	free(pbEKEPublicMB); 
	free(pbEKEPublicMA); 
    }

    CryptDestroyKey(hEKE_B);
    CryptDestroyKey(hPubEKE_MA);
    return 0;
done:
    if(hEKE_B) CryptDestroyKey(hEKE_B);
    if(hPubEKE_MA) CryptDestroyKey(hPubEKE_MA);
    if(pbEKEPublicMA) free(pbEKEPublicMA);
    if(pbEKEPublicMB) free(pbEKEPublicMB);
    return err;
}

DWORD FKCEKEEncrypt(LPEKE_CONTAINER pEKE, DWORD CryptMode, BOOL bEncrypt, LPBYTE pbData, DWORD cbData)
{
    DWORD dwParam,err=0;
    static BYTE  SeansVector[8]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

    dwParam = CALG_EKE_CIPHER;
    if(!CryptSetKeyParam(pEKE->hEKEAgree_A_B, KP_ALGID,(LPBYTE)&dwParam,0))
    {
	err = GetLastError();
	goto done;
    };

    dwParam = CryptMode;
    if(!CryptSetKeyParam(pEKE->hEKEAgree_A_B, KP_MODE, (LPBYTE)&dwParam, 0))
    {
	err = GetLastError();
	goto done;
    };

    if(!CryptSetKeyParam(pEKE->hEKEAgree_A_B, KP_SV, SeansVector, 0))
    {
	err = GetLastError();
	goto done;
    };

    dwParam = cbData;
    if(bEncrypt == ECC_MINUS) {
	/*Encrypt == ECC_MINUS*/
	if(!CryptEncrypt(pEKE->hEKEAgree_A_B, 0, TRUE, 0, pbData,&dwParam, cbData))
	{
	    err = GetLastError();
	    goto done;
	};
    } else {
	/*Decrypt == ECC_PLUS*/
	if(!CryptDecrypt(pEKE->hEKEAgree_A_B, 0, TRUE, 0, pbData, &dwParam))
	{
	    err = GetLastError();
	    goto done;
	};
    }
done:
    return err;
}

#include "fkchdimgprj.h"

#if defined PRINT_KEY
#include <stdio.h>
void
Printf_B_(LPBYTE pB, DWORD dwLen, LPSTR pstr) 
{
    if(pB) {
	DWORD i;

	printf("\n%s ",pstr);
	for(i=0; i<dwLen; i++) {
	    if(i%4==0)
		printf(" ");
	    printf("%02lx",(unsigned long)pB[i]);
	}
	printf("\n");
    }
}
#endif	/* PRINT_KEY */

void be2le(unsigned char *pdst, unsigned char *psrc, DWORD dwLen) 
{
    unsigned char *ptmp = psrc + dwLen - 1;
    DWORD i;
    for(i=0; i < dwLen; i++)
	*(pdst + i) = *(ptmp - i);
}

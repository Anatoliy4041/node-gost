#include "fkchdimgprj.h"

TSupErr uechdimg_file_write( TSupSysContext *context, TSupSysInfo *info )
{
    TReaderInfoWrite *inf = (TReaderInfoWrite*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );
    SUPSYS_PRE_INFO( info, TReaderInfoWrite );
    SUPSYS_PRE_READ_PTRS( inf->info.info, inf->info.length );

    inf->size_of = sizeof( TReaderInfoWrite );
    if( !inf->info.length )
	return SUP_ERR_NO;
    if( inf->from + inf->info.length > ctx->file_length )
    {
	unsigned char *ptr;
	ptr = realloc( ctx->file, inf->from + inf->info.length );
	if( ptr == NULL )
	{
	    inf->info.length = 0;
	    return SUP_ERR_MEMORY;
	}
	ctx->file = ptr;
	memset( ctx->file + ctx->file_length, 0, 
	    inf->from + inf->info.length - ctx->file_length );
	ctx->file_length = inf->from + inf->info.length;
    }
    memcpy( ctx->file + inf->from, inf->info.info, inf->info.length );
    inf->info.length = 0;
    return SUP_ERR_NO;
}

#include "fkchdimgprj.h"

TSupErr uechdimg_file_chsize( 
			TSupSysContext *context, 
			TSupSysInfo *info )
{
    TReaderInfoChSize *inf = (TReaderInfoChSize*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );
    SUPSYS_PRE_INFO( info, TReaderInfoChSize );

    inf->size_of = sizeof( TReaderInfoChSize );
    if( inf->length > ctx->file_length ) {
	inf->length = ctx->file_length;
	return RDR_ERR_FULL;
    }
    inf->length = ctx->file_length;
    return SUP_ERR_NO;
}

TSupErr uechdimg_file_size( 
		      TSupSysContext *context, 
		      TSupSysInfo *info )
{
    TReaderInfoLength *inf = (TReaderInfoLength*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );
    SUPSYS_PRE_INFO( info, TReaderInfoLength );

    inf->size_of = sizeof( TReaderInfoLength );
    inf->length = ctx->file_length;
    return SUP_ERR_NO;
}

#include "fkchdimgprj.h"

void
FKCReleaseTContainer( LPTOKEN_CONTAINER psRootKeys)
{
  if(!psRootKeys)
      return;

  psRootKeys->opened = FALSE;

  if (psRootKeys->lpEKEop) {
      eke_cont_release (psRootKeys->lpEKEop);
      psRootKeys->lpEKEop = NULL;
  }
  if( psRootKeys->hKeyPair )
  {
      CryptDestroyKey( psRootKeys->hKeyPair );
      psRootKeys->hKeyPair = 0;
  }
  if( psRootKeys->signHash )
  {
      CryptDestroyHash(psRootKeys->signHash);
      psRootKeys->signHash = 0;
  }
  if( psRootKeys->hContainer )
  {
      CryptReleaseContext( psRootKeys->hContainer, 0 );
      psRootKeys->hContainer = 0;
  }    
  if( psRootKeys->pbPublicKeyBlob )
  {
      free( psRootKeys->pbPublicKeyBlob );
      psRootKeys->pbPublicKeyBlob = NULL;
  }
  if( psRootKeys->pbPWPublicKeyBlobNew )
  {
      free( psRootKeys->pbPWPublicKeyBlobNew );
      psRootKeys->pbPWPublicKeyBlobNew = NULL;
  }
  if( psRootKeys->pbPWPublicKeyBlob )
  {
      free( psRootKeys->pbPWPublicKeyBlob );
      psRootKeys->pbPWPublicKeyBlob = NULL;
  }
  if( psRootKeys->pbSaltPublicBlob )
  {
      free( psRootKeys->pbSaltPublicBlob );
      psRootKeys->pbSaltPublicBlob = NULL;
  }
}

DWORD FKCCreateTContainer(LPTOKEN_CONTAINER psRootKeys, BOOL isNew)
{
    HCRYPTPROV	hCreateContaner=psRootKeys->hContainer;
    DWORD dwFlags, dwKeySpec = psRootKeys->dwKeySpec;
    DWORD err=0;
    LPCSTR pszKeyOID = (LPCSTR)psRootKeys->pszKeyOID;
    LPCSTR pPW = "default";
    DWORD Num_ECC = 0;

    psRootKeys->aAlgId = CALG_GR3410EL;
    if(dwKeySpec==AT_KEYEXCHANGE)
	psRootKeys->aAlgId = CALG_DH_EL_EPHEM;

    if(psRootKeys->pszKeyOID) {
	if(dwKeySpec==AT_SIGNATURE) {
	    if(!CryptSetProvParam( hCreateContaner,PP_SIGNATUREOID,(LPBYTE)pszKeyOID,0)) {
		err = GetLastError();
		return err;
	    }
	}
	if(dwKeySpec==AT_KEYEXCHANGE) {
	    if(!CryptSetProvParam( hCreateContaner,PP_DHOID,(LPBYTE)pszKeyOID,0)) {
		err = GetLastError();
		return err;
	    }
	}
	if(!strcmp(pszKeyOID,OID_ECCSignDHOSCAR) ) Num_ECC = 1;
	if(!strcmp(pszKeyOID,OID_ECCSignDHPRO) ) Num_ECC = 2;
	if(!strcmp(pszKeyOID,OID_ECCSignDHVar_1) ) Num_ECC = 3;
	if(!strcmp(pszKeyOID,OID_ECCDHPRO) ) Num_ECC = 4;
	if(!strcmp(pszKeyOID,OID_ECCDHPVar_1) )	Num_ECC = 5;
    } else {
	err = S_FALSE;
	goto done;
    }

    psRootKeys->pbPPHeader = PublicHeaders[Num_ECC-1];

    if(!CryptSetProvParam( hCreateContaner,PP_SIGNATURE_PIN,(LPBYTE)pPW,0)) {
	err = GetLastError();
	printf("Faild CryptSetProvParam( PP_SIGNATURE_PIN)");
    }
    if(isNew) {/*Gen Key*/
 	dwFlags = CRYPT_TOKEN_SHARED;
	if(!CryptGenKey(hCreateContaner, dwKeySpec, dwFlags,
	    &(psRootKeys->hKeyPair))){err = GetLastError();};
	if(err) goto done;
    } else { /*Open Key*/
	if(!CryptGetUserKey(hCreateContaner, dwKeySpec,&(psRootKeys->hKeyPair))) {
	    err = GetLastError();
	    printf("%s:%d: Error %lx during GetUserKey!\n", __FILE__, __LINE__, (unsigned long)err);
	    goto done;
	}
    }

done:
    if(!err)
	err = SetPublicKeyBlob(psRootKeys);
    return err;
}


DWORD CreatePublicKeyBlob(HCRYPTKEY   hKeyPair, 
	DWORD* pdwPubBlobLen, LPBYTE* ppPubKeyBlob)
{
    DWORD err=0, dwBlobLen;
    if(!CryptExportKey(hKeyPair, 0, PUBLICKEYBLOB, 0, NULL, &dwBlobLen)) {
	err = GetLastError();
	printf("Error %lx computing blob length!\n", (unsigned long)GetLastError());
	goto done;
    }
    *ppPubKeyBlob = malloc(dwBlobLen);	
    if(!*ppPubKeyBlob) {
	err = SUP_ERR_MEMORY;
	goto done;
    }
    *pdwPubBlobLen=dwBlobLen;
    if(!CryptExportKey(hKeyPair, 0, PUBLICKEYBLOB, 0, *ppPubKeyBlob , &dwBlobLen)) {
	err = GetLastError();
	printf("Error %lx during CPExportKey!\n", (unsigned long)GetLastError());
    }
done:
    return err;
}

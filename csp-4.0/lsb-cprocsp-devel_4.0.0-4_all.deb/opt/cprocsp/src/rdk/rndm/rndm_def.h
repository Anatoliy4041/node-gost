// ����������� ����������� ���� � ������ reader/include/reader/support.h,
// reader/source/support/sup_def.h � reader/source/rdr/rdr_def.h,
// �� ���� ������� � ������������!
#if defined( UNIX ) || defined( _WIN32 ) && defined( __STDC__ ) || defined( WINCE )
#define NO_SUP_PROPERTIES
#endif // defined( UNIX ) || defined( _WIN32 ) && defined( __STDC__ ) || defined( WINCE )
RNDM_ITEM(rndm, ( TSupSysEContext *context, size_t length, void *info ), ( context, length, info ))
RNDM_ITEM(rndm_type_get, ( const TSupSysEContext *context, TRndmType *type ), ( context, type ))
#if !defined UNIX
RNDM_ITEM(rndm_error, ( const TSupSysEContext *context, TSupErr code, size_t *length, TCHAR *text ), ( context, code, length, text ))
RNDM_ITEM(rndm_set_hwnd, ( const TSupSysEContext *context, HWND parent ), (context, parent))
#endif /* !UNIX */
RNDM_ITEM(rndm_find_open, ( TSupSysEList *list, TSupSysEFind **context, TRndmType mask, TRndmType value ), ( list, context, mask, value ))
RNDM_ITEM(rndm_find_mask, ( TSupSysEList *list, TSupSysEContext **context, TRndmType mask, TRndmType value ), ( list, context, mask, value ))
RNDM_ITEM(rndm_register_start, ( TSupSysEList **list ), ( list ))
RNDM_ITEM(rndm_level_set, ( const TSupSysEContext *context, TRndmLevel level ), ( context, level ))
RNDM_ITEM(rndm_level_get, ( const TSupSysEContext *context, TRndmLevel *level ), ( context, level ))
#ifndef NO_SUP_PROPERTIES
RNDM_ITEM(rndm_wnd_configure, ( HWND hwnd ), ( hwnd ))
#endif /* NO_SUP_PROPERTIES */

#include "reader.kit/gen_prj.h"
#include "reader/tchar.h"

#include "reader/support.h"
#include "reader/sup_syse.h"
#include "reader/rndm.h"

#define RNDM_ITEM(name,arg_list,call_list) \
    SUPDLL_ITEMT(rndm,name,arg_list,TSupErr,SUPDLL_NULL)
#include "rndm_def.h"
#undef RNDM_ITEM

SUPDLL_ITEMI_B_INSIDE(rndm)
#define RNDM_ITEM(name,arg_list,call_list) \
    SUPDLL_ITEMI(rndm,name)
#include "rndm_def.h"
#undef RNDM_ITEM
SUPDLL_ITEMI_E(rndm)

static const TCHAR RNDM_DEFAULT_NAME[] = 
#ifdef UNIX
_TEXT( "librdrrndm.so" );
#else /* UNIX */
_TEXT( "cprndm.dll" );
#endif /* UNIX */
#define rndm_module_init()
#define rndm_module_done()
SUPDLL_LOAD(rndm,RNDM_DEFAULT_NAME)
SUPDLL_UNLOAD(rndm)

#define RNDM_ITEM(name,arg_list,call_list) \
    SUPDLL_ITEMR2(rndm,name,arg_list,call_list,TSupErr,SUPDLL_NULL,SUP_ERR_UNSUPPORTED)
#include "rndm_def.h"

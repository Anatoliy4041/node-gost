static void __dummy_func__(void)
{
}

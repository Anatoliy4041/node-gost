/*
 * Copyright(C) 2003 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/*!
 * \file $RCSfile$
 * \version $Revision: 126987 $
 * \date $Date:: 2015-09-08 17:51:58 +0400#$
 * \author $Author: pav $
 *
 * \brief INITTST Util
 * \todo ����������� ���������� ServerCache ��������� ��� ����������
 */
/*
#define POLICY - �������� �������������� ��� �������� ������� � ������������ � 3280.
���� ��� ������� ����������� 3280 � ������ ������, �� �������� ���� ������
*/

#define CERT_REVOCATION_PARA_HAS_EXTRA_FIELDS

#if defined( MSLEAKS )
#define CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#endif

#include "common.h"
#include "reader/support.h"
#include <stdexcept>
#include <iostream>
#include <string>
#include <memory>
#include <sstream>
#include <locale.h>
#ifdef UNIX
#include <unistd.h>
#endif
#ifdef WIN32
    #include "delayimp.h"
#endif

#include "CA_CMP_Requests.h"
#include "CA_CMP_Certificate.h"
#include "CA_CMP_RevAnnContent.h"
#include "CA_CMP_CRL.h"
#include "PKIXCMP_Client.h"
#include "PKIXCMP_Server.h"
#include "ChainUtil.h"
#include "testsup.h"
#include "conwnd.h"
#include "EncodeAnd.h"
#include "CA_CMP_Util.h"

typedef void (*Action)( const Ini &path );

enum WndProvType {
    WND_PROV_DEFAULT,
    WND_PROV_CONSOLE,
    WND_PROV_SILENT,
    WND_PROV_EXCLUDE,
    WND_PROV_NO_PIN,
    WND_PROV_W32
};

static WndProv *type_to_prov( WndProvType wnd_prov_type )
{
    if( wnd_prov_type == WND_PROV_CONSOLE )
	return &con_wnd_prov;
    if( wnd_prov_type == WND_PROV_SILENT )
	return &silent_wnd_prov;
    if( wnd_prov_type == WND_PROV_EXCLUDE )
	return 0;
    if( wnd_prov_type == WND_PROV_NO_PIN )
	return &no_pin_wnd_prov;
    if( wnd_prov_type == WND_PROV_DEFAULT )
	return 0;
#ifdef _WIN32
    if( wnd_prov_type == WND_PROV_W32 )
	return &w32_wnd_prov;
#endif /* _WIN32 */
    ini_throw::throw_bad( "WndProvType bad" );
    return 0;
};

struct ServerCacheItem {
    PKIXCMP_Server *server_;
    Ini ini_path_;
    WndProvType wnd_prov_type_;
    WndProv *wnd_prov_;

    ServerCacheItem( PKIXCMP_Server *server, const Ini &ini_path, 
	WndProvType wnd_prov_type ) : server_( server ), ini_path_( ini_path ), 
	wnd_prov_type_( wnd_prov_type )
    {
	wnd_prov_ = type_to_prov( wnd_prov_type );
    }
    ServerCacheItem( const ServerCacheItem &right ) : server_( right.server_ ),
	ini_path_( right.ini_path_ ), wnd_prov_type_( right.wnd_prov_type_ ), 
	wnd_prov_( right.wnd_prov_ ) {}
    ServerCacheItem& operator=( const ServerCacheItem &right )
    {
	server_ = right.server_;
	ini_path_ = right.ini_path_;
	wnd_prov_type_ = right.wnd_prov_type_;
	wnd_prov_ = right.wnd_prov_;
        return *this;
    }
    bool operator ==( const ServerCacheItem &right ) const
    { return ini_path_ == right.ini_path_; }
    bool operator !=( const ServerCacheItem &right ) const
    { return ini_path_ != right.ini_path_; }
};

class ServerCache {
public:
    typedef std::list<ServerCacheItem> server_list;

    ServerCache() : verify_server( 0 ) { }
    ~ServerCache() { 
	delete verify_server; 
	server_list::const_iterator ci = the_list.begin();
	for( ; ci != the_list.end(); ++ci ) delete ci->server_;
    }

    PKIXCMP_Server *Create_GenerateRoot( const Ini &ini_path,
	const wchar_t *dn, 
	const CACMPT_Extensions& Extensions,
	const wchar_t *caname,
	const char * prov_name,
        bool keyExportable,
	int dwProvType = PROV_GOST_2001_DH,
	const char *szContainer = 0,
	const CACMPT_Period &cert_period = CACMPT_Period::OneYear,
	const CACMPT_Date &notbefore = CACMPT_Date(),
	const char *cdp = 0,
	const CACMPT_Period &crl_period = CACMPT_Period::OneMonth,
	WndProvType wnd_prov_type = WND_PROV_EXCLUDE )
    { 
	WndProv *wnd_prov = type_to_prov( wnd_prov_type );
	PKIXCMP_Server *server = PKIXCMP_Server::GenerateRoot( ini_path.get_path(),
	    dn, Extensions, caname, keyExportable, prov_name, dwProvType, szContainer, cert_period,
	    notbefore, cdp, crl_period, wnd_prov ); // 0=default provider, fill in if you wish 
	the_list.push_back( ServerCacheItem( server, ini_path, 
	    wnd_prov_type ) );
	return server;
    }
    PKIXCMP_Server *Create_Verify() 
    { 
	if( verify_server ) return verify_server; 
	if( the_list.begin() != the_list.end() )
	    return the_list.begin()->server_;
	verify_server = new PKIXCMP_Server(0, PROV_GOST_2001_DH);
	return verify_server;
    }
    PKIXCMP_Server *Create_Read( const Ini &ini_path,
	WndProvType wnd_prov_type = WND_PROV_DEFAULT )
    { 
	const ServerCacheItem *found = find_by_ini( ini_path );
	if( found )
	    return found->server_;
	if( wnd_prov_type == WND_PROV_DEFAULT )
	    wnd_prov_type = WND_PROV_SILENT;
	WndProv *wnd_prov = type_to_prov( wnd_prov_type );
	PKIXCMP_Server *server =
	    new PKIXCMP_Server( ini_path.get_path(), wnd_prov ); 
	the_list.push_back( ServerCacheItem( server, ini_path, wnd_prov_type ) );
	return server;
    }
    PKIXCMP_Server *UpdateRoot( const Ini &ini_path,
	int dwProvType,	const char *szContainer,
        bool keyExportable, CACMPT_BLOB &ann_msg, 
	PKIXCMP_Message *info, WndProvType wnd_prov_type, 
	CACMPT_BLOB *new_cert = NULL )
    {
	const ServerCacheItem *found = find_by_ini( ini_path );
	if( found )
	{
	    WndProv *wnd_prov = type_to_prov( wnd_prov_type );
	    if( wnd_prov_type == WND_PROV_DEFAULT )
		wnd_prov = found->wnd_prov_;
	    found->server_->UpdateRoot( ini_path.get_path(), dwProvType,
		szContainer, keyExportable, ann_msg, info, wnd_prov, new_cert );//0=default provider, fill in if you wish
	    return found->server_;
	}
	if( wnd_prov_type == WND_PROV_DEFAULT )
	    wnd_prov_type = WND_PROV_EXCLUDE;
	WndProv *wnd_prov = type_to_prov( wnd_prov_type );
	PKIXCMP_Server *server =
	    new PKIXCMP_Server( ini_path.get_path(), wnd_prov ); 
	the_list.push_back( ServerCacheItem( server, ini_path, wnd_prov_type ) );
	server->UpdateRoot( ini_path.get_path(), dwProvType,
	    szContainer, keyExportable, ann_msg, info, wnd_prov, new_cert );//0=default provider, fill in if you wish
	return server;
    }
    int ChangePassword( const Ini &ini_path, WndProvType wnd_prov_type )
    {
	const ServerCacheItem *found = find_by_ini( ini_path );
	if( found )
	    return found->server_->ChangePassword( found->wnd_prov_ );

	if( wnd_prov_type == WND_PROV_DEFAULT )
	    wnd_prov_type = WND_PROV_EXCLUDE;
	WndProv *wnd_prov = type_to_prov( wnd_prov_type );
	PKIXCMP_Server *server =
	    new PKIXCMP_Server( ini_path.get_path(), wnd_prov ); 
	the_list.push_back( ServerCacheItem( server, ini_path, wnd_prov_type ) );
	return server->ChangePassword( wnd_prov );
    }
    void ClearCacheItem( const Ini &ini_path )
    {
	ServerCacheItem ptr( 0, ini_path, WND_PROV_DEFAULT );
	server_list::iterator i = 
	    std::find<server_list::iterator, ServerCacheItem>( 
	    the_list.begin(), the_list.end(), ptr );
	ServerCacheItem tmp_server = *i;
	delete tmp_server.server_;
	if( i != the_list.end() )
	    the_list.erase( i );
    }
protected:
    const ServerCacheItem *find_by_ini( const Ini &ini_path )
    { 
	ServerCacheItem ptr( 0, ini_path, WND_PROV_DEFAULT );
	server_list::const_iterator f = 
	    std::find<server_list::const_iterator, ServerCacheItem>( 
	    the_list.begin(), the_list.end(), ptr );
	if( f == the_list.end() ) 
	    return 0;
	return &*f; 
    }
    PKIXCMP_Server *verify_server;
    server_list the_list;
};

class CANoNeedException : public CAException
{
public:
    explicit CANoNeedException( const char msg[] = "No need exception.", const char *f = NULL, int l = 0 )
	: CAException( msg, f, l ) {}
};

class TestSequenceException : public CAException
{
public:
    explicit TestSequenceException( const char *msg = "Sequence exception.", const char *f = NULL, int l = 0 )
	: CAException( msg, f, l ) {}
};

static ServerCache server_cache;

static void fill_message( const Ini &path, PKIXCMP_Message &msg );
static void get_free_text( const Ini &path, const char *param, FreeText &dest );
static const CertificateStore *get_extra_store( const Ini &path, 
    size_t &add_base_quant, wmulti_sz &addstore );
#if POLICY
static void get_policies( const Ini &path, const char *key, 
    policy_oid_set &set );
bool operator ==( const policy_set &left, const policy_oid_set &right );
bool operator !=( const policy_set &left, const policy_oid_set &right )
{ return !( left == right ); }
#endif 
void test_ProcessExtensions (const Ini &path, const TCHAR *key, 
    CACMPT_Extensions& Extensions);
static void get_extra_certs( const Ini &path, const char *key, 
    encoded_certificate_list &list );
static void get_extra_crl( const Ini &path, encoded_crl_list &list );
static WndProv &get_client_wnd_prov( const Ini &path );

static void test_GenerateRoot( const Ini &path );
static void test_InstallRoot( const Ini &path );
static void test_UpdateRoot( const Ini &path );
static void test_PasswdRootChange( const Ini &path );
static void test_CertReqMessage_EncodeAndSign( const Ini &path );
static void test_PKCS10_EncodeAndSign( const Ini &path );
static void test_CertReqMessage_Sign( const Ini &path );
static void test_CertReqMessage_Decode( const Ini &path );
static void test_CertReqMessage_Verify( const Ini &path );
static void test_CertReqMessage_Process( const Ini &path );
static void test_CertReqMessage_Reject( const Ini &path );
static void test_CertRepMessage_Decode( const Ini &path );
static void test_CertRepMessage_Verify( const Ini &path );
static void test_CertRepMessage_Install( const Ini &path );
static void test_GenerateCRL( const Ini &path );
static void test_DecodeCRL( const Ini &path );
static void test_VerifyCRL( const Ini &path );
static void test_Cert_Decode( const Ini &path );
static void test_RevAnnContent_Process( const Ini &path );
static void test_RevAnnContent_Decode( const Ini &path );
static void test_CertChain_Verify( const Ini &path );
static void test_IniSet( const Ini &path );
static void test_IniSetFile( const Ini &path );
static void test_Sequence( const Ini &path );
static void test_ListCertificateInStore( const Ini &path );
static void test_DeleteCertificateFromStore( const Ini &path );
static void test_AddCertificateToStore( const Ini &path );
static void test_ExtractCertificateFromStore( const Ini &path );
static void test_ListCrlInStore( const Ini &path );
static void test_DeleteCrlFromStore( const Ini &path );
static void test_AddCrlToStore( const Ini &path );
static void test_ExtractCrlFromStore( const Ini &path );
static void test_CrossReqMessage_EncodeAndSign( const Ini &path );
static void test_PKCS10_CrossReq ( const Ini &path );
static void test_ErrorMsgInfo_EncodeAndSign( const Ini &path );
static void test_ErrorMsgInfo_Decode( const Ini &path );
static void test_ErrorMsgInfo_Verify( const Ini &path );
static void test_ToBase64( const Ini &path );
static void test_FromBase64( const Ini &path );
static void test_CertAnnContent_EncodeAndSign( const Ini &path );
static void test_CertAnnContent_DecodeAndVerify( const Ini &path );
static void test_GenMsgContent_EncodeAndSign( const Ini &path );
static void test_ClearCacheItem( const Ini &path );
static void test_CertChain_Verify_CAPI( const Ini &path );
static void test_PasswdClientChange( const Ini &path );
static void test_GetURL( const Ini &path );
static void test_QuickCert( const Ini& path );
static void test_SetAsRoot( const Ini& path );
static void test_QuickIntermediate( const Ini& path );
static void test_CertVerifyRevocation( const Ini& path );

static const TCHAR* str_actions[] = 
{
    "GenerateRoot",
    "InstallRoot",
    "UpdateRoot",
    "PasswdRootChange",
    "PKCS10_EncodeAndSign",
    "CertReqMessage_Sign",
    "CertReqMessage_EncodeAndSign",
    "CertReqMessage_Decode",
    "CertReqMessage_Verify",
    "CertReqMessage_Process",
    "CertReqMessage_Reject",
    "CertRepMessage_Decode",
    "CertRepMessage_Verify",
    "CertRepMessage_Install",
    "GenerateCrl",
    "DecodeCrl",
    "VerifyCrl",
    "Cert_Decode",
    "RevAnnContent_Process",
    "RevAnnContent_Decode",
    "CertChain_Verify",
    "IniSet",
    "IniSetFile",
    "Sequence",
    "CertStoreList",
    "CertStoreDel",
    "CertStoreAdd",
    "CertStoreExtract",
    "CrlStoreList",
    "CrlStoreDel",
    "CrlStoreAdd",
    "CrlStoreExtract",
    "CrossReqMessage_EncodeAndSign",
    "PKCS10_CrossReq",
    "ErrorMsgInfoEncode",
    "ErrorMsgInfoDecode",
    "ErrorMsgInfoVerify",
    "FromBase64",
    "ToBase64",
    "CertAnnContent_EncodeAndSign",
    "CertAnnContent_DecodeAndVerify",
    "GenMsgContent_EncodeAndSign",
    "ClearCacheItem",
    "CertChain_Verify_CAPI",
    "PasswdClientChange",
    "GetURL",
    "QuickCert",
    "SetAsRoot",
    "QuickIntermediate",
    "CertVerifyRevocation",
};

static Action actions[] =
{
    test_GenerateRoot,
    test_InstallRoot,
    test_UpdateRoot,
    test_PasswdRootChange,
    test_PKCS10_EncodeAndSign,
    test_CertReqMessage_Sign,
    test_CertReqMessage_EncodeAndSign,
    test_CertReqMessage_Decode,
    test_CertReqMessage_Verify,
    test_CertReqMessage_Process,
    test_CertReqMessage_Reject,
    test_CertRepMessage_Decode,
    test_CertRepMessage_Verify,
    test_CertRepMessage_Install,
    test_GenerateCRL,
    test_DecodeCRL,
    test_VerifyCRL,
    test_Cert_Decode,
    test_RevAnnContent_Process,
    test_RevAnnContent_Decode,
    test_CertChain_Verify,
    test_IniSet,
    test_IniSetFile,
    test_Sequence,
    test_ListCertificateInStore,
    test_DeleteCertificateFromStore,
    test_AddCertificateToStore,
    test_ExtractCertificateFromStore,
    test_ListCrlInStore,
    test_DeleteCrlFromStore,
    test_AddCrlToStore,
    test_ExtractCrlFromStore,
    test_CrossReqMessage_EncodeAndSign,
    test_PKCS10_CrossReq,
    test_ErrorMsgInfo_EncodeAndSign,
    test_ErrorMsgInfo_Decode,
    test_ErrorMsgInfo_Verify,
    test_FromBase64,
    test_ToBase64,
    test_CertAnnContent_EncodeAndSign,
    test_CertAnnContent_DecodeAndVerify,
    test_GenMsgContent_EncodeAndSign,
    test_ClearCacheItem,
    test_CertChain_Verify_CAPI,
    test_PasswdClientChange,
    test_GetURL,
    test_QuickCert,
    test_SetAsRoot,
    test_QuickIntermediate,
    test_CertVerifyRevocation,
};

static const TCHAR *str_request_type[] =
{
    "GetCertificate",
    "RevokeCertificate",
    "GetCRL",
    "InitialRequest",
    "GetCross",
    "Confirm",
    "UpdateKey",
    "SuspendCertificate",
    "ResumeCertificate",
    "GenMsg",
    "ChangeName",
};

static const TCHAR *str_PKIStatus[] =
{
    "granted",
    "grantedWithMods",
    "rejection",
    "waiting",
    "revocationWarning",
    "revocationNotification",
    "keyUpdateWarning"
};

static const TCHAR *str_RevocationCheckFlags[] =
{
    "REVOCATION_CHECK_END_CERT",
    "REVOCATION_CHECK_CHAIN",
    "REVOCATION_CHECK_CHAIN_EXCLUDE_ROOT",
//    "CACHE_END_CERT",
    "REVOCATION_CHECK_CACHE_ONLY",
    "CACHE_ONLY_URL_RETRIEVAL",
    "DISABLE_PASS1_QUALITY_FILTERING",
//    "RETURN_LOWER_QUALITY_CONTEXTS",
//    "DISABLE_AUTH_ROOT_AUTO_UPDATE",
    "REVOCATION_ACCUMULATIVE_TIMEOUT",
//    "TIMESTAMP_TIME",
};

static const unsigned u_RevocationCheckFlags[] =
{
    CertChainBuildFlags::REVOCATION_CHECK_END_CERT,
    CertChainBuildFlags::REVOCATION_CHECK_CHAIN,
    CertChainBuildFlags::REVOCATION_CHECK_CHAIN_EXCLUDE_ROOT,
    CertChainBuildFlags::REVOCATION_CHECK_CACHE_ONLY,
    CertChainBuildFlags::CACHE_ONLY_URL_RETRIEVAL,
    CertChainBuildFlags::DISABLE_PASS1_QUALITY_FILTERING,
    CertChainBuildFlags::REVOCATION_ACCUMULATIVE_TIMEOUT
};
static const unsigned u_WinRevocationCheckFlags[] =
{
    CERT_CHAIN_REVOCATION_CHECK_END_CERT,
    CERT_CHAIN_REVOCATION_CHECK_CHAIN,
    CERT_CHAIN_REVOCATION_CHECK_CHAIN_EXCLUDE_ROOT,
    CERT_CHAIN_REVOCATION_CHECK_CACHE_ONLY,
    CERT_CHAIN_CACHE_ONLY_URL_RETRIEVAL,
    CERT_CHAIN_DISABLE_PASS1_QUALITY_FILTERING,
    CERT_CHAIN_REVOCATION_ACCUMULATIVE_TIMEOUT
};
static const TCHAR *str_ProvType[] =
{
    "gost2001",
    "gost2012_256",
    "gost2012_512",
//#if defined( _WIN32 )
    "rsaFull",
//#endif
};

static const DWORD SetProvType[] = 
{
    PROV_GOST_2001_DH,
    PROV_GOST_2012_256,
    PROV_GOST_2012_512,
//#if defined( _WIN32 )
    PROV_RSA_FULL
//#endif
};

static const TCHAR *str_wnd_prov[] = 
{
    "default",
    "console",
    "silent",
    "exclude",
    "nopin",
    "w32",
};

static const char pcs10req_def[] = "pkcs10.der";
static const char pkireq_def[] = "pkireq.der";
static const char pkirep_def[] = "pkirep.der";
static const char pkiann_def[] = "pkiann.der";
static const char cacert_def[] = "cacert.der";
static const char cacrl_def[] = "cacrl.der";
static const char pkicer_def[] = "pki.cer";
static const char revann_def[] = "revann.der";
static const char crossreq_def[] = "crossreq.der";
static const char emi_def[] = "emi.der";
static const char cann_def[] = "cann.der";
static const char genm_def[] = "genm.der";
static const char container_def[] = "";
static const char cacontainer_def[] = "";
static const wchar_t crlstore_def[] = L"system.CA";
static const wchar_t certstore_def[] = L"system.CA";
const wchar_t *mystore_def = L"user.MY";

static const Ini pse_path_default( "\\pkipse\\" );
static const Ini new_pse_path_default( "\\pkipse\\update\\" );
static const Ini rse_path_default( "\\pkica\\" );

static DWORD get_ProvType( const Ini &path );
static WndProvType get_WndProvType( const Ini &path );
static unsigned get_RevocationCheckFlags( const Ini &path );
static DWORD get_WinRevocationCheckFlags( const Ini &path );

#if !defined UNIX
static DWORD get_CertVerifyRevocationFlags( const Ini &path, std::string valueName );
static DWORD parseErrorcode( const std::string& str);
#endif	// !UNIX

static bool get_bool_def(const Ini& path, const std::string& name, bool def)
{
    std::string s = path.find_def(name.c_str(), def ? "true" : "false");
    for(std::string::iterator it = s.begin(); it != s.end(); it++) {
	*it = tolower(*it);
    }
    if(s == "true") {
        return true;
    } else {
        return false;
    }
}

void test_GenerateRoot( const Ini &path )
{
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    std::wstring subject = path.find_wstring( "subject" );
    std::string container = path.find_def( "cacontainer", cacontainer_def );
    std::string cdp = path.find_def( "cdp", "" );    
    std::wstring caname = path.find_wstring( "caname" );
    DWORD dwProvType = get_ProvType( path );
    CACMPT_Extensions Extensions;
    test_ProcessExtensions (path, "extensions", Extensions);
    WndProvType wnd_prov_type = get_WndProvType( path );
    std::string ProvName = path.find_def( "ProvName", "" );
    CACMPT_Period crl_update = path.find_def( "crl_period", CACMPT_Period::OneMonth );
        
    CACMPT_Period period = path.find_def( "period", CACMPT_Period::OneYear );
    CACMPT_Date NotBefore = path.find_def( "NotBefore", CACMPT_Date() );
    CACMPT_Date NotAfter = path.find_def( "NotAfter", CACMPT_Date() );
    
    if( NotAfter != CACMPT_Date() && NotBefore != CACMPT_Date() )
    {
	period = NotAfter - NotBefore;
    }

    bool keyExportable = get_bool_def(path, "keyExportable", false);

    PKIXCMP_Server *server = server_cache.Create_GenerateRoot( 
	rse_path, subject.c_str(), Extensions, caname.c_str(), 
        *ProvName.c_str() ? ProvName.c_str() : NULL, 
        keyExportable, dwProvType, container.c_str(), 
	period, NotBefore, cdp.c_str(), crl_update, wnd_prov_type );
    CACMPT_BLOB ca;
    ca = server->GetCert();
    std::string cacert = path.find_def( "cacert", cacert_def );
    ca.writeToFile( cacert.c_str() );
}

void test_InstallRoot( const Ini &path )
{
    std::string cacert = path.find_string( "cacert" );
    CACMPT_BLOB cert;
    cert.readFromFile (cacert);
    PKIXCMP_Base::InstallRoot (cert);
}

void test_UpdateRoot( const Ini &path )
{
    CACMPT_BLOB cert;

    CACMPT_BLOB output_buf;
    
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    std::string new_container = path.find_def( "cacontainer", cacontainer_def );
    DWORD dwProvType = get_ProvType( path );
    WndProvType wnd_prov_type = get_WndProvType( path );
    PKIXCMP_Message info;
    fill_message( path, info );
    CACMPT_BLOB ca;

    bool keyExportable = get_bool_def(path, "keyExportable", false);

    PKIXCMP_Server *server = server_cache.UpdateRoot( rse_path, 
	dwProvType, new_container.c_str(), keyExportable, output_buf, &info, wnd_prov_type, 
	&ca );
    if (!server)
	throw CA_EXCEPTION( CAException, "UpdateRoot  failed." );
    std::string output = path.find_def( "output", pkiann_def );
    output_buf.writeToFile( output );
    std::string cacert = path.find_def( "cacert", cacert_def );
    ca.writeToFile( cacert.c_str() );
}

void test_PasswdRootChange( const Ini &path )
{
    WndProvType wnd_prov_type = get_WndProvType( path );
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    if( server_cache.ChangePassword( rse_path, wnd_prov_type ) )
	throw CA_EXCEPTION( CAException, "ChangePassword failed." );
}

void test_CertReqMessage_Sign( const Ini &path )
{
    RequestInfo info;
    info.RequestType = path.find_enum(  "RequestType", str_request_type, sizeof( str_request_type ) 
	/ sizeof( *str_request_type ) );
    Ini pse_path( path.find_def( "pse_path", pse_path_default ) );
    info.RequestID = path.find_def( "RequestID", 0 );
    std::string input = path.find_def( "input", "" );
    WndProv &wnd_prov = get_client_wnd_prov( path );
    PKIXCMP_Client clnt( wnd_prov, pse_path.get_path(), 0, PROV_GOST_2001_DH );
    fill_message( path, info );
    info.RawRequest.readFromFile( input );
    if( path.find_def( "addpath", false ) )
	clnt.BuildChain( info.extra_certs );
    CACMPT_BLOB output_buf;
    if( clnt.CertReqMessage_EncodeAndSign (&info, output_buf ) )
	throw CA_EXCEPTION( CAException, 
	"CertReqMessage_EncodeAndSign failed." );
    std::string output = path.find_def( "output", pkireq_def );
    output_buf.writeToFile( output );
}

void test_CertReqMessage_EncodeAndSign( const Ini &path )
{
    bool exist = false;
    bool create = false;

    RequestInfo info;
    CACMPT_BLOB output_buf;
    
    info.RequestType = path.find_enum(  "RequestType", str_request_type, sizeof( str_request_type ) 
	/ sizeof( *str_request_type ) );
    info.RequestID = path.find_def( "RequestID", 0 );

    std::string input = path.find_def( "input", "" );

    CACMPT_BLOB old;
    switch (info.RequestType)
    {
    case REQUEST_TYPE_GET_CERTIFICATE: 
	if (input.empty())
	    exist = path.find_def( "use_existing", false );
	else
	    exist = false;
	if( !exist ) create = true;
	break;
    case REQUEST_TYPE_REVOKE_CERTIFICATE:
    {
	std::string reason_flags = path.find_string( "ReasonFlags" );
	info.RevokedReason = ReasonFlags::fromString( reason_flags.c_str() );
	exist = true;
	break;
    }
    case REQUEST_TYPE_INITIAL_REQUEST:
	if (input.empty())
	    exist = path.find_def( "use_existing", false );
	else
	    exist = false;
	if( !exist ) create = true;
	break;
    case REQUEST_TYPE_UPDATE_KEY:
    {
	std::string old_file = path.find_def( "input", pkicer_def );
	old.readFromFile( old_file );
	exist = true; create = true;
	break;
    }
    case REQUEST_TYPE_CHANGE_NAME:
    {	
	get_free_text( path, "KeyPhrase", info.keyPhrase );
	get_free_text( path, "AdditionalInfo", info.additionalInfo );
	exist = true;
	break;
    }
    case REQUEST_TYPE_GET_CRL:
    default:
	throw CA_EXCEPTION( CAException, "unsupported RequestType." );
    }

    Ini pse_path;
    if( exist || create )
	pse_path = path.find_def( "pse_path", pse_path_default );
    Ini new_pse_path;
    if( create && exist )
	new_pse_path = path.find_def( "new_pse_path", pse_path_default );
    std::string new_container;
    if( create )
	new_container = path.find_def( "container", container_def );
    unsigned long new_keyspec=0;
    if( create )
	new_keyspec = path.find_def( "keyspec",2);
    
    std::auto_ptr<PKIXCMP_Client> clnt;
    WndProv &wnd_prov = get_client_wnd_prov( path );
    fill_message( path, info );
    if( exist )
    {
	clnt.reset( new PKIXCMP_Client( wnd_prov, pse_path.get_path(), 0, PROV_GOST_2001_DH ) );
    }
    if( create ) 
    {
        bool keyExportable = get_bool_def(path, "keyExportable", false);

        DWORD dwProvType = get_ProvType( path );
	if( info.RequestType == REQUEST_TYPE_UPDATE_KEY )
	{
	    clnt->UpdateKey( wnd_prov, &info, new_pse_path.get_path(),
		0, dwProvType, new_container.c_str(), new_keyspec, keyExportable );
	}
	else
	{
	    clnt.reset( PKIXCMP_Client::GenerateKeyPair( wnd_prov, 
		pse_path.get_path(), 0, dwProvType, new_container.c_str(), 
		new_keyspec, keyExportable ) );
	}
    }

    path.find( "Subject", info.subjectRDN );
    if( !*info.RecipientGeneralName
	&& info.RequestType != REQUEST_TYPE_UPDATE_KEY )
    {
	throw CA_EXCEPTION( CAException, "RecipientGeneralName not specified." );
    }
    test_ProcessExtensions (path, "extensions", info.Extensions);
    switch (info.RequestType)
    {
    case REQUEST_TYPE_GET_CERTIFICATE:
	if (!input.empty())
	    info.RawRequest.readFromFile( input );
	else
	    clnt->PKCS10_EncodeAndSign (&info, info.RawRequest, true);
	break;
    }
    if( path.find_def( "addpath", false ) )
	clnt->BuildChain( info.extra_certs );
    if( clnt->CertReqMessage_EncodeAndSign (&info, output_buf ) )
	throw CA_EXCEPTION( CAException, "CertReqMessage_EncodeAndSign failed." );
    std::string output = path.find_def( "output", pkireq_def );
    output_buf.writeToFile( output );
}

void test_PKCS10_EncodeAndSign( const Ini &path )
{
    RequestInfo info;
    CACMPT_BLOB output_buf;
    info.subjectRDN = path.find_rdn( "Subject" );
    Ini pse_path( path.find_def( "pse_path", pse_path_default ) );
    std::string szContainer = path.find_def( "container", container_def );
    std::string output = path.find_def( "output", pcs10req_def );
    unsigned long keyspec = path.find_def("keyspec",2);
    test_ProcessExtensions (path, "extensions", info.Extensions);
    DWORD dwProvType = get_ProvType( path );
    WndProv &wnd_prov = get_client_wnd_prov( path );
    bool keyExportable = get_bool_def(path, "keyExportable", false);
    std::auto_ptr<PKIXCMP_Client> clnt( PKIXCMP_Client::GenerateKeyPair( 
	wnd_prov, pse_path.get_path(), 0, dwProvType, szContainer.c_str(), 
	keyspec, keyExportable ) );
    if( clnt->PKCS10_EncodeAndSign (&info, output_buf, true) )
	throw CA_EXCEPTION( CAException, "PKCS10_EncodeAndSign failed." );
    output_buf.writeToFile( output );
}

void test_CertReqMessage_Decode( const Ini &path )
{
    bool output;
    std::string input = path.find_def( "input", pkireq_def );
    CACMPT_BLOB req;
    req.readFromFile( input );
    RequestInfo info;
    int status = PKIXCMP_Base::CertReqMessage_Decode( req, 
	&info );
    if( status )
	throw CA_EXCEPTION( CAException, "CertReqMessage_Decode failed." );
    output = path.find_def( "output", true );
    if( output )
	out_RequestInfo( &info );
}

void test_CertReqMessage_Verify( const Ini &path )
{
    std::string input = path.find_def( "input", pkireq_def );
    CACMPT_BLOB req;
    req.readFromFile( input );

    int status = server_cache.Create_Verify()->CertReqMessage_Verify(req);
    if( status )
	throw CA_EXCEPTION( CAException, "test_CertReqMessage_Verify failed." );
}

void test_CertReqMessage_Process( const Ini &path )
{
    CACMPT_BLOB req;
    CACMPT_BLOB input_cert;
    std::string input;
    bool input_cert_found = path.find( "input_cert", input );
    if( input_cert_found )
    {
	input_cert.readFromFile( input );
    }
    else
    {
	input = path.find_def( "input", pkireq_def );
	req.readFromFile( input );
    }
    std::string output = path.find_def( "output", pkirep_def );
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    Ini pse_path;
    bool pse_path_found = path.find( "pse_path", pse_path );
    CACMPT_BLOB cert;
    PKIXCMP_Server *server = server_cache.Create_Read( rse_path );
    CertificateInfo certInfo;
    if( input_cert_found )
	server->CertReqCert_PreProcess( input_cert, &certInfo );
    else
	server->CertReqMessage_PreProcess( req, &certInfo );

    certInfo.NotBefore = path.find_def( "NotBefore", CACMPT_Date() );
    if( certInfo.NotBefore != CACMPT_Date() )
	certInfo.validity_changed = true;
    certInfo.NotAfter = path.find_def( "NotAfter", CACMPT_Date() );
    if( certInfo.NotAfter != CACMPT_Date() )
	certInfo.validity_changed = true;
    if( certInfo.NotBefore == CACMPT_Date() && certInfo.validity_changed ) {
	certInfo.NotBefore = CACMPT_Date::Now();
	if( certInfo.NotBefore >= certInfo.NotAfter ) {
	    certInfo.NotBefore = certInfo.NotAfter;
	    certInfo.NotBefore -= CACMPT_Period::OneYear;
	    certInfo.NotBefore -= CACMPT_Period::OneMonth;
	    certInfo.NotBefore -= CACMPT_Period::OneMonth;
	    certInfo.NotBefore -= CACMPT_Period::OneMonth;
	}
    }
    if( certInfo.NotAfter == CACMPT_Date() && certInfo.validity_changed ) {
	certInfo.NotAfter = certInfo.NotBefore;
	certInfo.NotAfter += CACMPT_Period::OneYear;
	certInfo.NotAfter += CACMPT_Period::OneMonth;
	certInfo.NotAfter += CACMPT_Period::OneMonth;
	certInfo.NotAfter += CACMPT_Period::OneMonth;
    }
    test_ProcessExtensions (path, "extensions", certInfo.Extensions);
    int status;
    if( !input_cert_found )
    {
	status = server->CertReqMessage_Verify(req);
	if( status )
	    throw CA_EXCEPTION( CAException, "CertReqMessage_Verify failed." );
    }
    fill_message( path, certInfo );
    if( path.find_def( "addpath", false ) )
	server->BuildChain( certInfo.extra_certs );
    CACMPT_BLOB rep;
    server->CertReqMessage_Process(&certInfo, rep);
    if (pse_path_found) {
	WndProv &wnd_prov = get_client_wnd_prov( path );
	PKIXCMP_Client client ( wnd_prov, pse_path.get_path(), 0, PROV_GOST_2001_DH );
	client.PKIXCMP_Sign ( rep, rep, &certInfo ); 
    }
    rep.writeToFile( output );
}

void test_CertReqMessage_Reject( const Ini &path )
{
    CACMPT_BLOB req;

    std::string input = path.find_def( "input", pkireq_def );
    req.readFromFile( input );
    std::string output = path.find_def( "output", pkirep_def );
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    Ini pse_path;
    bool pse_path_found = path.find( "pse_path", pse_path );
    CACMPT_BLOB cert;
    PKIXCMP_Server *server = server_cache.Create_Read( rse_path );

    RequestInfo info;
    int status = PKIXCMP_Base::CertReqMessage_Decode( req, 
	&info );
    if( status )
	throw CA_EXCEPTION( CAException, "CertReqMessage_Decode failed." );

    status = server->CertReqMessage_Verify(req);
    if( status )
	throw CA_EXCEPTION( CAException, "CertReqMessage_Verify failed." );

    fill_message( path, info );

    if( path.find_def( "addpath", false ) )
	server->BuildChain( info.extra_certs );

    info.pki_status = (enum PKIStatusEnum)
	path.find_enum(  "PKIstatus", str_PKIStatus, 
	sizeof( str_PKIStatus ) / sizeof( *str_PKIStatus ) );
    get_free_text( path, "StatusString", info.status_string );
    std::string failure_info = path.find_string( "FailureInfo" );
    info.failure_info.fromString( failure_info.c_str() );

    CACMPT_BLOB rep;
    server->CertReqMessage_Reject(info, rep, !pse_path_found);

    if (pse_path_found) {
	WndProv &wnd_prov = get_client_wnd_prov( path );
	PKIXCMP_Client client ( wnd_prov, pse_path.get_path(), 0, PROV_GOST_2001_DH );
	client.PKIXCMP_Sign ( rep, rep, &info ); 
    }
    rep.writeToFile( output );
}

void test_CertRepMessage_Decode( const Ini &path )
{
    std::string input = path.find_def( "input", pkirep_def );
    CACMPT_BLOB rep;
    rep.readFromFile( input );
    CertificateInfo info;
    int status = PKIXCMP_Base::CertRepMessage_Decode( rep, &info );
    if( status )
	throw CA_EXCEPTION( CAException, "CertRepMessage_Decode failed." );
    std::string output = path.find_def( "output", "true");
    //    std::transform(output.begin(),output.end(),output.begin(),tolower);
    for(std::string::iterator it=output.begin(); it != output.end(); it++) {
	*it = tolower(*it);
    }
    if( output == "true" )
	out_CertificateInfo( &info );
    std::string output_cer = path.find_def( "output_cert", "" );
    if( !output_cer.empty() )
	info.RawCertificate.writeToFile( output_cer );
}

void test_CertRepMessage_Verify( const Ini &path )
{
    std::string input_req = path.find_def( "input_req", pkireq_def );
    std::string input_rep = path.find_def( "input_rep", pkirep_def );
    CACMPT_BLOB req;
    req.readFromFile( input_req );
    CACMPT_BLOB rep;
    rep.readFromFile( input_rep );
    PKIXCMP_Client client(0, PROV_GOST_2001_DH);
    CertificateInfo info;
    int status = client.CertRepMessage_Verify( req, rep );
    if( status )
	throw CA_EXCEPTION( CAException, "CertRepMessage_Verify failed." );
}

void test_CertRepMessage_Install( const Ini &path )
{
    std::string input_cert = path.find_def( "input_cert", pkicer_def );
    CACMPT_BLOB cert;
    cert.readFromFile( input_cert );
    
    Ini pse_path( path.find_def( "pse_path", pse_path_default ) );
    WndProv &wnd_prov = get_client_wnd_prov( path );
    std::auto_ptr<PKIXCMP_Client> clnt( PKIXCMP_Client::OpenRequest (
	wnd_prov, cert ) );
    clnt->CertRepMessage_Install( cert, pse_path.get_path() );
}

void test_GenerateCRL( const Ini &path )
{
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    CACMPT_BLOB cert;
    PKIXCMP_Server *server = server_cache.Create_Read( rse_path );
    
    CrlInfo info;
    
    std::string input = path.find_def( "input", "" );
    if( !input.empty() )
    {
	CACMPT_BLOB in_crl;
	in_crl.readFromFile( input );
	PKIXCMP_Base::Crl_Decode( in_crl, &info );
    }
    else
    {
	path.find_string( "CrlSignatureAlgorithm", 
	    info.CrlSignatureAlgorithm,
	    sizeof( info.CrlSignatureAlgorithm ) );
	test_ProcessExtensions (path, "extensions", info.Extensions);
    }
    CACMPT_Date null_date;
    info.ThisUpdate = path.find_def( "ThisUpdate", null_date );
    info.NextUpdate = path.find_def( "NextUpdate", null_date );
    if( info.ThisUpdate != null_date )
	info.UseUpdate = true;

    CACMPT_BLOB out_crl;
    
    multi_sz delcert;
    if( path.find( "delcert", delcert ) )
    {
	multi_sz::const_iterator ci = delcert.begin();
	multi_sz::const_iterator cie = delcert.end();
	for( ; ci != cie; ++ci )
	{
	    cert.readFromFile( *ci );
	    CertificateInfo cert_info;
	    server->Cert_Decode( cert, &cert_info );
	    info.remove( cert_info.SerialNumber );
	}
    }
    ini_cprefix pred( "addcertcert" );
    Ini::const_iterator ie = path.param_end();
    Ini::const_iterator i = find_if<ini_cprefix>( path.param_begin(), ie, pred );
    for( ; i != ie; i = find_if<ini_cprefix>( ++i, ie, pred ) )
    {
	cert.readFromFile( i->get_string().c_str() );
	CertificateInfo cert_info;
	server->Cert_Decode( cert, &cert_info );
	CrlInfoItem add( cert_info.SerialNumber );
	std::string path_date( "addcertdate" );
	path_date += i->param().substr( strlen( "addcertcert" ) );
	std::string scertdate = path.find_string( path_date.c_str() );
	date1cpy( add.RevokedWhen, scertdate.c_str() );
	std::string path_ext( "addcertext" );
	path_ext += i->param().substr( strlen( "addcertcert" ) );
	test_ProcessExtensions( path, path_ext.c_str(), add.Extensions );
	std::string path_reason( "addcertreason" );
	path_reason += i->param().substr( strlen( "addcertcert" ) );
	std::string sreason;
	if( path.find( path_reason.c_str(), sreason ) )
	    add.SetReason( CrlReason_fromString( sreason.c_str() ) );
	std::string path_hold( "addhold" );
	path_hold += i->param().substr( strlen( "addcertcert" ) );
	std::string shold;
	if( path.find( path_hold.c_str(), shold ) )
	{
	    HoldInstruction h;
	    try {
		h = HoldInstruction_fromString( shold.c_str() );
	    }
	    catch( ... )
	    {
		h = HoldInstruction_fromOid( shold.c_str() );
	    }
	    add.SetHoldInstruction( h );
	}
	std::string path_invalidity( "addcertinvalidity" );
	path_invalidity += i->param().substr( strlen( "addcertcert" ) );
	CACMPT_Date invalidity;
	if( path.find( path_invalidity.c_str(), invalidity ) )
	    add.SetInvalidityDate( invalidity );
	info.push_back( add );
    }
    server->GenerateCRL(out_crl, &info);
    std::string output = path.find_def( "output", cacrl_def );
    out_crl.writeToFile( output );
}

void test_DecodeCRL( const Ini &path )
{
    std::string input = path.find_def( "input", cacrl_def );
    CACMPT_BLOB crl;
    crl.readFromFile( input );
    
    CrlInfo info;
    PKIXCMP_Base::Crl_Decode(crl, &info);
    bool output;
    output = path.find_def( "output", true );
    if( output )
	out_CrlInfo( &info );
}

void test_VerifyCRL( const Ini &path )
{
    std::string input = path.find_def( "input", cacrl_def );
    CACMPT_BLOB crl;
    crl.readFromFile( input );

    size_t add_base_quant = 0;
    int status;
    wmulti_sz addstore;
    std::auto_ptr<const CertificateStore> add_base( 
	get_extra_store( path, add_base_quant, addstore ) );
    status = PKIXCMP_Base::CertChain_VerifyCrl( crl, add_base.get(),
	add_base_quant );
    if( status )
	throw CA_EXCEPTION( CAException, "Crl_Verify failed." );
}

void test_Cert_Decode( const Ini &path )
{
    std::string input = path.find_def( "input", pkicer_def );
    CACMPT_BLOB cert;
    cert.readFromFile( input );
    CertificateInfo info;
    int status = PKIXCMP_Base::Cert_Decode( cert, &info );
    if( status )
	throw CA_EXCEPTION( CAException, "Cert_Decode failed." );
    bool output = path.find_def( "output", true );
    if( output )
	out_CertificateInfo( &info );
}

void test_RevAnnContent_Process( const Ini &path )
{
    std::string input = path.find_def( "input", pkicer_def );
    CACMPT_BLOB cert;
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    cert.readFromFile( input );
    std::string output = path.find_def( "output", revann_def );
    CACMPT_BLOB ann;
    PKIXCMP_Server *server = server_cache.Create_Read( rse_path );
    CertificateInfo cert_info;
    int status = PKIXCMP_Base::Cert_Decode( cert, &cert_info );
    if( status )
	throw CA_EXCEPTION( CAException, "Cert_Decode failed." );
    RevAnnContentInfo rev_info;
    strcpy( rev_info.SerialNumber, cert_info.SerialNumber );
    rev_info.subjectRDN = cert_info.subjectRDN;
    rev_info.PKIStatus = (enum PKIStatusEnum)
	path.find_enum(  "PKIstatus", str_PKIStatus, 
	sizeof( str_PKIStatus ) / sizeof( *str_PKIStatus ) );
    std::string willBeRevokedAt = path.find_string( "willBeRevokedAt" );
    date1cpy( rev_info.willBeRevokedAt, willBeRevokedAt.c_str() );
    fill_message( path, rev_info );
    if( path.find_def( "addpath", false ) )
	server->BuildChain( rev_info.extra_certs );
    server->RevAnnContent_Process(ann, &rev_info);
    ann.writeToFile( output );
}

void test_RevAnnContent_Decode( const Ini &path )
{
    std::string input = path.find_def( "input", revann_def );
    CACMPT_BLOB ann;
    ann.readFromFile( input );
    PKIXCMP_Client client(0, PROV_GOST_2001_DH);
    RevAnnContentInfo info;
    int status = client.RevAnnContent_DecodeAndVerify( 
	ann, &info );
    if( status )
	throw CA_EXCEPTION( CAException, 
	"RevAnnContent_DecodeAndVerify failed." );
    bool output = path.find_def( "output", true );
    if( output )
	out_RevAnnContentInfo( &info );
}

void test_CertChain_Verify( const Ini &path )
{
    bool disable_root = false;
    bool disable_predefined_crl_stores = false;
    bool disable_predefined_stores = false;
    if( path.find_def( "disable_root", false ) )
	disable_root = true;
    if( path.find_def( "disable_predefined_crl_stores", false ) )
	disable_predefined_crl_stores = true;
    if( path.find_def( "disable_predefined_stores", false ) )
	disable_predefined_stores = true;

    CertChainContext ctx(!disable_root,!disable_predefined_crl_stores,
	!disable_predefined_stores);

    std::string input = path.find_def( "input", pkicer_def );
    CACMPT_BLOB cert;
    cert.readFromFile( input );

    unsigned rev_flags = get_RevocationCheckFlags( path );

    ctx.set_flags( rev_flags );

    unsigned timeout = path.find_def( "timeout", 0 );
    ctx.set_timeout( timeout );

    encoded_certificate_list cert_list;
    get_extra_certs( path, "addcert", cert_list );
    ctx.set_list( &cert_list );

    encoded_certificate_list trust_list;
    get_extra_certs( path, "addtrust", trust_list );
    ctx.set_trust( &trust_list );

    encoded_crl_list crl_list;
    get_extra_crl( path, crl_list );
    ctx.add_crl_list( &crl_list );

    wmulti_sz add_store;
    size_t add_base_quant = 0;
    std::auto_ptr<const CertificateStore> add_base( 
	get_extra_store( path, add_base_quant, add_store ) );
    ctx.add_stores( add_base.get(), add_base_quant );

#if POLICY
    policy_oid_set user_initial_policy_set;
    get_policies( path, "policy.", user_initial_policy_set );
    ctx.add_policy( user_initial_policy_set );

    bool initial_policy_mapping_inhibit = path.find_def( 
	"inhibit", true );
    ctx.set_initial_policy_mapping_inhibit( 
	initial_policy_mapping_inhibit );

    bool initial_explicit_policy = path.find_def( 
	"explicit", true );
    ctx.set_initial_explicit_policy( 
	initial_explicit_policy );

    bool initial_any_policy_inhibit = get_bool_def(path, "any_inhibit", true);
    ctx.set_initial_any_policy_inhibit(initial_any_policy_inhibit);
#endif
    encoded_certificate_list chain;
    bool status = ctx.verify_certificate( cert );

    TrustStatus trust_status = ctx.get_status().get_unsigned();
    std::string str_status = path.find_def( "status", "" );
    TrustStatus must_status = TrustStatus::fromString( 
	str_status.c_str() );
    std::string err_msg;

    if( !status && must_status == TrustStatus::CT_NO_ERROR ) {
	err_msg = "Path verification failed: " + trust_status.toString();
	throw CA_EXCEPTION( CAException, err_msg.c_str() );
    }
    if( must_status != trust_status ) {
	err_msg = "Not same status.";
	err_msg += "\n  Status  : " + trust_status.toString();
	err_msg += "\n  Expected: " + must_status.toString() + "\n";
	throw CA_EXCEPTION( CAException, err_msg.c_str() );
    }
#if POLICY
    bool verify_policy = path.find_def( "vpolicy", false );
    if( verify_policy && trust_status == TrustStatus::CT_NO_ERROR )
    {
	policy_oid_set user_policy_set;
	get_policies( path, "vpolset.", user_policy_set );
	policy_set ret_policy_set;
	ctx.get_user_policy( ret_policy_set );
	if( ret_policy_set != user_policy_set )
	    throw CA_EXCEPTION( CAException, "Not same policy." );
	bool user_explicit_policy = path.find_def( 
	    "vexplicit", true );
	if( user_explicit_policy != ctx.get_user_explicit_policy() )
	    throw CA_EXCEPTION( CAException, 
	    "Explicit policy indicator not same." );
    }
#endif
}

void test_CertChain_Verify_CAPI( const Ini &path )
{
    std::string input = path.find_def( "input", pkicer_def );
    CACMPT_BLOB cert;
    cert.readFromFile( input );

    CERT_CREATE_CONTEXT_PARA createPara;
    ::memset(&createPara,0,sizeof(createPara));
    createPara.cbSize = sizeof(createPara);
    PCCERT_CONTEXT pCertInContext = ::CertCreateCertificateContext(
	X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
	cert.pbData,
	cert.cbData );
    if(!pCertInContext)
	throw CA_EXCEPTION( CAException, 
	    "Can't create certificate context." );

    encoded_certificate_list cert_list;
    get_extra_certs( path, "addcert", cert_list );

    HCERTSTORE hStore = NULL;
    HCERTCHAINENGINE hChainEngine = NULL;
    PCCERT_CHAIN_CONTEXT pChainContext = NULL;
    HCERTSTORE* pAddStores = NULL;

    try
    {
	hStore = ::CertOpenStore(
	    CERT_STORE_PROV_MEMORY,
	    X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
	    0,
	    CERT_STORE_CREATE_NEW_FLAG,
	    NULL);
	if(!hStore)
	    throw CA_EXCEPTION( CAException, 
		"Can't create memory store." );

	encoded_certificate_list::const_iterator blit = cert_list.begin();
	encoded_certificate_list::const_iterator blen = cert_list.end();
	for( ; blit != blen; ++blit)
	    if(!::CertAddEncodedCertificateToStore(
		hStore,
		X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
		blit->pbData,blit->cbData,
		CERT_STORE_ADD_ALWAYS,
		NULL))
		    throw CA_EXCEPTION( CAException, 
			"Can't add certificate to store." );
        
	encoded_crl_list crl_list;
	get_extra_crl( path, crl_list );

	encoded_crl_list::const_iterator crlblit = crl_list.begin();
	encoded_crl_list::const_iterator crlblen = crl_list.end();
	for( ; crlblit != crlblen; ++crlblit)
	    if(!::CertAddEncodedCRLToStore(
		hStore,
		X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
		crlblit->pbData,crlblit->cbData,
		CERT_STORE_ADD_ALWAYS,
		NULL))
		    throw CA_EXCEPTION( CAException, 
			"Can't add CRL to store." );
	CERT_CHAIN_ENGINE_CONFIG chainEngineConfig;
	::memset(&chainEngineConfig,0,sizeof(chainEngineConfig));
	chainEngineConfig.cbSize = sizeof(chainEngineConfig);
	chainEngineConfig.cAdditionalStore = 1;
	pAddStores = new HCERTSTORE;
	chainEngineConfig.rghAdditionalStore = pAddStores;
	if(!chainEngineConfig.rghAdditionalStore)
	    throw CA_MEMORY_EXCEPTION;
	chainEngineConfig.rghAdditionalStore[0] = hStore;
	chainEngineConfig.MaximumCachedCertificates = 0;
	chainEngineConfig.CycleDetectionModulus = 0;
	if(!::CertCreateCertificateChainEngine(&chainEngineConfig,&hChainEngine))
	    throw CA_EXCEPTION( CAException, 
		"Can't create chain engine." );
	CERT_CHAIN_PARA chainPara;
	::memset(&chainPara,0,sizeof(chainPara));
	chainPara.cbSize = sizeof(chainPara);
	chainPara.RequestedUsage.dwType = USAGE_MATCH_TYPE_AND;
	pChainContext = NULL;
	DWORD rev_flags = get_WinRevocationCheckFlags( path );
	if(!::CertGetCertificateChain(
	    0,
	    pCertInContext,
	    NULL,
	    hStore,
	    &chainPara,
	    rev_flags,
	    NULL,
	    &pChainContext)) {
	    throw CA_CRYPT_EXCEPTION;
	}

	CERT_CHAIN_POLICY_PARA policyPara;
	::memset(&policyPara,0,sizeof(policyPara));
	policyPara.cbSize = sizeof(policyPara);
	CERT_CHAIN_POLICY_STATUS policyStatus;
	::memset(&policyStatus,0,sizeof(policyStatus));
	policyStatus.cbSize = sizeof(policyStatus);
	BOOL status = ::CertVerifyCertificateChainPolicy(
	    CERT_CHAIN_POLICY_BASE,
	    pChainContext,
	    &policyPara,
	    &policyStatus);
        
	DWORD dwErrorStatus = pChainContext->TrustStatus.dwErrorStatus;
	if(policyStatus.dwError == (DWORD)CERT_E_WRONG_USAGE)
	    dwErrorStatus |= CERT_TRUST_IS_NOT_VALID_FOR_USAGE; 
	if(policyStatus.dwError == (DWORD)TRUST_E_BASIC_CONSTRAINTS)
	    dwErrorStatus |= CERT_TRUST_INVALID_BASIC_CONSTRAINTS;

	TrustStatus trust_status(dwErrorStatus);
	std::string str_status = path.find_def( "status", "" );
	TrustStatus must_status = TrustStatus::fromString( 
	    str_status.c_str() );
	std::string err_msg;

	if( !status && must_status == TrustStatus::CT_NO_ERROR ) {
	    err_msg = "Path verification failed: " + trust_status.toString();
	    throw CA_EXCEPTION( CAException, err_msg.c_str() );
	}
	if( TrustStatus::CT_NO_ERROR == must_status )
	{
	    if( TrustStatus::CT_NO_ERROR != trust_status.get_unsigned() ) {
		err_msg = "Not same status.";
		err_msg += "\n  Status  : " + trust_status.toString();
		err_msg += "\n  Expected: " + must_status.toString() + "\n";
		throw CA_EXCEPTION( CAException, err_msg.c_str() );
	    }
	}
	else if( !(must_status.get_unsigned() & trust_status.get_unsigned()) ) {
	    err_msg = "Not same status.";
	    err_msg += "\n  Status  : " + trust_status.toString();
	    err_msg += "\n  Expected: " + must_status.toString() + "\n";
	    throw CA_EXCEPTION( CAException, err_msg.c_str() );
	}

	::CertCloseStore(hStore,0);
	::CertFreeCertificateContext(pCertInContext);
	::CertFreeCertificateChain(pChainContext);
	delete pAddStores;
    }
    catch(...)
    {
	if(pChainContext)
	    ::CertFreeCertificateChain(pChainContext);
	if(hStore)
	    ::CertCloseStore(hStore,CERT_CLOSE_STORE_FORCE_FLAG);	
	if(pAddStores)
	    delete pAddStores;
	throw;
    }
}

struct LoadCertAndCreateContextFun 
    : public std::unary_function<std::string, PCCERT_CONTEXT>
{
    PCCERT_CONTEXT operator()( const std::string& certPath) {
	CACMPT_BLOB cert;
	cert.readFromFile(certPath);
	PCCERT_CONTEXT pCert = CertCreateCertificateContext(
	    X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
	    cert.pbData, cert.cbData);
	if(!pCert) {
	    throw CA_CRYPT_EXCEPTION;
	}
	return pCert;
    }
};

struct AddToStoreFun : public std::unary_function<std::string,void>
{
    HCERTSTORE hStore;
    AddToStoreFun( HCERTSTORE h): hStore(h) { }
    void operator()( const std::string& certPath) {
	CACMPT_BLOB cert;
	cert.readFromFile(certPath);
	if(!CertAddEncodedCertificateToStore(hStore,
	    X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
	    cert.pbData, cert.cbData,
	    CERT_STORE_ADD_ALWAYS, 0)
	    && !CertAddEncodedCRLToStore(hStore,
	    X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
	    cert.pbData, cert.cbData,
	    CERT_STORE_ADD_ALWAYS, 0)) {
	    throw CA_CRYPT_EXCEPTION;
	}
    }
};

struct FreeCertContextNoThrowFun
    : public std::unary_function<PCCERT_CONTEXT,void>
{
    void operator()( PCCERT_CONTEXT pCert) {
	CertFreeCertificateContext(pCert);
    }
};

void test_CertVerifyRevocation( const Ini& path)
{
#if defined UNIX
    UNUSED(path);
    throw CA_CRYPT_EXCEPTION;
#else // UNIX
    multi_sz certs = path.find_multu_sz("certs");
    string issuer = path.find_def("issuer","");
    multi_sz store = path.find_def("store", multi_sz());
    DWORD flags = get_CertVerifyRevocationFlags(path,"flags");
    std::string resultStr = path.find_def("result","true");
    std::transform(resultStr.begin(),resultStr.end(),resultStr.begin(),tolower);
    bool result = (resultStr == "true");
    CACMPT_Date time = path.find_def( "time", CACMPT_Date::Now() );
    std::string errorStr = path.find_def("errorcode","0");
    DWORD errorcode = parseErrorcode(errorStr);


    std::vector<PCCERT_CONTEXT> certContexts;
    PCCERT_CONTEXT pIssuer = 0;
    HCERTSTORE hStore = 0;
    try
    {
	std::transform(certs.begin(),certs.end(),
	    std::back_inserter(certContexts),LoadCertAndCreateContextFun());

	hStore = CertOpenStore(CERT_STORE_PROV_MEMORY,0,0,0,0);
	if(!hStore) {
	    throw CA_CRYPT_EXCEPTION;
	}

	std::for_each(store.begin(),store.end(),AddToStoreFun(hStore));

	if( !issuer.empty() ) {
	    CACMPT_BLOB issuerBlob;
	    issuerBlob.readFromFile(issuer);

	    pIssuer = CertCreateCertificateContext(
		X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
		issuerBlob.pbData, issuerBlob.cbData);
	    if(!pIssuer) {
		throw CA_CRYPT_EXCEPTION;
	    }
	}

	FILETIME ft = time.getFileTime();

	CERT_REVOCATION_CRL_INFO crlInfo = { sizeof(crlInfo) };

	CERT_REVOCATION_PARA para = { sizeof(para) };
	para.cCertStore = 1;
	para.rgCertStore = &hStore;
	para.hCrlStore = hStore;
	para.pIssuerCert = pIssuer;
	para.pftTimeToUse = &ft;
	para.pCrlInfo = &crlInfo;

	CERT_REVOCATION_STATUS status = { sizeof(status) };

	bool res = (TRUE == CertVerifyRevocation(
	    X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
	    CERT_CONTEXT_REVOCATION_TYPE,
	    static_cast<DWORD>(certContexts.size()),
	    reinterpret_cast<PVOID*>(const_cast<PCERT_CONTEXT*>(&certContexts[0])),
	    flags,
	    &para,
	    &status));

	if(result == true && res != true) {
	    throw CA_CRYPT_EXCEPTION;
	}

	if(result == false && ( res != false || status.dwError != errorcode) ) {
	    throw CA_CRYPT_EXCEPTION;
	}
    }
    catch(...)
    {
	std::for_each(certContexts.begin(),certContexts.end(),
	    FreeCertContextNoThrowFun());
	if(pIssuer) {
	    CertFreeCertificateContext(pIssuer);
	}
	if(hStore) {
	    CertCloseStore(hStore,CERT_CLOSE_STORE_FORCE_FLAG);
	}

	throw;
    }
#endif	// UNIX
}

void test_IniSet( const Ini &path )
{
    IniValue src = path["src"];
    Ini dest_ini( path.find_string( "dest" ).c_str() );
    switch( src.get_type() )
    {
    case IniValue::String:
	dest_ini.insert( path.find_string( "param" ).c_str(), 
	    src.get_string().c_str() );
	break;
    case IniValue::Long:
	dest_ini.insert( path.find_string( "param" ).c_str(), 
	    src.get_long() );
	break;
    case IniValue::Bool:
	dest_ini.insert( path.find_string( "param" ).c_str(), 
	    src.get_bool() );
	break;
    case IniValue::Binary:
	dest_ini.insert( path.find_string( "param" ).c_str(), 
	    src.get_binary() );
	break;
    default:
	ini_throw::throw_bad_type();
    }
}

void test_IniSetFile( const Ini &path )
{
    std::string src = path.find_string( "src" );
    CACMPT_BLOB src_blob;
    src_blob.readFromFile( src.c_str() );
    Ini dest_ini( path.find_string( "dest" ).c_str() );
    dest_ini.insert( path.find_string( "param" ).c_str(), src_blob );
}

void test_ListCertificateInStore( const Ini &path )
{
    encoded_certificate_list list;
    CertificateStore store;
    std::wstring issuer = path.find_def( "issuer", L"" );
    std::string serial = path.find_def( "serial", "" );
    store.Set(path.find_def( "store", certstore_def ).c_str());
    int status = PKIXCMP_Base::CertStore_Find( list, 
	store, issuer.c_str(), serial.c_str() );
    if( status )
	throw CA_EXCEPTION( CAException, "CertStore_Find failed." );
    for( encoded_certificate_list::const_iterator i = list.begin(); i !=
	list.end(); ++i )
    {
	const CACMPT_BLOB &cert = *i;
	CertificateInfo info;
	std::cout << "-------" << std::endl;
	try {
	    PKIXCMP_Base::Cert_Decode( cert, &info );
	    std::cout << "Issuer :" << info.issuerRDN.tostring().c_str() << std::endl;
	    std::cout << "Subject:" << info.subjectRDN.tostring().c_str() << std::endl;
	    std::cout << "Serial :" << info.SerialNumber << std::endl;
	}
	catch( ... )
	{
	    std::cout << "Invalid certificate format" << std::endl;
	}
    }
}

void test_DeleteCertificateFromStore( const Ini &path )
{
    CertificateStore store;
    std::wstring issuer = path.find_def( "issuer", L"" );
    std::string serial = path.find_def( "serial", "" );
    encoded_certificate_list cert_list;
    store.Set(path.find_def( "store", certstore_def ).c_str());
    int status = PKIXCMP_Base::CertStore_Find( cert_list, 
	store, issuer.c_str(), serial.c_str());
    if( status )
	throw CA_EXCEPTION( CAException, "CertStore_Find failed." );
    int j = 0;
    for( encoded_certificate_list::const_iterator i = 
	cert_list.begin(); i != cert_list.end(); ++i, j++ )
    {
	status = PKIXCMP_Base::CertStore_Del( store, *i);
	if( status )
	    throw CA_EXCEPTION( CAException, "CertStore_Del failed." );
    }
    TCHAR str[10]; sprintf( str, "%d", j );
    std::cout << "Deleted " << str << " certificate(s)" << std::endl;
}

void test_AddCertificateToStore( const Ini &path )
{
    CertificateStore store; 
    std::string input = path.find_string( "input" );
    CACMPT_BLOB cert;
    store.Set(path.find_def( "store", crlstore_def ).c_str());
    cert.readFromFile( input );
    PKIXCMP_Base::CertStore_Add(store, cert);
}

void test_ExtractCertificateFromStore( const Ini &path )
{
    CertificateStore store;
    std::wstring issuer = path.find_def( "issuer", L"" );
    std::string serial = path.find_def( "serial", "" );
    encoded_certificate_list cert_list;
    store.Set(path.find_def( "store", certstore_def ).c_str());
    int status = PKIXCMP_Base::CertStore_Find( cert_list, 
	store, issuer.c_str(), serial.c_str());
    if( status )
	throw CA_EXCEPTION( CAException, "CertStore_Find failed." );
    if( cert_list.size() == 0 )
	throw CA_EXCEPTION( CAException, "No certificate found." );
    std::string output = path.find_string( "output" );
    int j = 0;
    for( encoded_certificate_list::const_iterator i = 
	cert_list.begin(); i != cert_list.end(); ++i, j++ )
    {
	TCHAR str[10]; sprintf( str, "%d.der", j );
	i->writeToFile( ( std::string( output ) + str ).c_str() );
    }
}

void test_ListCrlInStore( const Ini &path )
{
    encoded_crl_list list;
    CertificateStore store;
    std::wstring issuer = path.find_def( "issuer", L"" );
    store.Set(path.find_def( "store", crlstore_def ).c_str());
    int status = PKIXCMP_Base::CrlStore_Find( list, store, 
	issuer.c_str() );
    if( status )
	throw CA_EXCEPTION( CAException, "CrlStore_Find failed." );
    for( encoded_crl_list::const_iterator i = list.begin(); i !=
	list.end(); ++i )
    {
	const CACMPT_BLOB &cert = *i;
	CrlInfo info;
	std::cout << "-------" << std::endl;
	try {
	    PKIXCMP_Base::Crl_Decode( cert, &info );
	    std::cout << "Issuer :" << info.issuerRDN.tostring().c_str() << std::endl;
	    std::cout << "ThisUpdate:" << info.ThisUpdate.tostring() << std::endl;
	    std::cout << "NextUpdate:" << info.NextUpdate.tostring() << std::endl;
	}
	catch( ... )
	{
	    std::cout << "Invalid crl format" << std::endl;
	}
    }
}

void test_DeleteCrlFromStore( const Ini &path )
{
    CertificateStore store;
    store.Set(path.find_def( "store", crlstore_def ).c_str());

    std::wstring issuer = path.find_def( "issuer", L"" );
    
    encoded_crl_list crl_list;
    int status = PKIXCMP_Base::CrlStore_Find( crl_list, 
	store, issuer.c_str());
    if( status )
	throw CA_EXCEPTION( CAException, "CrlStore_Find failed." );
    int j = 0;
    for( encoded_crl_list::const_iterator i = crl_list.begin(); i !=
	crl_list.end(); ++i, j++ )
    {
	PKIXCMP_Base::CrlStore_Del(store, *i);
    }
    TCHAR str[10]; sprintf( str, "%d", j );
    std::cout << "Deleted " << str << " crl(s)" << std::endl;
}

void test_AddCrlToStore( const Ini &path )
{
    CertificateStore store;
    store.Set(path.find_def( "store", crlstore_def ).c_str());
    std::string input = path.find_string( "input" );
    CACMPT_BLOB crl;
    crl.readFromFile( input );
    bool replace = path.find_def( "replace", true );
    PKIXCMP_Base::CrlStore_Add(store.GetName(), crl, store.isSystem(), replace);
}

void test_ExtractCrlFromStore( const Ini &path )
{
    CertificateStore store;
    store.Set(path.find_def( "store", crlstore_def ).c_str());
    std::wstring issuer = path.find_def( "issuer", L"" );
    encoded_crl_list crl_list;
    int status = PKIXCMP_Base::CrlStore_Find( crl_list, 
	store, issuer.c_str());
    if( status )
	throw CA_EXCEPTION( CAException, "CrlStore_Find failed." );
    if( crl_list.size() == 0 )
	throw CA_EXCEPTION( CAException, "No CRL found." );
    std::string output = path.find_string( "output" );
    int j = 0;
    for( encoded_crl_list::const_iterator i = crl_list.begin(); i !=
	crl_list.end(); ++i, j++ )
    {
	TCHAR str[10]; sprintf( str, "%d.der", j );
	i->writeToFile( ( std::string( output ) + str ).c_str() );
    }
}

void test_CrossReqMessage_EncodeAndSign( const Ini &path )
{
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    PKIXCMP_Server *server = server_cache.Create_Read( rse_path );
    CACMPT_BLOB cr_msg;
    CertificateInfo info;
    fill_message( path, info );
    std::string addpath = path.find_def( "addpath", "false");
    //std::transform(addpath.begin(),addpath.end(),addpath.begin(),tolower);
    for(std::string::iterator it=addpath.begin(); it != addpath.end(); it++) {
	*it = tolower(*it);
    }
    if( addpath == "true" )
	server->BuildChain( info.extra_certs );
    server->CrossReqMessage_EncodeAndSign( &info, cr_msg );
    std::string output = path.find_def( "output", crossreq_def );
    cr_msg.writeToFile( output );
}

void test_PKCS10_CrossReq ( const Ini &path )
{
    WndProvType wnd_prov_type = get_WndProvType( path );
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    PKIXCMP_Server *server = server_cache.Create_Read( rse_path, wnd_prov_type );
    CACMPT_BLOB cr_msg;
    RequestInfo info;
    CertificateInfo certinfo;
    int status = PKIXCMP_Base::Cert_Decode( server->GetCert(), &certinfo );
    if( status )
	throw CA_EXCEPTION( CAException, "Cert_Decode failed." );
    info.subjectRDN = certinfo.subjectRDN;
    info.Extensions = certinfo.Extensions;
    test_ProcessExtensions (path, "extensions", info.Extensions);
    server->PKCS10_EncodeAndSign ( &info, cr_msg, false );
    std::string output = path.find_def( "output", crossreq_def );
    cr_msg.writeToFile( output );
}

void test_ErrorMsgInfo_EncodeAndSign( const Ini &path )
{
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    PKIXCMP_Server *server = server_cache.Create_Read( rse_path );
    ErrorMsgInfo em_info;
    em_info.pki_status = (enum PKIStatusEnum)
	path.find_enum(  "PKIstatus", str_PKIStatus, 
	sizeof( str_PKIStatus ) / sizeof( *str_PKIStatus ) );
    em_info.error_code = path.find_def( "error_code", 0 );
    get_free_text( path, "StatusString", em_info.status_string );
    get_free_text( path, "ErrorDetails", em_info.error_details );
    fill_message( path, em_info );
    if( !*em_info.RecipientGeneralName )
	throw CA_EXCEPTION( CAException, 
	"RecipientGeneralName not specified." );
    std::string failure_info = path.find_string( "FailureInfo" );
    em_info.failure_info.fromString( failure_info.c_str() );
    CACMPT_BLOB em_msg;
    if( path.find_def( "addpath", false ) )
	server->BuildChain( em_info.extra_certs );
    server->ErrorMsgInfo_EncodeAndSign( &em_info, em_msg );
    std::string output = path.find_def( "output", emi_def );
    em_msg.writeToFile( output );
}

void test_ErrorMsgInfo_Decode( const Ini &path )
{
    std::string input = path.find_def( "input", emi_def );
    CACMPT_BLOB input_blob;
    input_blob.readFromFile( input );
    ErrorMsgInfo em_info;
    PKIXCMP_Base::ErrorMsgInfo_Decode( input_blob, &em_info );
    bool output = path.find_def( "output", true );
    if( output )
	out_ErrorMsgInfo( &em_info );
}

void test_ErrorMsgInfo_Verify( const Ini &path )
{
    Ini pse_path( path.find_def( "pse_path", pse_path_default ) );
    std::string input = path.find_def( "input", emi_def );
    CACMPT_BLOB em_msg;
    em_msg.readFromFile( input );
    
    WndProv &wnd_prov = get_client_wnd_prov( path );
    PKIXCMP_Client client ( wnd_prov, pse_path.get_path(), 0, PROV_GOST_2001_DH );
    int status = client.ErrorMsgInfo_Verify( em_msg );
    if( status )
	throw CA_EXCEPTION( CAException, "CertRepMessage_Install failed." );
}

void test_CertAnnContent_EncodeAndSign( const Ini &path )
{
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    PKIXCMP_Server *server = server_cache.Create_Read( rse_path );
    std::string input = path.find_def( "input", pkicer_def ); 
    CertificateInfo info;
    info.RawCertificate.readFromFile( input );
    CACMPT_BLOB cann_msg;
    fill_message( path, info );
    if( path.find_def( "addpath", false ) )
	server->BuildChain( info.extra_certs );
    server->CertAnnContent_EncodeAndSign( &info, cann_msg );
    std::string output = path.find_def( "output", cann_def );
    cann_msg.writeToFile( output );
}

void test_CertAnnContent_DecodeAndVerify( const Ini &path )
{
    std::string input = path.find_def( "input", cann_def );
    CACMPT_BLOB input_blob;
    input_blob.readFromFile( input );
    Ini pse_path( path.find_def( "pse_path", pse_path_default ) );
    WndProv &wnd_prov = get_client_wnd_prov( path );
    PKIXCMP_Client client ( wnd_prov, pse_path.get_path(), 0, PROV_GOST_2001_DH );
    CACMPT_BLOB output_blob;
    client.CertAnnContent_DecodeAndVerify( input_blob, output_blob );
    std::string output = path.find_def( "output", pkicer_def );
    output_blob.writeToFile( output );
}

void test_ToBase64( const Ini &path )
{
    std::string input = path.find_string( "input" );
    std::string output = path.find_string( "output" );
    bool ishdr = false;
    std::string header;
    ishdr = ishdr || path.find( "header", header );
    std::string footer;
    ishdr = ishdr || path.find( "footer", footer );
    CACMPT_BLOB src;
    src.readFromFile( input );
    if( ishdr )
	src.toBase64Hdr( header.c_str(), footer.c_str() ).writeToFile( output );
    else
	src.toBase64().writeToFile( output );
}

void test_FromBase64( const Ini &path )
{
    std::string input = path.find_string( "input" );
    std::string output = path.find_string( "output" );
    bool ishdr = false;
    std::string header;
    ishdr = ishdr || path.find( "header", header );
    std::string footer;
    ishdr = ishdr || path.find( "footer", footer );
    CACMPT_BLOB src;
    src.readFromFile( input );
    if( ishdr )
	src.fromBase64Hdr( header.c_str(), footer.c_str() ).writeToFile( output );
    else
	src.fromBase64().writeToFile( output );
}

void test_GenMsgContent_EncodeAndSign( const Ini &path )
{
    Ini rse_path( path.find_def( "rse_path", rse_path_default ) );
    PKIXCMP_Server *server = server_cache.Create_Read( rse_path );
    std::string input = path.find_def( "input", pkicer_def ); 
    PKIXCMP_Message info;
    fill_message( path, info );
    if( path.find_def( "addpath", false ) )
	server->BuildChain( info.extra_certs );
    CACMPT_BLOB gen_msg;
    server->GenMsgContent_EncodeAndSign( &info, gen_msg );
    std::string output = path.find_def( "output", genm_def );
    gen_msg.writeToFile( output );
}

void test_ClearCacheItem( const Ini &path )
{
    multi_sz sz = path.find_multu_sz( "src" );
    multi_sz::const_iterator ci = sz.begin();
    multi_sz::const_iterator cie = sz.end();
    for( ; ci != cie; ci++ )
	server_cache.ClearCacheItem( Ini( *ci ) );
}

void test_PasswdClientChange( const Ini &path )
{
    Ini pse_path( path.find_def( "pse_path", pse_path_default ) );
    WndProv &wnd_prov = get_client_wnd_prov( path );
    PKIXCMP_Client client ( wnd_prov, pse_path.get_path(), 0, PROV_GOST_2001_DH );
    client.ChangePin( wnd_prov );
}

static void dump_cert_store( HCERTSTORE hCertStore)
{
    PCCERT_CONTEXT pCertContext = 0;

    pCertContext = CertFindCertificateInStore( hCertStore, 
        X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, 0,
        CERT_FIND_ANY, NULL, NULL );
    while( pCertContext ) 
    {
		::printf("#cert#\n");
		pCertContext = CertFindCertificateInStore( hCertStore, 
			X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, 0,
			CERT_FIND_ANY, NULL, pCertContext );
    }
    if (pCertContext) CertFreeCertificateContext( pCertContext );
}

void test_GetURL( const Ini &path )
{
    std::string url = path.find_string( "url" );
    PCERT_CONTEXT pCertContext = NULL;
    HCERTSTORE hCertStore = NULL;
    if(!::CryptRetrieveObjectByUrl(
		url.c_str(),
		CONTEXT_OID_CRL,
		0,
		0,
		(LPVOID*)&pCertContext,
		NULL,NULL,NULL,NULL))
			throw CA_EXCEPTION( CAException, "CryptRetrieveObjectByUrl() failed.");
    CACMPT_BLOB encoded( pCertContext->pbCertEncoded, pCertContext->cbCertEncoded);
    std::string output = path.find_string( "output" );
    encoded.writeToFile( output );
    ::dump_cert_store(hCertStore);
}

static void test_QuickCert( const Ini& path )
{
    // create Server
    ASN1BEREncodeBuffer enc_buffer;
    Ini rse_path = path.find_def( "rse_path", rse_path_default );
    PKIXCMP_Server *server = server_cache.Create_Read( rse_path );

    // Parse server certificate
    CACMPT_ASN1BERDecodeBuffer dec_buffer( server->GetCert() );
    ASN1T_Certificate asn1t_ca;
    ASN1C_Certificate asn1c_ca (dec_buffer, asn1t_ca);
    if( asn1c_ca.Decode() < 0 )
	throw CA_ASN1_EXCEPTION(dec_buffer.getCtxtPtr());

    // Create user secret
//    Ini pse_path = path.find_def( "pse_path", pse_path_default );
    std::string new_container = path.find_def( "container", container_def );
    unsigned long new_keyspec = path.find_def( "keyspec",2);
    std::auto_ptr<PKIXCMP_Client> clnt;
    DWORD dwProvType = get_ProvType( path );
    bool keyExportable = get_bool_def(path, "keyExportable", false);
    clnt.reset( PKIXCMP_Client::GenerateKeyPair( no_pin_wnd_prov, 
	NULL, 0, dwProvType, new_container.c_str(), 
	new_keyspec, keyExportable ) );

    // create user cert template
    ASN1T_Certificate asn1t_cert;
//    ASN1CTXT* pctxt = enc_buffer.getCtxtPtr();
    ASN1CTXT* pdecctxt = dec_buffer.getCtxtPtr();
    asn1t_cert.tbsCertificate.version = Version::v3;
    asn1t_cert.tbsCertificate.m.versionPresent = 1;
    asn1t_cert.tbsCertificate.serialNumber = "1";
    asn1t_cert.tbsCertificate.signature = ASN1T_AlgorithmIdentifier_set (pdecctxt,
	server->GetCSP(), AT_SIGNATURE);
    asn1t_cert.tbsCertificate.issuer = asn1t_ca.tbsCertificate.subject;
    asn1t_cert.tbsCertificate.validity.notBefore.t = T_Time_utcTime;
    asn1t_cert.tbsCertificate.validity.notBefore.u.utcTime = ASN1UTCTime_current (enc_buffer);
    asn1t_cert.tbsCertificate.validity.notAfter.t = T_Time_utcTime;
    asn1t_cert.tbsCertificate.validity.notAfter.u.utcTime = ASN1UTCTime_add (enc_buffer,
	asn1t_cert.tbsCertificate.validity.notBefore.u.utcTime, CACMPT_Period::OneYear);
    asn1t_cert.tbsCertificate.validity.notAfter.u.utcTime = ASN1UTCTime_min (enc_buffer,
	asn1t_cert.tbsCertificate.validity.notAfter.u.utcTime, 
	asn1t_ca.tbsCertificate.validity.notAfter.u.utcTime);
    asn1t_cert.tbsCertificate.m.issuerUniqueIDPresent = 0;
    asn1t_cert.tbsCertificate.m.subjectUniqueIDPresent = 0;
    asn1t_cert.tbsCertificate.m.extensionsPresent = 0;
    rtDListInit (&asn1t_cert.tbsCertificate.extensions);

    // Set public key
    asn1t_cert.tbsCertificate.subjectPublicKeyInfo = ASN1T_SubjectPublicKeyInfo_set (
	clnt->GetCSP(), new_keyspec, pdecctxt);

    // Reset new params
    std::string serial;
    if( path.find( "serial", serial ) )
	asn1t_cert.tbsCertificate.serialNumber = serial.c_str();
    CACMPT_PARSED_RDN subjectRDN;
    if( path.find( "Subject", subjectRDN ) )
	subjectRDN.parse (dec_buffer, asn1t_cert.tbsCertificate.subject);
    CACMPT_PARSED_RDN issuerRDN;
    if( path.find( "Issuer", issuerRDN ) )
	issuerRDN.parse (dec_buffer, asn1t_cert.tbsCertificate.issuer);
    CACMPT_Extensions Extensions;
    test_ProcessExtensions (path, "extensions", Extensions);
    ASN1T_Extensions_set (pdecctxt, asn1t_cert.tbsCertificate.extensions, Extensions);
    asn1t_cert.tbsCertificate.m.extensionsPresent = asn1t_cert.tbsCertificate.extensions.count > 0;
    CACMPT_Date NotBefore = path.find_def( "NotBefore", CACMPT_Date() );
    if( NotBefore != CACMPT_Date() )
    {
	if( NotBefore.year() < 2050 )
	    asn1t_cert.tbsCertificate.validity.notBefore.u.utcTime =
		date2cpy( enc_buffer, NotBefore, T_Time_utcTime );
	else
	{
	    asn1t_cert.tbsCertificate.validity.notBefore.t = T_Time_generalTime;
	    asn1t_cert.tbsCertificate.validity.notBefore.u.generalTime =
		date2cpy( enc_buffer, NotBefore, T_Time_generalTime );
	}
    }
    CACMPT_Date NotAfter = path.find_def( "NotAfter", CACMPT_Date() );
    if( NotAfter != CACMPT_Date() )
    {
	if( NotAfter.year() < 2050 )
	    asn1t_cert.tbsCertificate.validity.notAfter.u.utcTime =
		date2cpy( enc_buffer, NotAfter, T_Time_utcTime );
	else
	{
	    asn1t_cert.tbsCertificate.validity.notAfter.t = T_Time_generalTime;
	    asn1t_cert.tbsCertificate.validity.notAfter.u.generalTime =
		date2cpy( enc_buffer, NotAfter, T_Time_generalTime );
	}
    }
    ASN1T_Extensions_add_aKI_and_iAN( pdecctxt, 
	asn1t_cert.tbsCertificate.extensions, asn1t_ca );
    ASN1T_Extensions_add_subjectKeyIdentifier( server->GetCSP(), pdecctxt, 
	asn1t_cert.tbsCertificate.extensions, 
	asn1t_cert.tbsCertificate.subjectPublicKeyInfo.subjectPublicKey,true);

    // Sign certificate
    ASN1C_TBSCertificate asn1c_tbs_cert (enc_buffer, asn1t_cert.tbsCertificate);
    asn1t_cert.signature = *ASN1EncodeBuffer_EncodeAndSign( 
	server->GetCSP(), AT_SIGNATURE, enc_buffer, asn1c_tbs_cert);
    if( path.find_def( "invalid_sig", false ) )
	*(unsigned char*)asn1t_cert.signature.data ^= 0xff;
    asn1t_cert.signatureAlgorithm = ASN1T_AlgorithmIdentifier_set (pdecctxt, 
	server->GetCSP(), AT_SIGNATURE );

    // Encode certificate
    ASN1C_Certificate asn1c_cert (enc_buffer, asn1t_cert);
    
    //Export ToBeSigned
    std::string output_tbsCert;
    if( path.find( "tbs", output_tbsCert ) )
    {
	int len_encoded_tbsCert;
	if ((len_encoded_tbsCert = asn1c_tbs_cert.EncodeTo(enc_buffer)) <= 0)
	    throw CA_ASN1_EXCEPTION(enc_buffer.getCtxtPtr());

	CACMPT_BLOB tbsCert_blob(enc_buffer.GetMsgPtr (), len_encoded_tbsCert);
	tbsCert_blob.writeToFile( output_tbsCert.c_str() );
    }

    int len;
    if ((len = asn1c_cert.EncodeTo (enc_buffer)) <= 0)
	throw CA_ASN1_EXCEPTION(enc_buffer.getCtxtPtr());

    // write certificate
    std::string output_cer = path.find_def( "cert", pkicer_def );
    CACMPT_BLOB cer_blob(enc_buffer.GetMsgPtr (), len);
    cer_blob.writeToFile( output_cer.c_str() );
    Ini pse_path;
    PKIXCMP_Base::InstallCertificateToStore( cer_blob, clnt->GetCSP(), new_keyspec );
    if( path.find( "pse_path", pse_path ) )
	pse_path.insert("cert", cer_blob);

    // install cert to container
    std::string install_cert_to_container = path.find_def( "certtocont", "false");
    if (install_cert_to_container.find("true") != 0 ||
	install_cert_to_container.find("TRUE") != 0)
    {
	PKIXCMP_Base::InstallCertificateToContainer(cer_blob, clnt->GetCSP(), new_keyspec);
    }
}

static void test_SetAsRoot( const Ini& path )
{
    Ini dest_ini( path.find_def( "pse_path", pse_path_default ) );
    std::string cer = path.find_def( "cert", pkicer_def );
    CACMPT_BLOB cer_blob;
    cer_blob.readFromFile( cer.c_str() );
    dest_ini.insert( "cert", cer_blob );
    CACMPT_Period period = path.find_def( "crl_update", CACMPT_Period::OneMonth );
    dest_ini.insert( "crl_update", period );
    std::string cdp = path.find_def( "cdp", "" );
    if(	!cdp.empty() )
	dest_ini.insert( "cdp", cdp.c_str() );
    std::string caname = path.find_string( "caname" );
    dest_ini.insert( "caname", caname.c_str() );
}

static void test_QuickIntermediate( const Ini& path )
{
    test_QuickCert( path );
    test_SetAsRoot( path );

    Ini pse_path( path.find_def( "pse_path", rse_path_default ) );
    CACMPT_BLOB cert;
    PKIXCMP_Server *server = server_cache.Create_Read( pse_path );
    CrlInfo info;
    
    CACMPT_Date null_date;
    info.ThisUpdate = path.find_def( "ThisUpdate", null_date );
    info.NextUpdate = path.find_def( "NextUpdate", null_date );
    if( info.ThisUpdate != null_date )
	info.UseUpdate = true;
    path.find_string( "CrlSignatureAlgorithm", 
	info.CrlSignatureAlgorithm,
	sizeof( info.CrlSignatureAlgorithm ) );
    test_ProcessExtensions (path, "crl_extensions", info.Extensions);
    CACMPT_BLOB out_crl;
    server->GenerateCRL(out_crl, &info);
    if( path.find_def( "invalid_crlsig", false ) )
    {
	CACMPT_ASN1BERDecodeBuffer dec_buffer( out_crl );
	ASN1T_CertificateList asn1t_list;
	ASN1C_CertificateList asn1c_list( dec_buffer, asn1t_list );
	if( asn1c_list.Decode() < 0 )
	    throw CA_ASN1_EXCEPTION(dec_buffer.getCtxtPtr());
	*(unsigned char*)asn1t_list.signature.data ^= 0xff;
	ASN1BEREncodeBuffer enc_buffer;
	ASN1C_CertificateList asn1ce_list (enc_buffer, asn1t_list);
	int len;
	if ((len = asn1ce_list.EncodeTo (enc_buffer)) <= 0)
	    throw CA_ASN1_EXCEPTION(enc_buffer.getCtxtPtr());
	out_crl = CACMPT_BLOB (enc_buffer.GetMsgPtr (), len);
    }
    std::string output = path.find_def( "crl", cacrl_def );
    out_crl.writeToFile( output );
}

static int call_section( const Ini &path ) throw()
{
    int ret = 0;
    try {
	int action = path.find_enum(  "action", str_actions, 
	    sizeof( actions ) / sizeof( *actions ) );
	std::cout << "Start [" << path.get_path() << "]  " 
	    << str_actions[action] << std::endl;
	bool error = path.find_def( "exception", false );
	try {
	    actions[action]( path );
	    if( error )
		throw CA_EXCEPTION( CANoNeedException, "No need exception" );
	    std::cout << "Ok [" << path.get_path() << "]  " 
		<< str_actions[action] << std::endl;
	}
	catch( CANoNeedException ex )
	{
	    throw;
	}
	catch( CAException ex )
	{
	    if( !error )
		throw;
	    std::cout << "Ok [" << path.get_path() << "]  " 
		<< str_actions[action] << " Error:"
		<< ex.what() << std::endl;
	}
    }
    catch( TestSequenceException )
    {
	ret = 3;
    }
    catch( std::exception &ex )
    {
	std::cout << "[" << path.get_path() << "] Exception:" << ex.what() 
	    << std::endl;
	ret = 1;
    }
    catch( ... )
    {
    	std::cout << "[" << path.get_path() << "] Unknown exception." << std::endl;
	ret = 2;
    }
    return ret;
}

static const char local_path[] = "\\pkicmp";

void test_Sequence( const Ini &path )
{
    multi_sz tests = path.find_multu_sz( "test" );
    multi_sz::const_iterator ie = tests.end();
    multi_sz::const_iterator i = tests.begin();
    int ret = 0;
    for( ; i != ie; i++ )
    {
	ret = call_section( Ini( path, *i ) );
	if( ret ) 
	    throw CA_EXCEPTION( TestSequenceException, "Sequence exception." );
    }
}

int main( int argc, char *argv[] )
{
    static const char start_path[] = "tests";
    int ret = 0;
#if defined( MSLEAKS )
    _CrtSetDbgFlag ( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif // defined( MSLEAKS )
    setlocale(LC_ALL,"");
#ifndef UNIX
    {
	UINT CodePage = GetConsoleOutputCP();    
	BOOL RusCodePage = (CodePage == 866 || CodePage == 1251);
	if (RusCodePage)
	    setlocale(LC_ALL, "rus");
    }
#endif
    if (support_load_library()) {
	std::cout << "Failed to initialize!" << std::endl;
	return 2;
    }
    Ini path( local_path );
    if( argc > 1 )
    {
	for( int i = 1; i < argc; i++ )
	{
	    ret = call_section( Ini( path, argv[i] ) );
	    if( ret ) break;
	}
    }
    else
    {
	ret = call_section( Ini( path, start_path ) );
    }
    return ret;
}


void fill_message( const Ini &path, PKIXCMP_Message &msg )
{
    // ���������� ���������
    path.find( "RecipientGeneralName", msg.RecipientGeneralName,
	( sizeof( msg.RecipientGeneralName ) - 1 ) / 
	sizeof( *msg.RecipientGeneralName ) );
    path.find( "SenderGeneralName", msg.SenderGeneralName,
	( sizeof( msg.SenderGeneralName ) - 1 ) / 
	sizeof( *msg.SenderGeneralName ) );
    path.find( "sender_nonce", msg.m_sender_nonce );
    path.find( "transactionID", msg.m_transactionID );
    path.find( "sender_kid", msg.m_sender_kid );
    get_extra_certs( path, "addcert", msg.extra_certs );
    GeneralAudit audit;
    audit.session = path.find_def( "session", 0U );
    audit.event_counter = path.find_def( "session", 0U );
    audit.success = path.find_def( "success", true );
    std::string msgtype;
    if( path.find( "msgtype", msgtype ) )
	audit.type = GeneralEventType_fromString( msgtype.c_str() );
    msg.tav_list.set_audit( audit );
    ini_cprefix pred( "gen" );
    Ini::const_iterator ie = path.param_end();
    Ini::const_iterator i = find_if<ini_cprefix>( path.param_begin(), ie, pred );
    for( ; i != ie; i = find_if<ini_cprefix>( ++i, ie, pred ) )
    {
	CACMPT_BLOB blob = path.find_binary( i->param().c_str() );
	msg.tav_list.insert (CACMPT_InfoTypeAndValue( 
	    i->param().c_str()+_tcslen("gen"), blob ));
    }
    get_free_text( path, "free", msg.free_text );
}

static void get_free_text( const Ini &path, const char *key, 
    FreeText &dest )
{
    multi_sz free_text;
    if( !path.find( key, free_text ) )
	return;
    multi_sz::const_iterator ie = free_text.end();
    multi_sz::const_iterator i = free_text.begin();
    for( ; i != ie; ++i )
    {
	std::string s = *i;
	size_t len = s.find( ':' );
	dest.insert( FreeTextItem( towstring( s.substr( len + 1 ) ), 
	    Encoding( s.substr( 0, len ).c_str() ) ) );
    }
}

const CertificateStore *get_extra_store( const Ini &path, 
    size_t &add_base_quant, wmulti_sz &addstore )
{
    if( !path.find( "addstore", addstore ) )
	return 0;
    wmulti_sz::const_iterator ie = addstore.end();
    wmulti_sz::const_iterator i = addstore.begin();
    std::auto_ptr<CertificateStore> add_base( new CertificateStore[addstore.size()] );
    for( ; i != ie; add_base_quant++, ++i )
    {
	    add_base.get()[add_base_quant].Set(
		*i,
		wcsncmp (*i, L"user.", 5)==0);
    }
    return add_base.release();
}

#if POLICY
void get_policies( const Ini &path, const char *key, policy_oid_set &set )
{
    ini_cprefix pred( key );
    Ini::const_iterator ie = path.param_end();
    Ini::const_iterator i = find_if<ini_cprefix>( path.param_begin(), ie, pred );
    for( ; i != ie; i = find_if<ini_cprefix>( ++i, ie, pred ) )
    {
	ASN1OBJID oid;
	std::string str_oid = ctx.param()+_tcslen(key);
	if( str_oid == "any" )
	    set.insert( PolicyOid( oid ) );
	else
	{
	    if( str2oid( str_oid.c_str(), &oid ) )
		throw CA_EXCEPTION( CAException, "Invalid policy oid." );
	    set.insert( PolicyOid( oid ) );
	}
    }
}

bool operator ==( const policy_set &left, const policy_oid_set &right )
{
    if( left.size() != right.size() )
	return false;
    policy_set::const_iterator lci = left.begin();
    policy_oid_set::const_iterator rci = right.begin();
    policy_set::const_iterator lcie = left.end();
    for( ; lci != lcie; ++lci, rci++ )
	if( lci->get_oid() != *rci )
	    return false;
    return true;
}

#endif

static int asn1c_unknownExtension_Decode( ASN1CTXT* pctxt, const char *encoded, 
    ASN1TDynOctStr &asn1t_string )
{
    static const std::string hUnknown( "hex" );
    std::string enc( strip_white_space( std::string( encoded ) ) );
    if( enc.empty() )
	return 1;
    if( get_sub_xml( enc ) != hUnknown )
	return 1;
    std::string hex = get_not_xml( enc );
    CACMPT_BLOB b;
    b.readFromHexString( hex.c_str() );
    void * buf = ASN1MALLOC (pctxt, b.cbData );
    memcpy (buf, b.pbData, b.cbData);
    asn1t_string.numocts = b.cbData;
    asn1t_string.data = (ASN1OCTET*) buf;
    if( get_sub_xml_lend( enc ) != hUnknown )
	return 1;
    return 0;
}

void test_ProcessExtensions (const Ini &path, const TCHAR *key, CACMPT_Extensions& Extensions)
{
    multi_sz extensions;
    if( !path.find( key, extensions ) )
	return;
    multi_sz::const_iterator ie = extensions.end();
    multi_sz::const_iterator i = extensions.begin();
    for( ; i != ie; ++i )
    {
	static const std::string crit = "crit.";
	std::string s = *i;
	size_t len = s.find( ':' );
	std::string value = *i + len + 1;
	bool iscrit = s.substr( 0, crit.length() ) == crit;
	std::string oid = iscrit ? s.substr( crit.length(), len - crit.length() )
	    : s.substr( 0, len );

	if( value == "erase" ) {
	    Extensions.Delete ( oid.c_str() );
	    continue;
	}

	ASN1TDynOctStr asn1t_string;
	// fix warning gcc-4.4.2 / Fedora12
	// �asn1t_string.ASN1TDynOctStr::<anonymous>.ASN1DynOctStr::data�
	// may be used uninitialized in this function
	asn1t_string.data = 0;

	ASN1BEREncodeBuffer enc_buffer;
	ASN1CTXT* pctxt = enc_buffer.getCtxtPtr();
	if( !asn1c_unknownExtension_Decode(pctxt,value.c_str(),asn1t_string ))
	{
	    ASN1OBJID id;
	    if( str2oid( oid.c_str(), &id ) )
		throw CA_EXCEPTION(Asn1DecodeException, "Invalid oid" );
	    CACMPT_ExtValue ext( (struct _ASN1OBJID&)id, 
		asn1t_string.data, asn1t_string.numocts );
	    Extensions.Insert( CACMPT_Extension( ext, iscrit ) );
	}
	else {
	    Extensions.Insert (CACMPT_Extension (oid, value, iscrit ) );
	}
    }
}

void get_extra_certs( const Ini &path, const char *key,
    encoded_certificate_list &list )
{
    multi_sz extra_certs;
    if( !path.find( key, extra_certs ) )
	return;
    multi_sz::const_iterator ie = extra_certs.end();
    multi_sz::const_iterator i = extra_certs.begin();
    for( ; i != ie; ++i )
    {
	CACMPT_BLOB cert;
	cert.readFromFile( *i );
	list.push_back( cert );
    }
}

void get_extra_crl( const Ini &path, encoded_crl_list &list )
{
    multi_sz extra_crl;
    if( !path.find( "addcrl", extra_crl ) )
	return;
    multi_sz::const_iterator ie = extra_crl.end();
    multi_sz::const_iterator i = extra_crl.begin();
    for( ; i != ie; ++i )
    {
	CACMPT_BLOB crl;
	crl.readFromFile( *i );
	list.push_back( crl );
    }
}

static WndProv &get_client_wnd_prov( const Ini &path )
{
    WndProvType wnd_prov_type = get_WndProvType( path );
    if( wnd_prov_type == WND_PROV_DEFAULT )
	wnd_prov_type = WND_PROV_SILENT;
    if( wnd_prov_type == WND_PROV_CONSOLE )
	return con_wnd_prov;
    if( wnd_prov_type == WND_PROV_SILENT )
	return silent_wnd_prov;
    if( wnd_prov_type == WND_PROV_NO_PIN )
	return no_pin_wnd_prov;
#ifdef _WIN32
    if( wnd_prov_type == WND_PROV_W32 )
	return w32_wnd_prov;
#endif /* _WIN32 */
    ini_throw::throw_bad( "WndProvType bad" );
    return con_wnd_prov;
}

static DWORD get_ProvType( const Ini &path )
{
    return SetProvType[path.find_enum( "ProvType", str_ProvType, 
	sizeof( str_ProvType) / sizeof( *str_ProvType ) )];
}

static WndProvType get_WndProvType( const Ini &path )
{
    return (WndProvType)
	path.find_def(  "WndProvType", str_wnd_prov, 
	sizeof( str_wnd_prov ) / sizeof( *str_wnd_prov ), 0 );
}

static unsigned get_RevocationCheckFlags( const Ini &path )
{
    std::string str;
    if( !path.find( "RevocationCheckFlags", str ) )
	return CertChainBuildFlags::REVOCATION_CHECK_CACHE_ONLY 
	    | CertChainBuildFlags::CACHE_ONLY_URL_RETRIEVAL
	    | CertChainBuildFlags::REVOCATION_CHECK_CHAIN;
    return SmallBitStringFromString( u_RevocationCheckFlags, str_RevocationCheckFlags, 
	sizeof( u_RevocationCheckFlags ) / sizeof( *u_RevocationCheckFlags ),
	str.c_str() );
}

static DWORD get_WinRevocationCheckFlags( const Ini &path )
{
    std::string str;
    if( !path.find( "RevocationCheckFlags", str ) )
	return CERT_CHAIN_REVOCATION_CHECK_CACHE_ONLY 
	    | CERT_CHAIN_CACHE_ONLY_URL_RETRIEVAL
	    | CERT_CHAIN_REVOCATION_CHECK_CHAIN;
    return SmallBitStringFromString( u_WinRevocationCheckFlags, str_RevocationCheckFlags, 
	sizeof( u_WinRevocationCheckFlags ) / sizeof( *u_WinRevocationCheckFlags ),
	str.c_str() );
}

#if !defined UNIX
static const TCHAR *str_CertVerifyRevocationFlags[] =
{
    "CERT_VERIFY_REV_CHAIN_FLAG",
    "CERT_VERIFY_CACHE_ONLY_BASED_REVOCATION",
    "CERT_VERIFY_REV_ACCUMULATIVE_TIMEOUT_FLAG"
};

static const unsigned u_CertVerifyRevocationFlags[] =
{
    CERT_VERIFY_REV_CHAIN_FLAG,
    CERT_VERIFY_CACHE_ONLY_BASED_REVOCATION,
    CERT_VERIFY_REV_ACCUMULATIVE_TIMEOUT_FLAG
};

static DWORD get_CertVerifyRevocationFlags( const Ini &path, std::string valueName )
{
    std::string str;
    if( !path.find( valueName.c_str(), str ) )
	return 0; 
    return SmallBitStringFromString( u_CertVerifyRevocationFlags, str_CertVerifyRevocationFlags, 
	sizeof( u_CertVerifyRevocationFlags ) / sizeof( *u_CertVerifyRevocationFlags ),
	str.c_str() );
}

static const TCHAR *str_Errorcodes[] =
{
    "CRYPT_E_NO_REVOCATION_CHECK",
    "CRYPT_E_REVOKED",
};

static const unsigned u_Errorcodes[] =
{
    CRYPT_E_NO_REVOCATION_CHECK,
    CRYPT_E_REVOKED,
};

static DWORD parseErrorcode( const std::string& str)
{
    if(isalpha(str[0])) { // ���� ������ ������ � ���������� ����
	const TCHAR **errorcodeStr = std::find(str_Errorcodes,
	    str_Errorcodes + sizeof(str_Errorcodes)/sizeof(str_Errorcodes[0]),
	    str);
	if( errorcodeStr == str_Errorcodes + 
		sizeof(str_Errorcodes)/sizeof(str_Errorcodes[0]) ) {
	    throw CA_EXCEPTION(CAException, "Unknown error name");
	}
	return u_Errorcodes[errorcodeStr - str_Errorcodes];
    } else if ( str[0] == '0' && str[1] == 'x' ) { 
	// ��� ������ � ����������������� ����
	std::istringstream is(str.substr(2));
	DWORD errorcode = 0;
	is >> std::hex >> errorcode;
	if(is.fail()) {
	    throw CA_EXCEPTION(CAException, "Cannot parse errorcode");
	}
	return errorcode;
    } else { 
	// ��� ������ � ���������� ����
	std::istringstream is(str);
	DWORD errorcode = 0;
	is >> std::dec >> errorcode;
	if(is.fail()) {
	    throw CA_EXCEPTION(CAException, "Cannot parse errorcode");
	}
	return errorcode;
    }
}
#endif	// !UNIX

/*
 * Copyright(C) 2003 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/*!
 * \file $RCSfile: CA_CMP_Util.h,v $
 * \version $Revision: 1.87 $
 * \date $Date: 2005/09/07 16:25:13 $
 * \author $Author: dedal $
 *
 * \brief CMP Utils
 */


#ifndef __CA_CMP_UTIL_H
#define __CA_CMP_UTIL_H
#undef min
#undef max

#include "ASN1Util.h"
#include "ASN1Traits.h"
#include "EncodeAnd.h"
#include "PKIXCMP_Base.h"
#include "CA_CMP_RevAnnContent.h"
#include "CA_CMP_Certificate.h"
#include "CA_CMP_Requests.h"
#include "CA_CMP_ErrorMsg.h"
#include "CA_CMP_CRL.h"

// CPCSP
#ifdef WIN32
#include <windows.h>
#include <WinCrypt.h>
#else
//#include "CSP_WinDef.h"
#include "CSP_WinCrypt.h"
#endif
#include "WinCryptEx.h"

int str2dn( const char *str, ASN1T_Name &name, ASN1BEREncodeBuffer &enc_buffer );
int str2dn( const wchar_t *str, ASN1T_Name &name, ASN1BEREncodeBuffer &enc_buffer );

int str2general( const wchar_t *value, 
    ASN1T_GeneralName &name, ASN1BEREncodeBuffer &enc_buffer );

void GeneralizedNameParse( const ASN1T_GeneralName &name, 
    CACMPT_PARSED_RDN &parsed_rdn );

typedef wchar_t CACMPT_RDN [ 8192 ];

inline void GeneralizedNameParse( const ASN1T_GeneralName &name, 
    CACMPT_PARSED_RDN &parsed_rdn, CACMPT_RDN &rdn )
{
    GeneralizedNameParse( name, parsed_rdn );
    wcscpy (rdn, parsed_rdn.tostring (CERT_X500_NAME_STR).c_str());
}

inline void GeneralizedNameParse( const ASN1T_GeneralName &name, CACMPT_RDN &rdn )
{
    CACMPT_PARSED_RDN parsed_rdn;
    GeneralizedNameParse( name, parsed_rdn, rdn );
}

ASN1TDynOctStr int2octs( int nVal, ASN1CTXT* pctxt );

ASN1GeneralizedTime
ASN1GeneralizedTime_add (ASN1BEREncodeBuffer &enc_buffer, ASN1GeneralizedTime base, 
    const CACMPT_Period &date);
ASN1UTCTime
ASN1UTCTime_add (ASN1BEREncodeBuffer &enc_buffer, ASN1UTCTime base, 
    const CACMPT_Period &date);

int ASN1CMPMessage_Verify( ASN1T_PKIMessage &message,
    const CertificateStore *add_store, int add_store_len, 
    encoded_certificate_list &path, /* [out] - message signer's chain */
    unsigned *chain_status = 0
);

void ASN1CMPMessage_Parse( ASN1T_PKIMessage &asn1_message,
    PKIXCMP_Message &message );
void ASN1CMPMessage_Encode( const PKIXCMP_Message &message,
    ASN1T_PKIMessage &asn1_message,
    ASN1BEREncodeBuffer &enc_buffer,
    ASN1BERDecodeBuffer &dec_buffer );

CACMPT_BLOB
ASN1CMPMessage_Sign( ASN1T_PKIMessage &asn1t_message,
    ASN1BEREncodeBuffer& enc_buffer,
    HCRYPTPROV hProv, 
    DWORD dwKeySpec,
    const encoded_certificate_list &extra_certs
);
CACMPT_BLOB
ASN1CMPMessage_EncodeEx( ASN1T_PKIMessage &asn1t_message,
    ASN1BEREncodeBuffer& enc_buffer,
    HCRYPTPROV hProv, 
    DWORD dwKeySpec,
    const encoded_certificate_list &extra_certs
);
ASN1T_Name&
ASN1T_Name_set (
    CACMPT_ASN1BERDecodeBuffer& dec_buffer,
    const CACMPT_PARSED_RDN& RDN
    );

ASN1T_Name&
ASN1T_Name_set_NULL (
    ASN1BEREncodeBuffer& enc_buffer
    );

void ASN1T_GeneralNames_add (ASN1CTXT* pctxt, ASN1T_GeneralNames& names, ASN1T_GeneralName& asn1t_gname);
void ASN1T_Extensions_add (ASN1CTXT* pctxt, ASN1T_Extensions& extensions, ASN1OBJID& oid, void * decoded, bool critical = false);
void ASN1T_Extensions_replace( ASN1CTXT* pctxt, ASN1T_Extensions& extensions, ASN1OBJID& oid, void * decoded, bool critical = false);
void ASN1T_Attributes_add (ASN1CTXT* pctxt, ASN1TSeqOfList& attributes, ASN1OBJID& oid, void * decoded);

void
ASN1T_Extensions_add_privateKeyUsagePeriod (
	ASN1BEREncodeBuffer &enc_buffer, 
	ASN1T_Extensions& extensions, 
	ASN1UTCTime base,
	int daysNotBefore,
	int daysNotAfter);

void
ASN1T_Extensions_add_basicConstraints (
	HCRYPTPROV hProv, 
	ASN1CTXT* pctxt,
	ASN1T_Extensions& extensions, 
	bool cA = true);
void
ASN1T_Extensions_add_subjectKeyIdentifier (
	HCRYPTPROV hProv, 
	ASN1CTXT* pctxt,
	ASN1T_Extensions& extensions, 
	ASN1TDynBitStr& subjectPublicKey,
	bool fReplace = false);
void 
ASN1T_Extensions_add_aKI_and_iAN (
	ASN1CTXT* pctxt,
	ASN1T_Extensions& extensions, 
	const ASN1T_Certificate& asn1t_ca);

void
ASN1T_Extensions_add_AIA (
	ASN1CTXT* pctxt,
	ASN1T_Extensions& extensions, 
	const ASN1T_Certificate& asn1t_ca);

void
ASN1T_Extensions_add (
	ASN1CTXT* pctxt,
	ASN1T_Extensions& extensions, 
	const CACMPT_Extension& obj);

void
ASN1T_Extensions_replace (
	ASN1CTXT* pctxt,
	ASN1T_Extensions& extensions, 
	const CACMPT_Extension& obj);

void
ASN1T_Extensions_set (
	ASN1CTXT* pdecctxt,
	ASN1T_Extensions& asn1t_extensions, 
	const CACMPT_Extensions &Extensions);

void
ASN1T_Extensions_get (
    const ASN1T_Extensions& asn1t_extensions, 
    CACMPT_Extensions &Extensions);

#if 0
const void* ASN1T_Extensions_find(
    const ASN1T_Extensions& extensions, const ASN1TObjId &extnID, 
    bool &critical );
#endif    

void SubjectPublicKeyInfo_Parse( CACMPT_PublicKeyInfo &dest,
    const ASN1T_AlgorithmIdentifier &src );

void tbsCertificateParse( ASN1CTXT *pctxt, 
    ASN1T_TBSCertificate &cert, 
    CertificateInfo *dest );

void Certificate_Parse( ASN1CTXT *pctxt, ASN1T_Certificate *cert,
    const CACMPT_BLOB &c_msg, CertificateInfo *dest );

void
ASN1T_BigInt_gen (HCRYPTPROV hProv, ASN1OCTET* buf, int len);

void
CACMP_GenContainerName (HCRYPTPROV hProv, char szContainer[256]);

class CertificateTemplate
{
public:
    CertificateTemplate();
    ~CertificateTemplate();

    ASN1BEREncodeBuffer enc_buffer;
    CACMPT_ASN1BERDecodeBuffer dec_buffer;
    ASN1T_PKIMessage asn1t_request; //?
    ASN1T_Certificate asn1t_cert;
    ASN1T_Certificate asn1t_ca;
};

// missing id-it-xxx OID's in asn1data
// These OID's are used in GenM/GenRep

#define id_it_ResumeCertificate id_CryptoPro_it_ResumeCertificate
#define id_it_GetMessage id_CryptoPro_it_GetMessage
#define id_it_GetMessages id_CryptoPro_it_GetMessages
#define id_it_ChangeNameReq id_CryptoPro_it_ChangeNameReq
#define id_it_ResumeCertificateReply id_CryptoPro_it_ResumeCertificateReply

void out_hex( 
    const void *info,
    size_t size );

ASN1T_Name* get_server_name( const CACMPT_BLOB &cert,
    ASN1BERDecodeBuffer &dec_buffer );

void add_extra_certs( ASN1BERDecodeBuffer &dec_buffer,
    ASN1T_PKIMessage &asn1t_message, 
    const encoded_certificate_list &extra_certs );

void copy_str_array( ASN1T_PKIFreeText &dest, const std::wstring *src, 
    size_t len, ASN1CTXT* pctxt );

void CertReq_Parse( ASN1CTXT *pctxt,
    ASN1T_CertificationRequest *req,
    RequestInfo *dest );

void CertReq_Parse( ASN1CTXT *pctxt,
    ASN1T_CertReqMessages *req,
    RequestInfo *dest );

void CertReq_Parse( ASN1CTXT *pctxt,
    ASN1T_RevReqContent& req,
    RequestInfo *dest );

void CertReq_Parse( ASN1CTXT *pctxt,
    ASN1T_RevDetails& asn1t_rev_details,
    RequestInfo *dest );

void FreeText_Encode( ASN1CTXT *pctxt, ASN1T_PKIFreeText &dest,
    const FreeText &src );

void FreeText_Parse( ASN1CTXT *pctxt, FreeText &dest,
    const ASN1T_PKIFreeText &src );

HCRYPTPROV get_pin_load( WndProv &wnd_prov, HCRYPTPROV hProv, const char *name, short n, int num );
HCRYPTPROV set_pin_load( WndProv &wnd_prov, HCRYPTPROV hProv, 
    const char *name, short n, int num );
bool change_pin( WndProv &wnd_prov, HCRYPTPROV hProv, 
    const char *name, short n, int num );
CACMPT_BLOB GetPinInfo( HCRYPTPROV hProv );
void get_reader_list( HCRYPTPROV hProv, ReaderList& );
bool create( WndProv &wnd_prov, const char *provider, DWORD provtype, 
    const char *reader, const char *name, HCRYPTPROV *hProv, 
    short n, int num );
bool create_with_change( WndProv &wnd_prov, 
    const char *provider, DWORD dwProvType, 
    const char *reader, const char *container, 
    short i, short n, HCRYPTPROV *hProv,
    DWORD *hProvInt );
void split_container_name( const char *name, 
    std::string &reader_name, std::string &container_name );
std::string get_container( HCRYPTPROV hProv );
std::string get_provider( HCRYPTPROV hProv );
std::string get_unique( HCRYPTPROV hProv );

class RetrySetProvParam : public Retry
{
public:
    RetrySetProvParam( HCRYPTPROV hProv, DWORD dwParam, const BYTE *pbData,
	DWORD dwFlags ) : m_hProv( hProv ), m_dwParam( dwParam ), 
	m_pbData( pbData ), m_dwFlags( dwFlags ) {}
protected:
    virtual BOOL call( void ) 
    { return CryptSetProvParam( m_hProv, m_dwParam, (BYTE*) m_pbData, m_dwFlags ); }
    HCRYPTPROV m_hProv;
    DWORD m_dwParam;
    const BYTE *m_pbData;
    DWORD m_dwFlags;
};

class RetryGetProvParam : public Retry
{
public:
    RetryGetProvParam( HCRYPTPROV hProv, DWORD dwParam, BYTE *pbData,
	DWORD *pdwDataLen, DWORD dwFlags ) : m_hProv( hProv ), 
	m_dwParam( dwParam ), m_pdwDataLen( pdwDataLen ), m_pbData( pbData ), 
	m_dwFlags( dwFlags ) {}
protected:
    virtual BOOL call( void ) 
    { 
	DWORD dwDataLen = *m_pdwDataLen;
	if( CryptGetProvParam( m_hProv, m_dwParam, m_pbData, &dwDataLen,
	    m_dwFlags ) )
	{
	    *m_pdwDataLen = dwDataLen;
	    return TRUE;
	}
	return FALSE;
    }
    HCRYPTPROV m_hProv;
    DWORD m_dwParam;
    DWORD *m_pdwDataLen;
    BYTE *m_pbData;
    DWORD m_dwFlags;
};

class RetryAcquireContext : public Retry
{
public:
    RetryAcquireContext( HCRYPTPROV *hProv, const char *szContainer, 
	const char *szProvider, DWORD dwProvType, DWORD dwFlags,
	HCRYPTPROV hProvVerify );
    virtual BOOL call( void );
protected:
    HCRYPTPROV *m_hProv;
    std::string m_szContainer;
    const char *m_szProvider;
    DWORD m_dwProvType;
    DWORD m_dwFlags; 
    ReaderList list;
};

ASN1ConstCharPtr DateToASN1GeneralizedTime( ASN1CTXT* pctxt, const CACMPT_Date& date);

// only for t == T_GeneralName_directoryName
void ASN1T_GeneralName_set(
    ASN1CTXT* pctxt,
    ASN1T_GeneralName& dest,
    const CACMPT_BLOB& src); 

// only for t == T_GeneralName_directoryName
void ASN1T_GeneralName_get(
    const ASN1T_GeneralName& src,
    CACMPT_BLOB& dest); 

void ASN1DynBitStr_set(
    ASN1CTXT* pctxt,
    ASN1DynBitStr& dest,
    const CACMPT_BLOB& src);

void ASN1DynBitStr_get(
    const ASN1DynBitStr& src,
    CACMPT_BLOB& dest);

ASN1ConstCharPtr DWORDToASN1BigInteger( ASN1CTXT* pctxt, DWORD val);
DWORD ASN1BigIntegerToDWORD( ASN1ConstCharPtr val);

void ASN1T_SignerInfo_get( CACMPT_SignerInfo& dest, const ASN1T_SignerInfo& src);

std::string get_sub_xml( std::string &src );
std::string get_not_xml( std::string &src );
std::string get_sub_xml_rend( std::string &src );
std::string get_sub_xml_lend( std::string &src );
#if 0
std::string strip_white_space( const std::string &src );
#endif

class ASN1GeneralizedTime_traits
{
public:
    typedef ASN1C_InvalidityDate ASN1_C;

    static void set(
	ASN1CTXT* pctxt,
	ASN1GeneralizedTime& dest,
	const CACMPT_Date& src);
    static void get(
	const ASN1GeneralizedTime& src,
	CACMPT_Date& dest);
    static void copy(
	ASN1CTXT* pctxt,
	const ASN1GeneralizedTime& src,
	ASN1GeneralizedTime& dest);
};

class ASN1T_Extension_traits
{
public:
    typedef ASN1C_Extension ASN1_C;

    static void set(
	ASN1CTXT* pctxt,
	ASN1T_Extension& dest,
	const CACMPT_Extension& src);
    static void get(
	const ASN1T_Extension& src,
	CACMPT_Extension& dest);
    static void copy(
	ASN1CTXT* pctxt,
	const ASN1T_Extension& src,
	ASN1T_Extension& dest);
};

class ASN1T_PKIStatusInfo_traits
{
public:
    typedef ASN1C_PKIStatusInfo ASN1_C;

    static void set(
	ASN1CTXT* pctxt,
	ASN1T_PKIStatusInfo& dest,
	const ErrorMsgInfo& src);
    static void get(
	const ASN1T_PKIStatusInfo& src,
	ErrorMsgInfo& dest);
    static void copy(
	ASN1CTXT* pctxt,
	const ASN1T_PKIStatusInfo& src,
	ASN1T_PKIStatusInfo& dest);
};

class ASN1T_SignerInfo_traits
{
public:
    typedef ASN1C_SignerInfo ASN1_C;

    static void set(
	ASN1CTXT* pctxt,
	ASN1T_SignerInfo& dest,
	const CACMPT_SignerInfo& src);
    static void get(
	const ASN1T_SignerInfo& src,
	CACMPT_SignerInfo& dest);
    static void copy(
	ASN1CTXT* pctxt,
	const ASN1T_SignerInfo& src,
	ASN1T_SignerInfo& dest);
};

class ASN1T_SignerInfos_traits
    : public ASN1TSeqOfList_traits<
	ASN1T_SignerInfo,
	ASN1T_SignerInfo_traits,
	CACMPT_SignerInfo,
	CACMPT_SignerInfos>
{
public:
    typedef ASN1C_SignerInfos ASN1_C;
};

class ASN1T_RevAnnContent_traits
{
public:
    typedef ASN1C_RevAnnContent ASN1_C;

    static void set(
	ASN1CTXT* pctxt,
	ASN1T_RevAnnContent& dest,
	const CACMPT_RevAnnContent& src);
    static void get(
	const ASN1T_RevAnnContent& src,
	CACMPT_RevAnnContent& dest);
    static void copy(
	ASN1CTXT* pctxt,
	const ASN1T_RevAnnContent& src,
	ASN1T_RevAnnContent& dest);
};

class ASN1T_Extensions_traits
    : public ASN1TSeqOfList_traits<
	ASN1T_Extension,
	ASN1T_Extension_traits,
	CACMPT_Extension,
	CACMPT_Extensions>
{
public:
    typedef ASN1C_Extensions ASN1_C;
};

class ASN1T_CRLReason_traits
{
public:
    typedef ASN1C_CRLReason ASN1_C;

    static void set(
	ASN1CTXT* pctxt,
	ASN1T_CRLReason& dest,
	const CrlReason& src);
    static void get(
	const ASN1T_CRLReason& src,
	CrlReason& dest);
    static void copy(
	ASN1CTXT* pctxt,
	const ASN1T_CRLReason& src,
	ASN1T_CRLReason& dest);
};

#endif // __CA_CMP_UTIL_H


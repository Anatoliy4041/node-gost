
#ifndef _KSP_BASE_
#define _KSP_BASE_

#include "CSP_WinCrypt.h"
#include "CSP_Sspi.h"
#include "CSP_SChannel.h"

#ifdef UNIX //for CPSSP_CTX_FLAGS
#include "CpSChl.h"
#endif //UNIX

#include "WinCryptEx.h"
#include "wincspc.h"
#include "reader/dprint.h"

typedef struct _CPSSP_TLS_VERSION_INFO_
{
    BOOL forceServerMaxSupportedProto;
    BOOL forceClientMaxSupportedProto;
    DWORD dwProtoVersionSupported;
} CPSSP_TLS_VERSION_INFO, *PCPSSP_TLS_VERSION_INFO;

typedef struct _CPSSP_CTX_ {
	CPSSP_CTX_FLAGS				Flags;
        HCRYPTKEY				hReadKey;
        HCRYPTKEY				hWriteKey;
        HCRYPTKEY				hReadHMACKey;
        HCRYPTKEY				hWriteHMACKey;
        HCRYPTHASH				hReadHMACHash;
        HCRYPTHASH				hWriteHMACHash;
	BOOL					fReadHMACCummulative;
	BOOL					fWriteHMACCummulative;
        BYTE					read_sequence[8];
        BYTE					write_sequence[8];
        DWORD					dwHMACLen;
        DWORD					shutdown;
	SecPkgContext_Certificates		ContextCertificates;
	HANDLE					hHandle;
	DWORD					cbSubjectName;
	BYTE*					pbSubjectName;
	DWORD					cbIssuerName;
	BYTE*					pbIssuerName;
	SecPkgContext_ClientCertPolicyResult	clientCertPolicyResult;
	HCRYPTPROV				hCryptProv;
	DWORD					dwProvVersion;
	HCRYPTMODULE				hCSP;
        BYTE                                    AlpnProtoLen;
        BYTE                                    AlpnProto[MAX_PROTOCOL_ID_SIZE];
        BYTE                                    NpnProtoLen;
        BYTE                                    NpnProto[MAX_PROTOCOL_ID_SIZE];
	CPSSP_TLS_VERSION_INFO			tlsVersionInfo;
	DWORD					dwTLSVersion;
	BOOL					isHashEnabled[3]; // � TLS 1.2 ���������� ����� ��������� �����.
	BOOL					hasRenegotiated;
	DWORD					dwLastProcessedRecordTLSVersion;
	ALG_ID					aiEffectiveSignAlgid;
	ALG_ID					aiEffectiveExchAlgid;
	ALG_ID					aiEffectiveHashAlgid;
} CPSSP_CTX, *PCPSSP_CTX, *PCPSSP_CREDS;

#define SSL3_RT_MAX_PLAIN_LENGTH		16384
#define SSL3_RT_MAX_COMPRESSED_LENGTH	(1024+SSL3_RT_MAX_PLAIN_LENGTH)
#define SSL3_RT_MAX_ENCRYPTED_LENGTH	(1024+SSL3_RT_MAX_COMPRESSED_LENGTH)

#define SSL3_AD_CLOSE_NOTIFY		 0
#define SSL3_AD_UNEXPECTED_MESSAGE	10	/* fatal */
#define SSL3_AD_BAD_RECORD_MAC		20	/* fatal */
#define SSL3_AD_DECOMPRESSION_FAILURE	30	/* fatal */
#define SSL3_AD_HANDSHAKE_FAILURE	40	/* fatal */
#define SSL3_AD_NO_CERTIFICATE		41
#define SSL3_AD_BAD_CERTIFICATE		42
#define SSL3_AD_UNSUPPORTED_CERTIFICATE	43
#define SSL3_AD_CERTIFICATE_REVOKED	44
#define SSL3_AD_CERTIFICATE_EXPIRED	45
#define SSL3_AD_CERTIFICATE_UNKNOWN	46
#define SSL3_AD_ILLEGAL_PARAMETER	47	/* fatal */

#define SSL_SENT_SHUTDOWN	1
#define SSL_RECEIVED_SHUTDOWN	2
#define SSL_WANT_SHUTDOWN	4

#define TLS1_VERSION			0x0301
#define TLS1_VERSION_MAJOR		0x03
#define TLS1_VERSION_MINOR		0x01

#define TLS1_1_VERSION			0x0302
#define TLS1_1_VERSION_MAJOR		0x03
#define TLS1_1_VERSION_MINOR		0x02

#define TLS1_2_VERSION			0x0303
#define TLS1_2_VERSION_MAJOR		0x03
#define TLS1_2_VERSION_MINOR		0x03

#define SSL3_MT_HELLO_REQUEST			0

#define AddToMessageLog(a,b,c,d,e,f,g)

#endif /* _KSP_BASE_ */

/*
 * Copyright(C) 2003 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/*!
 * \file $RCSfile: CA_CMP_Types.h,v $
 * \version $Revision: 1.59 $
 * \date $Date: 2005/01/24 12:36:43 $
 * \author $Author: cav $
 *
 * \brief CMP Types
 */


#ifndef CA_CMP_TYPES_H
#define CA_CMP_TYPES_H
// @devnote Platform SDK August 2001 + stlport 4.0 incompatibility fix
#ifdef WIN32
#include <windows.h>
#include <wincryptex.h>
#else
#include "CSP_WinCrypt.h"
#endif

#include <string>
#include <list>
#include <vector>
#include <stdio.h>
#include <wchar.h>
#include <time.h>
#include "ASN1Exceptions.h"
#include "ASN1Blob.h"
#include "ASN1Types.h"

/**************************************************************/
/*                                                            */
/*  Internal structure                                        */
/*                                                            */
/**************************************************************/

class CACMPT_ExtValue
{    
  protected:
    std::string m_oid;
    std::string m_xer;
    CACMPT_BLOB m_der;
    void Encode (class ASN1MessageBufferIF& msgBuf, struct _ASN1OBJID&oid, void *encoded, bool encodeDER = true);
    void Decode (struct _ASN1OBJID&oid, const std::string& xer);
  public:
    CACMPT_ExtValue () {}
    ~CACMPT_ExtValue () {}
    CACMPT_ExtValue (struct _ASN1OBJID&oid, const unsigned char * pbDER, unsigned cbDER, void *decoded = NULL);
    CACMPT_ExtValue (struct _ASN1OBJID&oid, void *decoded);
    CACMPT_ExtValue (struct _ASN1OBJID&oid, const std::string& xer);
    CACMPT_ExtValue (const std::string& oid, const std::string& xer);
    CACMPT_ExtValue (const std::string& oid, const std::string& xer, const CACMPT_BLOB& der) 
	: m_oid (oid), m_xer (xer), m_der (der) {}
    CACMPT_ExtValue (const CACMPT_ExtValue& ev) 
	: m_oid (ev.m_oid), m_xer (ev.m_xer), m_der (ev.m_der) {}
    CACMPT_ExtValue& operator=( const CACMPT_ExtValue& ev)
    { m_oid = ev.m_oid; m_xer = ev.m_xer; m_der = ev.m_der; return *this; }
    inline const std::string& get_oid () const { return m_oid; }
    inline const std::string& get_xer () const { return m_xer; }
    inline const CACMPT_BLOB& get_der () const { return m_der; }
};

class CACMPT_ExtPKUP: public CACMPT_ExtValue
{
  public:
    CACMPT_ExtPKUP (int daysNotBefore, int daysNotAfter);
};

class CACMPT_ExtCDP: public CACMPT_ExtValue
{
  public:
    typedef std::vector<std::string> CDPList;  
    CACMPT_ExtCDP (const std::string& cdp);
    CACMPT_ExtCDP (const CDPList & CDPs);
};

class CACMPT_ExtAIA: public CACMPT_ExtValue
{
  public:
    typedef std::vector<std::string> AIAList;
    CACMPT_ExtAIA(const std::string & aia);
    CACMPT_ExtAIA(const AIAList & AIAs);
  protected:
    static std::string AIAXer(const std::string & aia);
};

extern const char* sz_id_ce_invalidityDate;

class CACMPT_ExtInvalidityDate: public CACMPT_ExtValue
{
public:
    CACMPT_ExtInvalidityDate();
    CACMPT_ExtInvalidityDate( 
	const CACMPT_Date& invalidityDate);
    CACMPT_ExtInvalidityDate( const CACMPT_BLOB& der);

    ~CACMPT_ExtInvalidityDate() {}

    void encode();
    void decode();

    //get
    const CACMPT_Date& get_invalidityDate() const;
    //set
    void set_invalidityDate( 
	const CACMPT_Date& invalidityDate);
private:
    CACMPT_Date invalidityDate_;
};

extern const char* sz_id_ce_certificateIssuer;

class CACMPT_ExtCertificateIssuer: public CACMPT_ExtValue
{
public:
    CACMPT_ExtCertificateIssuer();
    CACMPT_ExtCertificateIssuer( 
	const CACMPT_GeneralNames& issuer);
    CACMPT_ExtCertificateIssuer( const CACMPT_BLOB& der);

    ~CACMPT_ExtCertificateIssuer() {}

    void encode();
    void decode();

    //get
    const CACMPT_GeneralNames& get_issuer() const;
    //set
    void set_issuer( 
	const CACMPT_GeneralNames& issuer);
private:
    CACMPT_GeneralNames issuer_;
};

class CACMPT_Extension
{
  protected:
    CACMPT_ExtValue m_value;
    bool            m_critical;
  public:
    CACMPT_Extension (const char *oid, const char *value, const CACMPT_BLOB& der, bool critical = false)
	: m_value (CACMPT_ExtValue (oid, value, der)), m_critical (critical) { }
    CACMPT_Extension (const std::string& oid, const std::string& value, const CACMPT_BLOB& der, bool critical = false)
	: m_value (CACMPT_ExtValue (oid, value, der)), m_critical (critical) { }
    CACMPT_Extension (const std::string& oid, const std::string& value, bool critical = false)
	: m_value (CACMPT_ExtValue (oid, value)), m_critical (critical) { }
    CACMPT_Extension (const CACMPT_ExtValue& value, bool critical = false)
	: m_value (value), m_critical (critical) {}
    CACMPT_Extension ()
	: m_value (CACMPT_ExtValue()), m_critical (false) {}
    CACMPT_Extension (const CACMPT_Extension& ext)
	: m_value (ext.m_value), m_critical (ext.m_critical) {}
    CACMPT_Extension& operator=( const CACMPT_Extension& ext)
    { m_value = ext.m_value; m_critical = ext.m_critical; return *this; }
    inline const std::string& get_oid () const { return m_value.get_oid(); }
    inline const std::string& get_value () const { return m_value.get_xer(); }
    inline const CACMPT_BLOB& get_der () const { return m_value.get_der(); }
    inline bool	get_critical () const { return m_critical; }
};

bool operator==( const CACMPT_Extension& lhs, const CACMPT_Extension& rhs);

class CACMPT_Extensions : public std::list<CACMPT_Extension>
{
public:
    typedef std::list<CACMPT_Extension> ExtList;
    CACMPT_Extensions() : ExtList() {}
    CACMPT_Extensions( const_iterator f, const_iterator l ) : 
	ExtList(f,l) {}
    ~CACMPT_Extensions(){}
    void Delete (const std::string& oid);
    void Insert (CACMPT_Extension ext);
    iterator find( std::string oid )
    {	iterator e = end();
	for( iterator i = begin(); i != e; i++ ) 
	{ if( i->get_oid() == oid ) return i; } 
	return e;
    }
    const_iterator find( std::string oid ) const
    {	const_iterator e = end();
	for( const_iterator i = begin(); i != e; i++ ) 
	{ if( i->get_oid() == oid ) return i; }
	return e;
    }

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);
};

enum PKIStatusEnum {
    PKI_STATUS_GRANTED,
    PKI_STATUS_GRANTEDWITHMODS,
    PKI_STATUS_REJECTION,
    PKI_STATUS_WAITING,
    PKI_STATUS_REVOCATIONWARNING,
    PKI_STATUS_REVOCATIONNOTIFICATION,
    PKI_STATUS_KEYUPDATEWARNING
};

// since we can fail in more than one way!
// More codes may be added in the future if/when required.
struct FailureInfo
{
    FailureInfo();

    // unrecognized or unsupported Algorithm Identifier
    static const unsigned badAlg;
    // integrity check failed (e.g., signature did not verify)
    static const unsigned badMessageCheck;
    // transaction not permitted or supported
    static const unsigned badRequest;
    // messageTime was not sufficiently close to the system time,
    // as defined by local policy
    static const unsigned badTime;
    // no certificate could be found matching the provided criteria
    static const unsigned badCertId;
    // the data submitted has the wrong format
    static const unsigned badDataFormat;
    // the authority indicated in the request is different from the
    // one creating the response token
    static const unsigned wrongAuthority;
    // the requester's data is incorrect (used for notary services)
    static const unsigned incorrectData;
    // when the timestamp is missing but should be there (by policy)
    static const unsigned missingTimeStamp;
    // the proof-of-possession failed
    static const unsigned badPOP;
    // the TSA's time source is not available
    static const unsigned timeNotAvailable;
    // the requested TSA policy is not supported by the TSA.
    static const unsigned unacceptedPolicy;
    // the requested extension is not supported by the TSA.
    static const unsigned unacceptedExtension;
    // the additional information requested could not be understood
    // or is not available
    static const unsigned addInfoNotAvailable;
    // the request cannot be handled due to system failure  }
    static const unsigned systemFailure;

    // ������������������ �����.
    static const unsigned sequence[15];

    unsigned info;

    std::string toString() const;
    void fromString( const char* );
};

CACMPT_BigInteger MakeRandomBigInteger( HCRYPTPROV hProv, size_t size);

CACMPT_BLOB MakeHash(
    HCRYPTPROV hCryptProv,
    const CACMPT_AlgorithmIdentifier& hashAlgorithm,
    const CACMPT_BLOB& data,
    HCRYPTHASH* phHash = 0);

struct CACMPT_SignerInfo
{
    unsigned version;
    CACMPT_BLOB issuer;
    CACMPT_BigInteger serialNumber;
    CACMPT_AlgorithmIdentifier signatureAlgorithm;
    CACMPT_AlgorithmIdentifier digestAlgorithm;
    CACMPT_BLOB signature;
    CACMPT_Attributes signedAttributes;
    CACMPT_Attributes unsignedAttributes;
};

bool operator==( const CACMPT_SignerInfo& lhs, const CACMPT_SignerInfo& rhs);
bool operator!=( const CACMPT_SignerInfo& lhs, const CACMPT_SignerInfo& rhs);

typedef std::list<CACMPT_SignerInfo> CACMPT_SignerInfos;

class CACMPT_RevAnnContent
{
public:
    CACMPT_RevAnnContent() {}
    CACMPT_RevAnnContent(
	const PKIStatusEnum& status,
	const CACMPT_CertId& certId,
	const CACMPT_Date& willBeRevokedAt,
	const CACMPT_Date& badSinceDate);
    CACMPT_RevAnnContent( const CACMPT_RevAnnContent& src);
    //virtual ~CACMPT_RevAnnContent() {}

    CACMPT_RevAnnContent& operator=( const CACMPT_RevAnnContent& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    // get
    const PKIStatusEnum& get_status() const;
    const CACMPT_CertId& get_certId() const;
    const CACMPT_Date& get_willBeRevokedAt() const;
    const CACMPT_Date& get_badSinceDate() const;
    const CACMPT_Extensions* get_crlDetails() const;
    // set
    void set_status(const PKIStatusEnum& status);
    void set_certId(const CACMPT_CertId& certId);
    void set_willBeRevokedAt(const CACMPT_Date& willBeRevokedAt);
    void set_badSinceDate( const CACMPT_Date& badSinceDate);
    void set_crlDetails( const CACMPT_Extensions* crlDetails);
private:
    PKIStatusEnum status_;
    CACMPT_CertId certId_;
    CACMPT_Date willBeRevokedAt_;
    CACMPT_Date badSinceDate_;
    std::auto_ptr<CACMPT_Extensions> crlDetails_;
};

void out_RequestInfo( class RequestInfo *info );
void out_CertificateInfo( class CertificateInfo *info, bool dumpRawData = true );
void out_CrlInfo( class CrlInfo *info );
void out_RevAnnContentInfo( struct RevAnnContentInfo *info );
void out_PKIStatus( PKIStatusEnum status );
void out_ErrorMsgInfo( const class ErrorMsgInfo *info );
void out_FailureInfo( const FailureInfo *info );
void out_tav_list( const class CACMPT_InfoTypeAndValueList &info );
void out_general_info( const class CACMPT_GeneralInfo &info );
void out_PKIXCMP_Message( const class PKIXCMP_Message *info );
void out_FreeText( const class FreeText &info );

#endif /* CA_CMP_TYPES_H */

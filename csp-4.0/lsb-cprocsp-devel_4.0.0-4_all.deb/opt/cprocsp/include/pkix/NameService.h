/*
 * Copyright(C) 2004 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/*!
 * \file $RCSfile$
 * \version $Revision: 126987 $
 * \date $Date:: 2015-09-08 17:51:58 +0400#$
 * \author $Author: pav $
 *
 * \brief ������ ��� ������ �� ����������� ������ ������ ����
 */

#ifndef _NAMESERVICE_H_INCLUDE
#define _NAMESERVICE_H_INCLUDE

#include "ASN1Blob.h"
#include "ASN1Types.h"
#include "CSP_WinCrypt.h"
#include "Date.h"
#include "CA_CMP_Msg.h"
#include "CA_CMP_ErrorMsg.h"

#define sz_id_ct_NSRequestData "1.2.643.2.2.45.1"
#define sz_id_ct_NSResponseData "1.2.643.2.2.45.2"

class NSStatusInfo;
class NSResponseInformation;
class NSErrorNotice;
class NSSubjectNameInfo;
class NSNameInfo;
class NSRequestInformation;
class NSData;

enum NSVersionEnum
{
    NSVersion_v1 = 1
};

enum NSServiceEnum
{
    NSService_registerName = 1,
    NSService_deleteName = 2,
    NSService_checkName = 3,
    NSService_reserveName = 4
};

enum NSStatusEnum
{
    NSStatus_success = 0,
    NSStatus_nameExists = 1,
    NSStatus_incompleteName = 2
};

class NSMessage
{
public:
    NSMessage();
    NSMessage( const CACMPT_BLOB& encodedMessage);
    NSMessage( const std::string& contentType, const CACMPT_BLOB& encodedContent);

    const CACMPT_BLOB& getEncodedContent() const;
    const std::string& getContentType() const;

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);
private:
    NSMessage( const NSMessage&);
    NSMessage& operator=( const NSMessage&);

    CACMPT_BLOB encodedContent_;
    std::string contentType_;
};

// Request

class NSRequestImpl;
class NSRequest
{
public:
    NSRequest();
    NSRequest(
	const NSRequestInformation& requestInformation,
	const NSData& nsData);
    ~NSRequest();

    NSRequest( const NSRequest& src);
    NSRequest& operator=( const NSRequest& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    //get
    const NSRequestInformation& get_requestInformation() const;
    const NSData& get_nsData() const;
    const CACMPT_GeneralName* get_transactionIdentifier() const;
    //set
    void set_requestInformation( 
	const NSRequestInformation& requestInformation);
    void set_nsData( const NSData& nsData);
    void set_transactionIdentifier( 
	const CACMPT_GeneralName* transactionIdentifier);
private:
    NSRequestImpl *pImpl_;
};

class NSRequestInformationImpl;
class NSRequestInformation
{
public:
    NSRequestInformation();
    NSRequestInformation( NSServiceEnum service, const CACMPT_Date& requestTime);
    ~NSRequestInformation();

    NSRequestInformation( const NSRequestInformation& src);
    NSRequestInformation& operator=( const NSRequestInformation& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    //get
    NSVersionEnum get_version() const;
    NSServiceEnum get_service() const;
    const CACMPT_Date& get_requestTime() const;
    const CACMPT_GeneralNames* get_requester() const;
    //set
    void set_version( NSVersionEnum version);
    void set_service( NSServiceEnum service);
    void set_requestTime( const CACMPT_Date& requestTime);
    void set_requester( const CACMPT_GeneralNames* requester);
private:
    NSRequestInformationImpl *pImpl_;
};

class NSDataImpl;
class NSData
{
public:
    NSData();
    NSData( const NSNameInfo& nsName);
    ~NSData();

    NSData( const NSData& src);
    NSData& operator=( const NSData& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    //get
    int get_reservedPeriod() const;
    int get_nameType() const;
    const NSNameInfo& get_nsName() const;
    //set
    void set_reservedPeriod( int reservedPeriod);
    void set_nameType( int nameType);
    void set_nsName( const NSNameInfo& nsName);    
private:
    NSDataImpl *pImpl_;
};

class NSNameInfoImpl;
class NSNameInfo
{
public:
    enum Type
    {
	t_subjectNameInfo = 1
    };
public:
    NSNameInfo();
    ~NSNameInfo();

    NSNameInfo( const NSNameInfo& src);
    NSNameInfo& operator=( const NSNameInfo& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    // get
    Type get_type() const;
    const NSSubjectNameInfo* get_subjectNameInfo() const;
    // set (������������ ������������� ������ ���)
    void set_subjectNameInfo( const NSSubjectNameInfo& subjectNameInfo);
private:
    NSNameInfoImpl* pImpl_;
};

class NSSubjectNameInfoImpl;
class NSSubjectNameInfo
{
public:
    NSSubjectNameInfo();
    ~NSSubjectNameInfo();

    NSSubjectNameInfo( const NSSubjectNameInfo& src);
    NSSubjectNameInfo& operator=( const NSSubjectNameInfo& src);

    CACMPT_BLOB encode();
    void decode( const CACMPT_BLOB& encoded);

    //get
    const CACMPT_Name* get_subject() const;
    const CACMPT_GeneralNames* get_subjectAltName() const;
    //set
    void set_subject( const CACMPT_Name* subject);
    void set_subjectAltName( const CACMPT_GeneralNames* subjectAltName);
private:
    NSSubjectNameInfoImpl *pImpl_;
};

// Response

class NSResponseImpl;
class NSResponse
{
public:
    NSResponse();
    NSResponse( 
	const NSResponseInformation& nsRespInfo,
	const NSErrorNotice& nsErrorNote);
    ~NSResponse();

    NSResponse( const NSResponse& src);
    NSResponse& operator=( const NSResponse& src);

    CACMPT_BLOB encode();
    void decode( const CACMPT_BLOB& encoded);

    //get
    const NSResponseInformation& get_nsRespInfo() const;
    const NSErrorNotice& get_nsErrorNote() const;
    //set
    void set_nsRespInfo( const NSResponseInformation& nsRespInfo);
    void set_nsErrorNote( const NSErrorNotice& nsErrorNote);
private:
    NSResponseImpl *pImpl_;
};

class NSResponseInformationImpl;
class NSResponseInformation
{
public:
    NSResponseInformation();
    NSResponseInformation(
	const CACMPT_Date& responseTime,
	const NSStatusInfo& nsStatus);
    ~NSResponseInformation();

    NSResponseInformation( const NSResponseInformation& src);
    NSResponseInformation& operator=( const NSResponseInformation& src);

    CACMPT_BLOB encode();
    void decode( const CACMPT_BLOB& encoded);

    //get
    NSVersionEnum get_version() const;
    const CACMPT_Date& get_responseTime() const;
    const NSStatusInfo& get_nsStatus() const;
    const CACMPT_Extensions* get_extensions() const;
    //set
    void set_version( NSVersionEnum version);
    void set_responseTime( const CACMPT_Date& responseTime);
    void set_nsStatus( const NSStatusInfo& nsStatus);
    void set_extensions( const CACMPT_Extensions* extensions);
private:
    NSResponseInformationImpl *pImpl_;
};

class NSStatusInfoImpl;
class NSStatusInfo
{
public:
    NSStatusInfo();
    NSStatusInfo( NSStatusEnum status);
    ~NSStatusInfo();

    NSStatusInfo( const NSStatusInfo& src);
    NSStatusInfo& operator=( const NSStatusInfo& src);

    CACMPT_BLOB encode();
    void decode( const CACMPT_BLOB& encoded);

    //get
    NSStatusEnum get_status() const;
    const FreeText* get_statusString() const;
    //set
    void set_status( NSStatusEnum status);
    void set_statusString( const FreeText* statusString);
private:
    NSStatusInfoImpl *pImpl_;
};

class NSErrorNoticeImpl;
class NSErrorNotice
{
public:
    NSErrorNotice();
    NSErrorNotice( const ErrorMsgInfo& transactionStatus);
    ~NSErrorNotice();

    NSErrorNotice( const NSErrorNotice& src);
    NSErrorNotice& operator=( const NSErrorNotice& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    // get
    const ErrorMsgInfo& get_transactionStatus() const;
    const CACMPT_GeneralName* get_transactionIdentifier() const;
    // set
    void set_transactionStatus( const ErrorMsgInfo& transactionStatus);
    void set_transactionIdentifier( const CACMPT_GeneralName* transactionIdentifier);
private:
    NSErrorNoticeImpl* pImpl_;
};

#endif // _NAMESERVICE_H_INCLUDE

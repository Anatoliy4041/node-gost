/*
 * Copyright(C) 2003 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/*!
 * \file $RCSfile$
 * \version $Revision: 126987 $
 * \date $Date:: 2015-09-08 17:51:58 +0400#$
 * \author $Author: pav $
 *
 * \brief ��������������� ������ ��� ���������� ASN1 �������.
 */

#ifndef _ASN1TYPESIMPL_H
#define _ASN1TYPESIMPL_H

#include "ASN1Util.h"
#include "ASN1Traits.h"

// choice

class ChoiceValueTraits
{
public:
    ChoiceValueTraits() {}
    virtual ~ChoiceValueTraits() {}
    virtual bool isType( unsigned type) const=0;
    virtual void deleteValue( void* value) const=0;
//    virtual void* newValue() const=0;
    virtual void* newValue( const void* src) const=0;
    virtual void copyValue( void* dst, const void* src) const=0;
//    virtual bool equal( const void* lhs, const void* rhs) const=0;
};

template<class T, int Type>
class ChoiceValueTraitsT : public ChoiceValueTraits
{
public:
    ChoiceValueTraitsT() {}
    virtual ~ChoiceValueTraitsT() {}
    virtual bool isType( unsigned type) const
    { return Type == type; }
    virtual void deleteValue( void* value) const
    { delete static_cast<T*>(value); }
//    virtual void* newValue() const
//    { return new T(); }
    virtual void* newValue( const void* src) const
    { if(!src) throw CA_EXCEPTION(CAException,"pointer is null");
      return new T(*static_cast<const T*>(src)); }
    virtual void copyValue( void* dst, const void* src) const
    { (*static_cast<T*>(dst)) = (*static_cast<const T*>(src)); }
//    virtual bool equal( const void* lhs, const void* rhs) const
//    { return (*static_cast<const T*>(lhs)) == (*static_cast<const T*>(rhs)); }

    static const ChoiceValueTraitsT<T,Type> instance;
};

class Choice
{
protected:
    unsigned get_type() const { return type_; }
    const void* get_value() const { return value_; };
    void* get_value() { return value_; };
    void set_value( unsigned type, const void* value)
    {
	const ChoiceValueTraits* oldTraits = findTraits( type_ );
	const ChoiceValueTraits* newTraits = findTraits( type );
	if(!newTraits)
	    throw CA_EXCEPTION(CAException,"No traits: type is invalid.");
	oldTraits->deleteValue(value_);
	value_ = newTraits->newValue(value);
//	newTraits->copyValue(value_,value);
	type_ = type;
    }
protected:
    Choice(): type_(0), value_(0) {}
    virtual ~Choice()
    { }
    virtual const ChoiceValueTraits* findTraits( unsigned type ) const=0;
private:

    unsigned type_;
    void* value_;
//    friend bool operator==( const Choice& lhs, const Choice& rhs);
};

//bool operator==( const Choice& lhs, const Choice& rhs);
//bool operator!=( const Choice& lhs, const Choice& rhs);

#define REG_CHOICETRAITS(c,t) \
    template<> const ChoiceValueTraitsT< c, int(t) > \
	ChoiceValueTraitsT< c, int(t) >::instance = ChoiceValueTraitsT< c, int(t) >();

#define CHOICETRAITS_LIST_BEGIN(T) protected:\
    virtual const ChoiceValueTraits* findTraits( unsigned type ) const \
    { \
	switch(static_cast<T>(type)) \
	{
#define CHOICETRAITS_LIST_END \
	default: \
	    return &ChoiceValueTraitsT<void*,0>::instance; \
	} \
    }
#define CHOICETRAITS_LIST_ADD(c,t) \
    case (t): \
	return &ChoiceValueTraitsT<c,t>::instance;

#define CHOICE_CLASS(ImplClassName,ClassName) \
    class ImplClassName : public Choice \
    { \
    public: \
	ImplClassName() {} \
	ImplClassName( const ImplClassName& src) : Choice() \
	{ Choice::set_value( src.get_type(), src.get_value() ); } \
	virtual ~ImplClassName() \
	{ findTraits(Choice::get_type())->deleteValue(Choice::get_value()); } \
	ClassName::Type get_type() const { return static_cast<ClassName::Type>(Choice::get_type()); }

#define CHOICE_CLASS_END };

#define CHOICE_FIELD(Field,FieldType,FieldTag) public: \
    const FieldType* get_##Field() const \
    { \
	if( Choice::get_type() == FieldTag ) \
	    return static_cast<const FieldType*>(Choice::get_value()); \
	else \
	    return 0; \
    } \
    void set_##Field( const FieldType& Field) \
    { Choice::set_value(FieldTag,& Field); }

class CACMPT_DistributionPointImpl
{
public:
    CACMPT_DistributionPointImpl() {}
    CACMPT_DistributionPointImpl( const CACMPT_DistributionPointImpl& src);
public:
    std::auto_ptr<CACMPT_DistributionPointName> distributionPoint_;
    std::auto_ptr<CACMPT_ReasonFlags> reasons_;
    std::auto_ptr<CACMPT_GeneralNames> cRLIssuer_;
};

class CACMPT_ATAVRegister
{
public:
    typedef std::list<CACMPT_ATAVRegister>::iterator iterator;
    typedef std::list<CACMPT_ATAVRegister>::const_iterator const_iterator;
public:
    CACMPT_ATAVRegister(
	const CACMPT_OID& type, 
	const std::wstring& typeName,
	CACMPT_StringType defaultStringType,
	size_t maxSize)
	: type_(type), typeName_(typeName), 
        stringType_(defaultStringType), altStringType_(stDefault),
        maxSize_(maxSize)
    { CACMPT_ATAVRegister::registered_.push_back(*this); }

    CACMPT_ATAVRegister(
	const CACMPT_OID& type, 
	const std::wstring& typeName,
	CACMPT_StringType defaultStringType,
        CACMPT_StringType altStringType,
	size_t maxSize)
	: type_(type), typeName_(typeName), 
        stringType_(defaultStringType), altStringType_(altStringType), 
        maxSize_(maxSize)
    { CACMPT_ATAVRegister::registered_.push_back(*this); }

    CACMPT_ATAVRegister(
	const CACMPT_OID& type, 
	const std::wstring& typeName,
        const std::wstring& secondaryName,
	CACMPT_StringType defaultStringType,
	size_t maxSize)
	: type_(type), typeName_(typeName), secondaryName_(secondaryName),
        stringType_(defaultStringType), maxSize_(maxSize)
    { CACMPT_ATAVRegister::registered_.push_back(*this); }

    CACMPT_ATAVRegister(
	const CACMPT_OID& type, 
	const std::wstring& typeName,
        const std::wstring& secondaryName,
	CACMPT_StringType defaultStringType,
        CACMPT_StringType altStringType,
	size_t maxSize)
	: type_(type), typeName_(typeName), secondaryName_(secondaryName),
        stringType_(defaultStringType), altStringType_(altStringType), maxSize_(maxSize)
    { CACMPT_ATAVRegister::registered_.push_back(*this); }

    CACMPT_StringType typeForString( const std::wstring& str) const;

    static CACMPT_AttributeTypeAndValue makeATAV(
	const std::wstring& type, const std::wstring& value, 
        size_t& pos, CACMPT_StringType stringType, DWORD dwStrType);
    static CACMPT_AttributeTypeAndValue makeATAV(
	const std::wstring& str, size_t& pos,
        CACMPT_StringType stringType, DWORD dwStrType);
    static std::wstring typeToStr( const CACMPT_OID& type);
    static std::wstring valueToStr( const CACMPT_OID& type, const CACMPT_BLOB& value);
    static CACMPT_OID typeFromStr( const std::wstring& str);
    static CACMPT_BLOB valueFromStr(
	const CACMPT_OID& type, const std::wstring& str,
	size_t& pos, CACMPT_StringType stringType, DWORD dwStrType);
    static CACMPT_BLOB valueFromStr(
	const CACMPT_OID& type, const std::wstring& str,
        CACMPT_StringType stringType, DWORD dwStrType);
    static const_iterator find( const CACMPT_OID& type);
    static const_iterator find( const std::wstring& typeName);
private:
    CACMPT_OID type_;
    std::wstring typeName_;
    std::wstring secondaryName_;
    CACMPT_StringType stringType_;
    CACMPT_StringType altStringType_;
    size_t maxSize_;

    static std::list<CACMPT_ATAVRegister> registered_;
    static CACMPT_ATAVRegister default_;
};

#endif // _ASN1TYPESIMPL_H

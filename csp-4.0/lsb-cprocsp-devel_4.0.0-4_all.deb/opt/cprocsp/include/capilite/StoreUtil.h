#ifndef __STORE_UTIL_H
#define __STORE_UTIL_H

#include "ASN1Blob.h"

#include <set>

#ifdef _WIN32
#include <windows.h>
#include <WinCrypt.h>
#else
#include "WinCryptEx.h"
#endif
#include <stdlib.h>

class CertificateStore 
{
protected:
	wchar_t * StoreName;
	bool isSystemStore;	
public:
	CertificateStore()
	{
		StoreName=NULL;
		isSystemStore=true;
	}
	CertificateStore(const wchar_t * aStoreName, const bool aisSystemStore);
	CertificateStore(const CertificateStore & store);
	
	void  Set(const wchar_t * name,const bool aisSystemStore);
	
	void Set(const wchar_t * name); // ������ ��� PKIXCMPTEST� (������ ��� �� user./system. ��� store
	const wchar_t * GetName() const
	{
		return StoreName;
	}
	bool isSystem() const
	{
		return isSystemStore;
	}
	const CertificateStore & operator = (const CertificateStore & s);
	bool operator == (const CertificateStore & s) const;
	bool operator < (const CertificateStore & s) const;
	~CertificateStore()
	{
		if (StoreName)
			free(StoreName);
	}

};

#define Store_My	 CertificateStore (L"My",	false)
#define Store_Request	 CertificateStore (L"Request",	false)
#define Store_CA	 CertificateStore (L"CA",	true)
#define Store_RA	 CertificateStore (L"RA",	true)
#define Store_Root	 CertificateStore (L"Root",	true)
#define Store_Trust	 CertificateStore (L"Trust",	true)


struct store_handle
{
    store_handle(): store_(0), trust_(false) {}
    explicit store_handle(const HANDLE& store, bool dup_handle = true, bool trust = false);
    store_handle( const store_handle& handle);
    ~store_handle();

    bool open(
	const std::wstring & store,
        bool issystem,
	unsigned long flags = CERT_STORE_OPEN_EXISTING_FLAG | CERT_STORE_READONLY_FLAG );
    bool open(
	const CertificateStore & store,
	unsigned long flags = CERT_STORE_OPEN_EXISTING_FLAG | CERT_STORE_READONLY_FLAG )
    {
	    return store_handle::open(store.GetName(),store.isSystem(),flags);
    };

    bool open(
	const std::wstring & store,
	unsigned long flags = CERT_STORE_OPEN_EXISTING_FLAG | CERT_STORE_READONLY_FLAG | CERT_SYSTEM_STORE_CURRENT_USER);
    HANDLE store_;
    bool trust_;
private:
    // ����������� ���������
    store_handle& operator=( const store_handle& handle);
};

template< class f1, class f2, bool v > bool cmp_handles( const store_handle &left,
    const store_handle &right )
{ 
    if( left.trust_ != right.trust_ ) 
	return f1() ( left.trust_, right.trust_);
    if( left.store_ != right.store_ ) 
	return f2() ( left.store_, right.store_ );
    return v;
}

inline bool operator !=( const store_handle &left, const store_handle &right )
{ return cmp_handles< std::not_equal_to<bool>, std::not_equal_to<HANDLE>, false >( left, right ); }
inline bool operator ==( const store_handle &left, const store_handle &right )
{ return cmp_handles< std::equal_to<bool>, std::equal_to<HANDLE>, false >( left, right ); }
inline bool operator <( const store_handle &left, const store_handle &right )
{ return cmp_handles< std::greater<bool>, std::greater<HANDLE>, false >( left, right ); }
inline bool operator <=( const store_handle &left, const store_handle &right )
{ return cmp_handles< std::less_equal<bool>, std::less_equal<HANDLE>, true >( left, right ); }
inline bool operator >( const store_handle &left, const store_handle &right )
{ return cmp_handles< std::less<bool>, std::less<HANDLE>, false >( left, right ); }
inline bool operator >=( const store_handle &left, const store_handle &right )
{ return cmp_handles< std::greater_equal<bool>, std::greater_equal<HANDLE>, true >( left, right ); }

typedef std::set<store_handle> store_set;

template<class Right> class StoreFindParam
{
public:
    const DWORD dwFindType;
    const void *pvFindPara;
    StoreFindParam( DWORD FindType, const void *FindPara ) : 
      dwFindType( FindType ), pvFindPara( FindPara ) {}
    virtual ~StoreFindParam( ) {} 
    virtual bool operator ==( const Right &right ) const 
    { (void)right; return true; } // XXXX dim: samples/ccstest/tsptest.cpp trigger this
    inline bool operator !=( const Right &right ) const
    { return !( *this == right ); }
};

typedef StoreFindParam<CERT_CONTEXT> CertStoreFindParam;
typedef StoreFindParam<CRL_CONTEXT> CrlStoreFindParam;

bool CertStore_Is( const CACMPT_BLOB &cert,
    HANDLE hCertStore);

int CertStore_Find( encoded_certificate_list &dest,
    HANDLE hCertStore,
    const CertStoreFindParam &param,
    bool first );

int CrlStore_Find( encoded_crl_list &dest, 
    HANDLE hCrlStore,
    const CrlStoreFindParam& param);

/* ����� ����������� � Store �� ��� ����� */
PCCERT_CONTEXT 
CertStore_FindExisting (
    const CACMPT_BLOB &cert, 
    HANDLE& hRetCertStore, 
    const wchar_t * store_name = L"My", 
    bool SystemStore = false, bool ReadOnly = true );

class CertFindByIssuerSubStrAndSerial : public CertStoreFindParam
{
public:
    CertFindByIssuerSubStrAndSerial( 
	const wchar_t *Issuer,
	const CACMPT_BLOB &Serial ) : CertStoreFindParam( CERT_FIND_ANY, NULL ), issuer( Issuer ), serial( Serial )
	{}
    virtual bool operator ==( const CERT_CONTEXT &right ) const;
protected:
    const wchar_t *issuer;
    const CACMPT_BLOB &serial;
};

class CertFindBySubjectAndSerial : public CertStoreFindParam
{
public:
    CertFindBySubjectAndSerial( const CACMPT_BLOB &Subject,
	const CACMPT_BLOB &Serial );
    CertFindBySubjectAndSerial( const CACMPT_BLOB &Subject,
	const char *Serial );
    virtual bool operator==( const CERT_CONTEXT &right ) const;
protected:
    CERT_NAME_BLOB name_blob;
    CACMPT_BLOB serial;
//    CACMPT_ASN1BERDecodeBuffer dec_buffer;
};

class CertFindByKeyIdentifier : public CertStoreFindParam
{
public:
    CertFindByKeyIdentifier( const CACMPT_BLOB &KeyIdentifier )
	: CertStoreFindParam( CERT_FIND_KEY_IDENTIFIER, &key_identifier )
    {
	key_identifier.cbData = KeyIdentifier.cbData;
	key_identifier.pbData = KeyIdentifier.pbData;
    }
    virtual bool operator==( const CERT_CONTEXT &right ) const;
protected:
    CRYPT_HASH_BLOB key_identifier;
};

class CertFindByCertificateHash : public CertStoreFindParam
{
public:
    CertFindByCertificateHash( const CACMPT_BLOB &certificateHash )
	: CertStoreFindParam( CERT_FIND_HASH, &cert_hash )
    {
	cert_hash.cbData = certificateHash.cbData;
	cert_hash.pbData = certificateHash.pbData;
    }
    virtual bool operator==( const CERT_CONTEXT &right ) const;
protected:
    CRYPT_HASH_BLOB cert_hash;
};

class CrlFindByIssuerSubStr : public CrlStoreFindParam
{
public:
    CrlFindByIssuerSubStr( const wchar_t *Issuer ) : CrlStoreFindParam( CERT_FIND_ANY, NULL ), issuer( Issuer )
	{}
    virtual bool operator ==( const CRL_CONTEXT &right ) const;
protected:
    const wchar_t *issuer;
};

class CertFindByPublicKey: public CertStoreFindParam
{
public:
    CertFindByPublicKey ( const CACMPT_BLOB &Cert );
    CertFindByPublicKey ( const CACMPT_PublicKeyInfo &PKInfo );
    virtual bool operator ==( const CERT_CONTEXT &right ) const;
protected:
    CACMPT_BLOB pkey;
};

class CrlFindByIssuer : public CrlStoreFindParam
{
public:
    CrlFindByIssuer( const CACMPT_BLOB &Issuer ) : CrlStoreFindParam( CERT_FIND_ANY, NULL ), issuer( Issuer )
	{}
    virtual bool operator==( const CRL_CONTEXT &right ) const;
protected:
    const CACMPT_BLOB &issuer;
};

class CrlFindByIssuerKeyId : public CrlStoreFindParam
{
public:
    CrlFindByIssuerKeyId( const CACMPT_BLOB &Issuer,
	const CACMPT_BLOB &KeyIdentifier)
	: CrlStoreFindParam( CERT_FIND_ANY, NULL ), issuer( Issuer ), keyid( KeyIdentifier )
	{}
    virtual bool operator==( const CRL_CONTEXT &right ) const;
protected:
    const CACMPT_BLOB &issuer;
    const CACMPT_BLOB &keyid;
};

class CertFindByIssuerAndSerial: public CertStoreFindParam
{
public:
    CertFindByIssuerAndSerial( 
	const CACMPT_BLOB &Issuer,
	const CACMPT_BLOB &Serial ) : CertStoreFindParam( CERT_FIND_ANY, NULL ), issuer( Issuer ), serial( Serial )
	{}
    virtual bool operator ==( const CERT_CONTEXT &right ) const;
protected:
    const CACMPT_BLOB &issuer;
    const CACMPT_BLOB &serial;
};

class ThreadSpecificKey
{
    unsigned int m_key;
  public:
    ThreadSpecificKey ();
    ~ThreadSpecificKey ();
    void * GetValue ();
    bool SetValue (const void * ptr, void **old_ptr = NULL);
};

#if defined UNIX || defined CAPILITE_WIN
typedef BOOL (*CRYPT_PIN_CALLBACK) (char *pin, size_t len, void * arg);
extern "C" BOOL CPCryptGetPinFromCallback (char *pin, size_t len);
extern "C" void CPCryptSetPinCallback (CRYPT_PIN_CALLBACK func, void *arg);
extern "C" void CPCryptGetPinCallback (CRYPT_PIN_CALLBACK* func, void **arg);

class CryptSetPinCallback
{
  public:
    CryptSetPinCallback ();
    virtual ~CryptSetPinCallback ();
    virtual std::string get_pin () = 0;
    bool Get (char *pin_buf, size_t pin_len);
  protected:
    CRYPT_PIN_CALLBACK m_old_func;
    void * m_old_arg;
};

/* ������ ����� ������ ���� ������� �� ����� ����� ������� 
 * AcquireCredentialsHandle ��� CryptAcquireCertificatePrivateKey,
 * ����� ��� ����� ������ � ����. �� ������� ��������� ����������
 * �������� ����� ������ - �� ������ ������������ ������ �� �����
 * ������ ����� �� ���� �������. */
class CryptSetPinCallbackFixed: public CryptSetPinCallback
{
  public:
    CryptSetPinCallbackFixed (std::string pin) : m_pin (pin) {}
    virtual ~CryptSetPinCallbackFixed ();
    virtual std::string get_pin ();
  protected:
    std::string m_pin;
};
#endif // _WIN32

void FindInStoreAndAcquirePrivateKey(
     const CACMPT_BLOB& cert,
     const std::wstring& store,
     bool isSystem,
     HCRYPTPROV& hCryptProv,
     DWORD& dwKeySpec);

extern const wchar_t ROOT_STORE[];
extern const wchar_t CA_STORE[];
extern const wchar_t CACHE_STORE[];

#endif // __STORE_UTIL_H

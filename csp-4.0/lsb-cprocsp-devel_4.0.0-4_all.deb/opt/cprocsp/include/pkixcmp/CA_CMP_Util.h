/*
 * Copyright(C) 2003 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/*!
 * \file $RCSfile$
 * \version $Revision: 126987 $
 * \date $Date:: 2015-09-08 17:51:58 +0400#$
 * \author $Author: pav $
 *
 * \brief CMP Utils
 */

#ifndef __CA_CMP_UTIL_H
#define __CA_CMP_UTIL_H
#undef min
#undef max

#include "ASN1Util.h"
#include "ASN1Traits.h"
#include "EncodeAnd.h"
#include "PKIXCMP_Base.h"
#include "CA_CMP_RevAnnContent.h"
#include "CA_CMP_Certificate.h"
#include "CA_CMP_Requests.h"
#include "CA_CMP_ErrorMsg.h"
#include "CA_CMP_CRL.h"

// CPCSP
#ifdef WIN32
#include <windows.h>
#include <WinCrypt.h>
#include "WinCryptEx.h"
#else
#include "CSP_WinCrypt.h"
#endif

int str2dn( const wchar_t *str, ASN1T_Name &name, ASN1BEREncodeBuffer &enc_buffer );

void GeneralizedNameParse(const ASN1T_GeneralName &name, CACMPT_PARSED_RDN &parsed_rdn);

typedef wchar_t CACMPT_RDN [ 8192 ];

inline void GeneralizedNameParse( const ASN1T_GeneralName &name, 
    CACMPT_PARSED_RDN &parsed_rdn, CACMPT_RDN &rdn )
{
    GeneralizedNameParse( name, parsed_rdn );
    wcscpy (rdn, parsed_rdn.tostring (CERT_X500_NAME_STR).c_str());
}

inline void GeneralizedNameParse( const ASN1T_GeneralName &name, CACMPT_RDN &rdn )
{
    CACMPT_PARSED_RDN parsed_rdn;
    GeneralizedNameParse( name, parsed_rdn, rdn );
}

ASN1UTCTime
ASN1UTCTime_add (ASN1BEREncodeBuffer &enc_buffer, ASN1UTCTime base, 
    const CACMPT_Period &date);

int ASN1CMPMessage_Verify( ASN1T_PKIMessage &message,
    const CertificateStore *add_store, int add_store_len);

void ASN1CMPMessage_Parse( ASN1T_PKIMessage &asn1_message,
    PKIXCMP_Message &message );
void ASN1CMPMessage_Encode( const PKIXCMP_Message &message,
    ASN1T_PKIMessage &asn1_message,
    ASN1BEREncodeBuffer &enc_buffer,
    ASN1BERDecodeBuffer &dec_buffer );

/* dim: made static */
CACMPT_BLOB
ASN1CMPMessage_Sign( ASN1T_PKIMessage &asn1t_message,
    ASN1BEREncodeBuffer& enc_buffer,
    HCRYPTPROV hProv, 
    DWORD dwKeySpec,
    const encoded_certificate_list &extra_certs);

ASN1T_Name&
ASN1T_Name_set (
    CACMPT_ASN1BERDecodeBuffer& dec_buffer,
    const CACMPT_PARSED_RDN& RDN);

void ASN1T_Attributes_add (ASN1CTXT* pctxt, ASN1TSeqOfList& attributes, ASN1OBJID& oid, void * decoded);

void
ASN1T_Extensions_add_basicConstraints(ASN1CTXT* pctxt, ASN1T_Extensions& extensions);

void
ASN1T_Extensions_add_subjectKeyIdentifier (
	HCRYPTPROV hProv, 
	ASN1CTXT* pctxt,
	ASN1T_Extensions& extensions, 
	ASN1TDynBitStr& subjectPublicKey,
	bool fReplace = false);
void 
ASN1T_Extensions_add_aKI_and_iAN (
	ASN1CTXT* pctxt,
	ASN1T_Extensions& extensions, 
	const ASN1T_Certificate& asn1t_ca);

void
ASN1T_Extensions_add_AIA (
	ASN1CTXT* pctxt,
	ASN1T_Extensions& extensions, 
	const ASN1T_Certificate& asn1t_ca);

void
ASN1T_Extensions_replace (
	ASN1CTXT* pctxt,
	ASN1T_Extensions& extensions, 
	const CACMPT_Extension& obj);

void
ASN1T_Extensions_set (
	ASN1CTXT* pdecctxt,
	ASN1T_Extensions& asn1t_extensions, 
	const CACMPT_Extensions &Extensions);

void
ASN1T_Extensions_get (
    const ASN1T_Extensions& asn1t_extensions, 
    CACMPT_Extensions &Extensions);

/* dim: made static */
void SubjectPublicKeyInfo_Parse( CACMPT_PublicKeyInfo &dest,
    const ASN1T_AlgorithmIdentifier &src );

void tbsCertificateParse( ASN1T_TBSCertificate &cert, CertificateInfo *dest );

/* dim: inline? */
void
ASN1T_BigInt_gen (HCRYPTPROV hProv, ASN1OCTET* buf, int len);

void
CACMP_GenContainerName (HCRYPTPROV hProv, char szContainer[256]);

class CertificateTemplate
{
public:
    CertificateTemplate();
    ~CertificateTemplate();

    ASN1BEREncodeBuffer enc_buffer;
    CACMPT_ASN1BERDecodeBuffer dec_buffer;
    ASN1T_PKIMessage asn1t_request; //?
    ASN1T_Certificate asn1t_cert;
    ASN1T_Certificate asn1t_ca;
};

// missing id-it-xxx OID's in asn1data
// These OID's are used in GenM/GenRep

#define id_it_ResumeCertificate id_CryptoPro_it_ResumeCertificate
#define id_it_GetMessage id_CryptoPro_it_GetMessage
#define id_it_GetMessages id_CryptoPro_it_GetMessages
#define id_it_ChangeNameReq id_CryptoPro_it_ChangeNameReq
#define id_it_ResumeCertificateReply id_CryptoPro_it_ResumeCertificateReply

/* dim: made static */
void add_extra_certs( ASN1BERDecodeBuffer &dec_buffer,
    ASN1T_PKIMessage &asn1t_message, 
    const encoded_certificate_list &extra_certs );

void FreeText_Encode( ASN1CTXT *pctxt, ASN1T_PKIFreeText &dest,
    const FreeText &src );

void FreeText_Parse( ASN1CTXT *pctxt, FreeText &dest,
    const ASN1T_PKIFreeText &src );

DWORD get_pin_load( WndProv &wnd_prov, HCRYPTPROV hProv, const char *name, short n, int num );

/* dim: made static */
CACMPT_BLOB GetPinInfo( HCRYPTPROV hProv );

void get_reader_list( HCRYPTPROV hProv, ReaderList& );

bool create_with_change( WndProv &wnd_prov, 
    const char *provider, DWORD dwProvType, 
    const char *reader, const char *container, 
    short i, short n, HCRYPTPROV *hProv,
    DWORD *hProvInt );
void split_container_name( const char *name, 
    std::string &reader_name, std::string &container_name );
std::string get_container( HCRYPTPROV hProv );
std::string get_provider( HCRYPTPROV hProv );
/* dim: made static */
std::string get_unique( HCRYPTPROV hProv );

class RetrySetProvParam : public Retry
{
public:
    RetrySetProvParam( HCRYPTPROV hProv, DWORD dwParam, const BYTE *pbData,
	DWORD dwFlags ) : m_hProv( hProv ), m_dwParam( dwParam ), 
	m_pbData( pbData ), m_dwFlags( dwFlags ) {}
protected:
    virtual BOOL call( void ) 
    { return CryptSetProvParam( m_hProv, m_dwParam, (BYTE *)m_pbData, m_dwFlags ); }
    HCRYPTPROV m_hProv;
    DWORD m_dwParam;
    const BYTE *m_pbData;
    DWORD m_dwFlags;
};

class RetryGetProvParam : public Retry
{
public:
    RetryGetProvParam( HCRYPTPROV hProv, DWORD dwParam, BYTE *pbData,
	DWORD *pdwDataLen, DWORD dwFlags ) : m_hProv( hProv ), 
	m_dwParam( dwParam ), m_pdwDataLen( pdwDataLen ), m_pbData( pbData ), 
	m_dwFlags( dwFlags ) {}
protected:
    virtual BOOL call( void ) 
    { 
	DWORD dwDataLen = *m_pdwDataLen;
	if( CryptGetProvParam( m_hProv, m_dwParam, m_pbData, &dwDataLen,
	    m_dwFlags ) )
	{
	    *m_pdwDataLen = dwDataLen;
	    return TRUE;
	}
	return FALSE;
    }
    HCRYPTPROV m_hProv;
    DWORD m_dwParam;
    DWORD *m_pdwDataLen;
    BYTE *m_pbData;
    DWORD m_dwFlags;
};

class RetryAcquireContext : public Retry
{
public:
    RetryAcquireContext( HCRYPTPROV *hProv, const char *szContainer, 
	const char *szProvider, DWORD dwProvType, DWORD dwFlags,
	HCRYPTPROV hProvVerify );
    virtual BOOL call( void );
protected:
    HCRYPTPROV *m_hProv;
    std::string m_szContainer;
    const char *m_szProvider;
    DWORD m_dwProvType;
    DWORD m_dwFlags; 
    ReaderList list;
};

std::string get_sub_xml( std::string &src );
std::string get_not_xml( std::string &src );
std::string get_sub_xml_lend( std::string &src );

class ASN1T_Extension_traits
{
public:
    typedef ASN1C_Extension ASN1_C;

    static void set(
	ASN1CTXT* pctxt,
	ASN1T_Extension& dest,
	const CACMPT_Extension& src);
    static void get(
	const ASN1T_Extension& src,
	CACMPT_Extension& dest);
    static void copy(
	ASN1CTXT* pctxt,
	const ASN1T_Extension& src,
	ASN1T_Extension& dest);
};

class ASN1T_Extensions_traits
    : public ASN1TSeqOfList_traits<
	ASN1T_Extension,
	ASN1T_Extension_traits,
	CACMPT_Extension,
	CACMPT_Extensions>
{
public:
    typedef ASN1C_Extensions ASN1_C;
};

#endif // __CA_CMP_UTIL_H

#!/bin/sh

# $1 - VendorID $2 - ProductID $3 - FriendlyName 
# return 0 if OK, 1 if duplicated VendorID + ProductID + FriendlyName, 2 duplicated VendorID + ProductID
check_previous_registration()
{
  res=0
  vendor_str_find_arr=`echo "$VendorId_list" | grep -in $1  | awk -F":" '{print $1}'`
 
  for i in $vendor_str_find_arr
  do
    j=`expr $i - 1`
    eval tmp=\$ProductIdArr_$j
    str_in_section_productId=`echo $tmp | grep -i $2`
    if test -n "$str_in_section_productId"; then
       eval tmp="\$FriendlyNameArr_$j"
       str_in_section_friendly_name=`echo "$tmp" | sed 's/<string>//g' | sed 's/<\/string>//g' | grep -xi "$3"`
       if test -z "$str_in_section_friendly_name"; then
          res=2
       else
          res=1
       fi

       if test $res -eq 1; then
          return $res
       fi
    fi
  done

  return $res
}

# $1 - string $2 - section 
add_string_to_section()
{
  line=`sed -n "/$2/{=;}" $tmpFile`
  sed -i.old -e "$(( $line+2 ))i\\
<string>$1<\/string>" $tmpFile
  rm -f "$tmpFile.old"
}

print_help()
{
  echo "
  using ccid_reg.sh: 
  ccid_reg.sh [command] [arguments]:

  select [command] from:
  -help         Print this help
  -add          ccid_reg.sh -add <path_to_Info.plist> <VID> <PID> <Name>
  -list         ccid_reg.sh -list <path_to_Info.plist>
  -del          ccid_reg.sh -del <path_to_Info.plist> <VID> <PID> <Name>"
}

list_registrations()
{
  pre_command_action
 
  if test $? -eq 1; then
    return 3
  fi 

  #for ((i = 0 ; i < nVendorID ; i++ )); do 
  for i in `seq 0 $nVendorID`; do
    if test $i -eq $nVendorID; then
      break
    fi
    eval echo "\$VendorIdArr_$i:\$ProductIdArr_$i \$FriendlyNameArr_$i" | sed 's/0x//g'
  done
}  

pre_command_action()
{ 
  VendorId_list=`sed -n "/VendorID/,/<\/array>/p" $tmpFile | grep -v "<key>" | grep -v array|sed 's/<string>//g' | sed 's/<\/string>//g'`
  ProductId_list=`sed -n "/ProductID/,/<\/array>/p" $tmpFile | grep -v "<key>" | grep -v array|sed 's/<string>//g' | sed 's/<\/string>//g'`
  FriendlyName_list=`sed -n "/FriendlyName/,/<\/array>/p" $tmpFile | grep -v "<key>" | grep -v array|sed 's/<string>//g' | sed 's/<\/string>//g'`   
  nVendorID=`echo "$VendorId_list" | wc -l`
  nProductID=`echo "$ProductId_list" | wc -l`
  nFriendlyName=`echo "$FriendlyName_list" | wc -l`
  posVendorID=`sed -n "/VendorID/{=;}" $tmpFile`
  posProductID=`sed -n "/ProductID/{=;}" $tmpFile`
  posFriendlyName=`sed -n "/FriendlyName/{=;}" $tmpFile`

  if test -z "$VendorId_list" -o -z "$ProductId_list" -o -z "$FriendlyName_list"; then
    return 1
  fi

  if test "$nVendorID" -ne "$nProductID" -o "$nVendorID" -ne "$nFriendlyName" -o "$nProductID" -ne "$nFriendlyName"; then
    echo "error, $plist_file is corrupted"
    echo "number of lines in sections : VendorID - $nVendorID, ProductID - $nProductID, FriendlyName - $nFriendlyName"
    return 1
  fi

  i=0
  for tmp in $VendorId_list; do
    eval VendorIdArr_$i=$tmp
    i=`expr $i + 1`
  done

  tempFile=`mktemp /tmp/tmpInfo_XXXXXXXXXX` 
  echo "$FriendlyName_list" > $tempFile

  i=0
  while read line; do
    eval FriendlyNameArr_$i=\"$line\"
    i=`expr $i + 1`
  done < $tempFile
 
  i=0
  for tmp in $ProductId_list; do
    eval ProductIdArr_$i=$tmp
    i=`expr $i + 1`
  done

  rm -f $tempFile
  return 0
}

# $1 - Info.plist , $2 - VendorID , $3 - ProductID , $4 - Friendly Name
add_registration()
{
  pre_command_action

  if test $? -eq 1; then
    return 3
  fi

  VID=`echo $2 | sed 's/0x//g'`
  PID=`echo $3 | sed 's/0x//g'`
  name="$4"
  check_previous_registration $2 $3 "$name" 
  case $? in
  1)  echo "  same device \"$VID:$PID $name\" already registered"
      return 1;;
  2)  echo "  device with same VID:PID \"$VID:$PID\" already exists"
      return 2;;
  esac

  add_string_to_section $2 VendorID 
  add_string_to_section $3 ProductID 
  add_string_to_section "$4" FriendlyName 
   
  return 0
}

# $1 - Info.plist , $2 - VendorID , $3 - ProductID , $4 - Friendly Name 
del_registration()
{
  pre_command_action

  if test $? -ne 0; then
    return 3
  fi

  vendor_str_find_arr=`echo "$VendorId_list" | grep -in $2  | awk -F":" '{print $1}'`

  if test -z "$vendor_str_find_arr"; then
     echo "  error, string $2 to delete was not found"
     return 6
  fi

  found=0;
  for i in $vendor_str_find_arr; do
    j=`expr $i - 1`
    eval tmp=\$ProductIdArr_$j
    str_in_section_productId=`echo $tmp | grep -i $3`
    eval tmp="\$FriendlyNameArr_$j"
    str_in_section_friendly_name=`echo "$tmp" | grep -i "$4"`
    if test -n "$str_in_section_productId" && test -n "$str_in_section_friendly_name"; then
      found=1;
      sed -i.backup  "$(($i + $posVendorID + 1 ))d" $tmpFile
      sed -i.backup  "$(($i + $posProductID))d" $tmpFile
      sed -i.backup  "$(($i + $posFriendlyName - 1))d" $tmpFile
      rm -f "$tmpFile.backup"
      break
    fi
  done

  if test $found -eq 0; then
    echo "`echo "  error, cannot find $2:$3" | sed 's/0x//g'` $4 to delete"
    return 6 
  fi

  return 0
}

# $1 - cmd , $2 - Info.plist , $3 - VendorID, $4 - ProductID , $5 - Friendly Name
parse_cmd_line()
{
  if test -z "$1" || test "$1" = "--help" || test "$1" = "-help"; then
    print_help
    return 0
  fi

  if test $1 != "-add" && test $1 != "-list" && test $1 != "-del"; then
    echo "  error, wrong command"
    echo "  for more information use ccid.reg.sh -help" 
    return 1
  fi

  if (test -z "$5" && test $1 != "-list") || (test $1 = "-list" && test -z "$2"); then
    echo "  error, too few arguments for command $1"
    echo "  for more information use ccid.reg.sh -help"
    return 1
  fi

  if test ! -f "$2"; then
    echo "  error, file $2 doesn't exist" 
    return 1
  fi
  
  if test $1 != "-list"; then
    tmpFile=`mktemp /tmp/tmpInfo_XXXXXXXXXX`
    cp "$2" $tmpFile
  else
    tmpFile="$2"
  fi

  case $1 in
    "-add") add_registration $tmpFile $3 $4 "$5" 
    ;;
    "-list") list_registrations $tmpFile 
	     return $?
    ;;
    "-del")  del_registration $tmpFile $3 $4 "$5"
    ;;
  esac
 
  res=$?
  n_diff=`diff $tmpFile "$2" | wc -l`

  if test $n_diff -gt 30; then
    echo "unknown error occured"
    rm -f $tmpFile
    return 5
  fi

  cp $tmpFile "$2"  
  rm -f $tmpFile
  
  return $res
}

command=$1
plist_file="$2"
vendorID=$3
productID=$4
friendly_name="$5"
parse_cmd_line $command "$plist_file" $vendorID $productID "$friendly_name"

res=$?

exit $res

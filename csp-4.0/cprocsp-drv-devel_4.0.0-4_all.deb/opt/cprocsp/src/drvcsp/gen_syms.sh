#!/bin/sh
for f in $*
do
    mod_name=`basename $f|sed 's/\.ko$//'`
    nm -g $f|awk -v mod_name=$mod_name '
	/__crc_/ {
		sub("__crc_","",$3); 
		sub("^00000000","0x",$1);
		printf "%s\t%s\tcrypto/%s\tEXPORT_SYMBOL\n", $1,$3,mod_name;
		next
    } 
	{next}'
done

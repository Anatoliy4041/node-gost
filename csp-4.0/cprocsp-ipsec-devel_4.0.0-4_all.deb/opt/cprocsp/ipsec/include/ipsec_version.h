/*
 * Copyright(C) 2007-2012 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������-���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������-���.
 *
 * This is proprietary information of
 * Crypto-Pro company.
 *
 * Any part of this file can not be copied, 
 * corrected, translated into other languages,
 * localized or modified by any means,
 * compiled, transferred over a network from or to
 * any computer system without preliminary
 * agreement with Crypto-Pro company
 */

/*!
 * \file $RCSfile$
 * \version $Revision: 126987 $
 * \date $Date:: 2015-09-08 17:51:58 +0400#$
 * \author $Author: pav $
 *
 * \brief
 *
 */

#if !defined _IPSEC_VERSION_H_
#define _IPSEC_VERSION_H_

static const unsigned API_IPSEC_GOST_MAJOR = 8;
static const unsigned API_IPSEC_GOST_MINOR = 20150409; /* 20090111 == 2009-jan-11 */
static const unsigned API_CSP_GOST_MINIMAL = 0x00000400; /* PP_VERSION >= 4.0 */

/*
 * ChangeLog
 *
 * 20081117 - change API_MAJOR to 2
 * 20090103 - preliminary API
 * 20090111 - beta API (API_MAJOR to 3)
 * 20090114 - add capi_result::CAPI_MAC_ERROR
 * 20090119 - remove vblob::set_inited()
 * 20090127 - remove vblob::fill_siteid()
 * 20090313 - CP-21 (aka IPSEC-110): use #include "ike_gost_types.h"
 * 20090319 - isakmp/esp Encap/Decap: add input data' lengthes checks
 * 20090324 - CP-6 (aka IPSEC-116)
 *            p1_SetOtherPubKeyFn() - arg change: PCERT_PUBLIC_KEY_INFO otherPubKey --> PCCERT_CONTEXT otherCertContext
 *            p2_CreateFn() - remove `const vblob* OtherCERT_b' arg;
 * 20090331 - [follow arg change from 20090324] rename p1_SetOtherPubKeyFn to p1_SetOtherCertFn
 * 20090406 - fix CP-23 (aka IPSEC-114)
 *
 * 20090408 - increase API_IPSEC_GOST_MAJOR: struct ike/esp_gost_out: remove espprop/ikeprop, add pointers to memory-mgmt functions
 * 20090408 - remove ikeprop/espprop from typedef.h, ike_gost.h, esp_gost.h
 *            fix CP-18 (aka IPSEC-69) PSK become NUL-terminated C-string
 * 20090414 - fix CP-27b (aka IPSEC-101)
 * 20090917 - API V5.
 * 20091015 - IPSEC-186: remove useless definitions in vblob.h. rename DT_OTHER to DT_EXTDATA
 *            IPSEC-187: add 'virtual' in vblob.h
 *            IPSEC-193: add 5 new errcodes into enum capi_result
 *            IPSEC-197: CAPI_MORE_DATA+CAPI_NO_MORE_DATA --> CAPI_MOT_ENOUGH_SPACE
 * 20091029 - remove fields 'size' from API structs and related constants from this file
 * 20091111 - IPSEC-191: change Vendor ID
 * 20091208 - change algoithm for SKEYID, SK_a/SK_d  calculations
 * 20100301 - IPSEC-256: fix calling conventions
 * 20100423 - IPSEC-268: all in & out params serialize functions changed from std::vector to vblob *
 *            remove from API valid_psk_len(), vcreate3_const() as unused
 * 20100524 - IPSEC-285: remove from API as unused : vblob:: new/delete/new[]/delete[]
 * 20100525 - IPSEC-285: remove from API as unused : vblob::rw_ref()
 * 20100528 - IPSEC-282: added function : p1_NatDHash
 * 20100531 - IPSEC-285: remove from API as useless : vblob::vblob(DATA_TYPE, char*, unsigned)
 * 20100624 - VerifyIR remove "const" from vblob
 * 20100531 - IPSEC-285: remove from API as unused : vblob::DATA_TYPE::DT_BYTE_BE
 * 20100930 - espEncapFn()/espDecapFn() with IOVEC, add espGetParamFn(), fix transform's list
 * 20101102 - change CPESP_MAC_NULL: 11 --> 65411
 * 20101114 - size_t --> unsigned P1_SER_LEN, SPI_SER_LEN
 *            change P1_SER_LEN : 253 --> 249
 * 20101116 - change P1_SER_LEN : 249 --> 248
 * 20101125 - vblob::DT_TYPE rename DT_P2_DATA --> DT_SPI_DATA
 * 20101201 - added Encryption Bit check in p1_Decap, p2_Decap
 * 20101206 - io_krn.h -- force 4-bytes alignment to fix testesp.ko+example_io_krn for x64.
 *            x64-kernel tests PASS. x86 not affected.
 * 20101208 - IPSEC-321: example(CPIPSEC_PROTO_IPSEC_ESP, CPESP_GOST_4M_IMIT, CPESP_MAC_NULL) not work
 *            error was introduced 2010-dec-07 while code refactoring
 * 20110228 - IPSEC-331: CPIPSEC_PROTO_IPSEC_AH iovec support (now for all variations except SIMPLE)
 * 20110228 - IPSEC-371: performance improvements
 * 20110506 - IPSEC-393: API cleanup
 *            class vblob remove
 *               public: vblob(DT_TYPE), init(), is_usable()
 *               private: has_nontrivial_properties(), inited
 *            extern "C"
 *              remove vcreate1()
 *              rename vcreate3() --> vcreate()
 *            IKE: all objects created inside library now are created at all in library
 *            add one more indirection level to the following params
 *              p1_Serialize::p1_data
 *              p1_reSerialize::p1_data_to
 *              spiSerialize::spi_data
 *              spireSerialize::spi_data_to
 *              p1_Setup::{KEx_b, Nx_b}
 *              p1_Auth_ir::hs
 *              p1_Verify_ir::hash
 *              p1_NatDHash::NatDHash
 *              p2_Setup::{PFSKey, Nx_b}
 *              p2_Hash3::Hash3_b
 *              p2_HashA::hash
 * 20110516 - IPSEC-389 p1-Serialize/p2_Create: add "ready to use" check for parent P1 session
 *            now early return CAPI_PROTOCOL_ERROR instead of p2_Decap::CAPI_IMITA_ERROR
 * 20110708 - IPSEC-408 p1_SetPSKFn: added the P1_SETPSK_HCRYPT flag to allow HCRYPTKEY
 *            and HCRYPTPROV to be used in PSK mode without using genpsk infrastructure
 * 20110831 - IPSEC-408 sadb.CreatePSKFn: added the P1_SETPSK_HCRYPT flag to allow HCRYPTKEY
 *            and HCRYPTPROV to be used in PSK mode without using genpsk infrastructure     
 * 20110920 - IPSEC-421 CPC_CONFIG * config argument added in
 *            4 functions: deSerializePubKey/spiCreate/espEncap/espDecap 
 * 20111123 - IPSEC-435 extended number of phases 2 
 *            2^7, 2^12 -> 2^14, 2^16
 *            
 * 20111222 - increase API_IPSEC_GOST_MAJOR up to 7, increase API_IPSEC_GOST_MINOR
 * 20111226 - changed 1 reserved arg to shared string in ike and esp init struct for special KEYLOGGER build 
 * 20120116 - changed Vendor ID and added ver_spec to sid (p1, p2, spi) based on recognized Vendor ID in p1_CreateFn
 * 20120220 - IPSEC-443: remove #include "wincspc.h", typedef HCRYPTPROV, HCRYPTKEY, HCRYPTHASH from public headers
 * 20120312 - CPCSP-1616 add typedef HCRYPTPROV, HCRYPTKEY, HCRYPTHASH, HCRYPTMODULE, LPCPC_CONFIG in typedefs_sadb.h
 * 20120322 - IPSEC-450 remove ESP_GOST-SIMPLE-IMIT and Nortel compatibility mode
 * 20120323 - IPSEC-451 remove static vars from funcs
 * 20120409 - IPSEC-455 in spiSerialize only 100 unique spi sessions available from p2
 * 20120425 - IPSEC-460 spiCreate now creates own HCRYPTPROV and added FLAG_SADB_DUPLICATE_EPHEM to CreateEphemFn
 * 20120518 - IPSEC-471 correcting counter_bytes count and compare with ttlkb, bytes vs. kilobytes, kb wins
 * 20120531 - IPSEC-467 IPSEC-477 if unpredictable error occurs in CSP, sid stops to work in espEncapFn/espDecapFn
 *	      errors corresponding to "distorted" packets now goes with log CAPI_INFO/CAPI_NOTICE instead of CAPI_ERR
 * 20130205 - IPSEC-518 CFGMODE support added
 * 20131015 - half-year development. Alas, not documented yet
 * 20140110 - changelog now in CSP\doc\IPsec-changelog.txt
 */
#endif	/* _IPSEC_VERSION_H_ */
